#!/bin/bash
#	Loop on repeated readings for each lane starting on Lane 0
#	$1 B:D:F
#	$2 Number of Lanes
#	$3 Repeat Test 
#	$4 Any extra parameter - wildcard
#	$5 Any extra parameter - wildcard
#	$6 Any extra parameter - wildcard
#
LANES=$2
for ((i=0; i < LANES; i++)); do
	echo LANES= $i
	./PCIECVApp.exe -bdf $1 -td 1.556*$3 -lmtLaneNum $i -lmtErrLimit 4 -l 0 $4 $5 $6 
	if [[ "$?" -ne 0 ]]; then 
		break
	fi
done