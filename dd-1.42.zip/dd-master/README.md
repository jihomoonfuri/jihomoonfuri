# PCI-SIG Hardware Access Driver

[[_TOC_]]

## Windows

See [README_Windows.md](docs/README_Windows.md) for original Windows documentation.

### Supported Versions

The PCI-SIG Hardware Access (HWA) driver is supported on the following Windows versions:

- Windows 10 (x86, x64)
- Windows 11 (x64, ARM64)
- Windows Server 2019 (x86, x64)
- Windows Server 2022 (x86, x64)

### Build Instructions

#### Project Structure

The solution files for the driver and test program are:

- [`pcisig_driver/pcisig_driver.sln`](pcisig_driver/pcisig_driver.sln)
- [`pcisig_driver_test/pcisig_driver_test.sln`](pcisig_driver_test/pcisig_driver_test.sln)

The solution file for the test program contains the shared library project. The driver output files are:

- `pcisig_driver.inf`
- `pcisig_driver.cat`
- `pcisig_driver.sys`

The output directories for the driver project are:

- `pcisig_driver/$(ConfigurationName)/pcisig_driver` (x86)
- `pcisig_driver/x64/$(ConfigurationName)/pcisig_driver` (x64)
- `pcisig_driver/ARM64/$(ConfigurationName)/pcisig_driver` (ARM64)

where `$(ConfigurationName)` is an `MSBuild` configuration. The output files for the shared library and test program are:

- `pcisig_driver_lib.dll`
- `pcisig_driver_test.exe`

The output directories for the shared library and test program projects are:

- `pcisig_driver_test/$(ConfigurationName)` (x86)
- `pcisig_driver_test/x64/$(ConfigurationName)` (x64)
- `pcisig_driver_test/ARM64/$(ConfigurationName)` (ARM64)

#### Dependencies

Install Visual Studio 2019 and the Windows Driver Kit for Windows 11, version 21H2 following [these](https://learn.microsoft.com/en-us/windows-hardware/drivers/other-wdk-downloads) instructions. The last WDK to contain the 32-bit driver toolchain was Windows 11, version 21H2. You must install the WDK for Windows 11, version 21H2 to compile the 32-bit driver.

First, [install](https://learn.microsoft.com/en-us/windows-hardware/drivers/other-wdk-downloads#step-1-install-visual-studio) Visual Studio 2019. The edition (Community, Professional or Enterprise) does not matter. In the Visual Studio Installer, select the "Desktop development with C++" workload and the following components:

- Windows 11 SDK (10.0.22000.0)
- MSVC v142 - VS 2019 C++ ARM64 build tools (Latest)
- MSVC v142 - VS 2019 C++ ARM64 Spectre-mitigated libs (Latest)

Second, [install](https://learn.microsoft.com/en-us/windows-hardware/drivers/other-wdk-downloads#step-2-install-the-wdk) the WDK for Windows 11, version 21H2. The Visual Studio 2019 extension is installed by default. Note that PCIeCV 5.0 development on Windows requires MSVC v141 (x86/64) and MSVC v142 (ARM64) while UniCV requires MSVC v143.

#### Compilation

To build the driver, open [pcisig_driver.sln](pcisig_driver/pcisig_driver.sln) in Visual Studio 2019, select the desired configuration and platform and compile. For example: to compile the 64-bit driver in release mode, select the `Release` configuration and `x64` platform; to compile the ARM64 driver in debug mode, select the `Debug` configuration and `ARM64` platform. The `ARM` platform is not currently supported. Do not retarget the driver project if prompted.

Alternatively, launch an administrative PowerShell or Command Prompt session using the "Developer PowerShell for VS 2019" shortcut. The configuration of alternative build environment is detailed [here](https://learn.microsoft.com/en-us/cpp/build/building-on-the-command-line?view=msvc-170) but beyond the scope of these instructions. The following commands build the above configurations with verbose `MSBuild` output:

```
PS C:\dd> MSBuild.exe pcisig_driver\pcisig_driver.sln -t:Rebuild -p:Configuration=Release -p:Platform=x64 -v:Detailed
```

```
PS C:\dd> MSBuild.exe pcisig_driver\pcisig_driver.sln -t:Rebuild -p:Configuration=Debug -p:Platform=ARM64 -v:Detailed
```

To build the shared library and test program, open [`pcisig_driver_test.sln`](pcisig_driver_test/pcisig_driver_test.sln) in Visual Studio 2019, select the desired configuration and platform and compile. Note that the 32-bit configuration is named `Win32` rather than `x86`. Do not retarget the shared library or test program projects if prompted. The corresponding `MSBuild` commands are:

```
PS C:\dd> MSBuild.exe pcisig_driver_test\pcisig_driver_test.sln -t:Rebuild -p:Configuration=Release -p:Platform=x86 -v:Detailed
```

```
PS C:\dd> MSBuild.exe pcisig_driver_test\pcisig_driver_test.sln -t:Rebuild -p:Configuration=Debug -p:Platform=ARM64 -v:Detailed
```

### Testing

The test program is intended to load the driver dynamically. The 64-bit binary can load the 32-bit and 64-bit drivers. However, the 32-bit binary can only load the 32-bit driver. The ARM64 driver can only be loaded by the ARM64 binary.

To run the test program, open an administrative PowerShell or Command Prompt session. To load the driver dynamically, copy the desired driver output directory to the output directory of the test program. In the following example, the 64-bit test program is run with the 64-bit driver and again with the 32-bit driver. If you are unable to load the driver dynamically, install the driver and run the test program directly.

```
PS C:\dd\pcisig_driver_test\x64\Release> Copy-Item -Recurse -Path ..\..\..\pcisig_driver\x64\Release\pcisig_driver -Destination .
PS C:\dd\pcisig_driver_test\x64\Release> .\pcisig_driver_test.exe
PS C:\dd\pcisig_driver_test\x64\Release> Remove-Item -Recurse pcisig_driver
PS C:\dd\pcisig_driver_test\x64\Release> Copy-Item -Recurse -Path ..\..\..\pcisig_driver\Release\pcisig_driver -Destination .
PS C:\dd\pcisig_driver_test\x64\Release> .\pcisig_driver_test.exe
```

### Common Problems

#### Driver Signature Enforcement

If the driver fails to load because Driver Signature Enforcement is enabled, run the following commands from an administrative PowerShell or Command Prompt session to enable Windows Test Mode and reboot.

```
PS C:\> bcdedit.exe -set loadoptions DISABLE_INTEGRITY_CHECKS
PS C:\> bcdedit.exe -set TESTSIGNING ON
```

To disable Windows Test Mode, run the following commands:

```
PS C:\> bcdedit.exe -set loadoptions ENABLE_INTEGRITY_CHECKS
PS C:\> bcdedit.exe -set TESTSIGNING OFF
```

## Linux

See [`README_Linux.md`](docs/README_Linux.md) and [`boot_instructions.md`](docs/boot_instructions.md) for original Linux documentation.

### Supported Distributions

The driver and shared library compile on most standard Linux distributions. The following Linux distributions are officially supported:

- Debian 12 (x86, x64, ARM64)
- Ubuntu 20.04 LTS (x64, ARM64)
- Ubuntu 22.04 LTS (x64, ARM64)
- Fedora 37 (x64, ARM64)
- Fedora 38 (x64, ARM64)

### Build Instructions

#### Dependencies

Install the kernel headers and build tools for your Linux distribution. The commands `uname -a` and `cat /proc/version` provide all relevant information. The following commands will install whatever build tools and header files are necessary to compile the driver, shared library and test program.

1. Debian-based distributions

```
$ sudo apt install build-essential linux-headers-$(uname -r)
```

2. RPM-based distributions

```
$ dnf install make gcc kernel-devel
```

#### Compilation

The Linux build files are located [`dd/linux`](linux). Running `make` from that directory will build the driver, shared library and test program. The output files are named `pcisig_module.ko`, `libpcisig.so` and `pcisig_module_test`. The following commands build individual targets in order of their dependencies:

```
$ make module
$ make library
$ make test
```

To compile with debugging symbols, specify `DEBUG=1` when invoking `make`:

```
$ make DEBUG=1
```

### Installation

PCIeCV 5.0 versions 5.0.173.1 and above and UniCV require the kernel module and shared library to be installed in standard system locations. The following command installs the shared library to `/usr/local/lib` and the kernel module in your kernel source tree:

```
$ sudo make install
```

To uninstall the kernel module and shared library, run

```
$ sudo make uninstall
```

### Testing

The wrapper script [`runtest.sh`](linux/runtest.sh) is provided to invoke the test program. The following command reloads the driver if necessary, invokes the test program and removes it before terminating:

```
$ sudo ./runtest.sh pcisig_module
```
