/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_common.h
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#ifndef _pcisig_common_h
#define _pcisig_common_h



// Definitions relating to I/O Control
#define PCISIG_UNIQUE_SIGNATURE                0x4729134F
#define PCISIG_UNIQUE_SIGNATURE_OUT            0x47231343

#ifdef _WIN32

DEFINE_GUID (GUID_DEVINTERFACE_PCISIG,
    0xff4ea3b0,0x0d06,0x41dd,0x95,0x13,0xc9,0xa7,0x4b,0x7b,0x12,0xd8);
// {ff4ea3b0-0d06-41dd-9513-c9a74b7b12d8}

#define PCISIG_BASE                         0x900
#define PCISIG_IOCTL_INIT_PCI   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+1), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_GET_DRV_VERSION   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+2), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_GET_MCFG   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+3), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_READ_IO   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+4), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_WRITE_IO   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+5), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_GETSET_PCI_CONFIG_IO   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+6), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_GETSET_PCI_CONFIG_MCFG   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+7), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_RW_MEM_ADDR   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+8), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_TEST_MEM   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+9), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#define PCISIG_IOCTL_CLOSE_PCI   \
            CTL_CODE(FILE_DEVICE_UNKNOWN , (PCISIG_BASE+10), METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)

#else

enum {
    PCISIG_IOCTL_INIT_PCI = 0x8001,
    PCISIG_IOCTL_GET_DRV_VERSION,
    PCISIG_IOCTL_GET_CONFIG,
    PCISIG_IOCTL_GET_MCFG,
    PCISIG_IOCTL_ENUM_PCI_IO,
    PCISIG_IOCTL_ENUM_PCI_MCFG,
    PCISIG_IOCTL_GETSET_PCI_CONFIG_IO,
    PCISIG_IOCTL_GETSET_PCI_CONFIG_MCFG,
    PCISIG_IOCTL_GET_PCI_CONFIG_OS,
    PCISIG_IOCTL_WRITE_IO,
    PCISIG_IOCTL_READ_IO,
    PCISIG_IOCTL_SIZE_BAR,
    PCISIG_IOCTL_RW_MEM_ADDR,
    PCISIG_IOCTL_TEST_MEM
};
#endif


#ifdef _PCISIG_STDINT_
// Define a common method for all types
#define INT32       int
#define UINT32      unsigned int
#define UINT16      unsigned short
#define ULONG       unsigned long
#define PVOID       void*
#define ULONG_PTR   ulong*
#define UCHAR       unsigned char
#define PCHAR       char*
#define PUCHAR      unsigned char*
#define UINT8       unsigned char
#define LONGLONG    long long
#define UINT64      unsigned long long
#define BOOL        unsigned int
#define BOOLEAN     unsigned int
#define DWORD       unsigned int

#ifndef TRUE
#define TRUE        1
#define FALSE       0
#endif

#endif

#define PCISIG_IO_8                    0x1
#define PCISIG_IO_16                   0x2
#define PCISIG_IO_32                   0x3
#define PCISIG_MEM_8                   0x4
#define PCISIG_MEM_16                  0x5
#define PCISIG_MEM_32                  0x6

#define PCISIG_PCI_ENABLE_BIT          0x80000000

typedef struct
{
    UINT32  ioctlSignature;
    UINT32  requestAddrLow;
    UINT32  requestAddrHigh;
    UINT32  requestSize;
    UINT32  requestOffset;
    UINT32  inputData;
    UINT32  bitMaskOverride;
    BOOLEAN useMcfg;
    UINT32  command;
    
    // PCI Specific Data
    // Starting BDF for Enum's or just BDF for other calls
    UINT16  segment;
    UINT8   bus;
    UINT8   device;
    UINT8   function;

    UINT8   startBus;
    UINT8   endBus;

    UINT32  bufSize;
    UINT32  pciData[4096/4];
    UINT32  outReturnData;
    UINT32  outioctlStatus;
    UINT32  outPhysAddrLow;
    UINT32  outPhysAddrHigh;
    UINT32  outNumSegments;
} pcisigIoctl;


// Define Log Levels

#define PCISIGLOG_NONE                       0x0
#define PCISIGLOG_ERROR                      0x1
#define PCISIGLOG_DEBUG                      0x2
#define PCISIGLOG_INFO                       0x4


// Define IOCTL Return Values

enum {
    IOCTL_STATUS_UNDEFINED = 0,
    IOCTL_STATUS_SUCCESS,
    IOCTL_STATUS_NOTFOUND,
    IOCTL_STATUS_DRIVER_NOTFOUND,
    IOCTL_STATUS_BUF_ERROR,
    IOCTL_STATUS_SIGNATURE_ERROR,
    IOCTL_STATUS_IOMAP_ERROR,
    IOCTL_STATUS_ACPI_ERROR,
    IOCTL_STATUS_SEMAPHORE_ERROR,
    IOCTL_STATUS_SEMAPHORE_TIMEOUT,
    IOCTL_STATUS_IO_ERROR,
    IOCTL_STATUS_ALLOC_ERROR,
    IOCTL_STATUS_INVALID_SEGMENT,
    IOCTL_STATUS_PCIMCFG_SIZE_ERROR,
    IOCTL_STATUS_PCIMCFG_SEGMENT_ERROR,
    IOCTL_STATUS_PCIIO_SIZE_ERROR,
    IOCTL_STATUS_BUF_SIZE_ERROR,
    IOCTL_STATUS_LIB_DRV_MISMATCH_WARNING, // JPL 10/14/22 - Reduce to a warning since not all driver changes can cause incompatibility
    IOCTL_STATUS_BUFALLOC_FAILED,
    IOCTL_STATUS_PHYSTOVIRT_ERROR,
    IOCTL_STATUS_ERROR_READ_CONFIG,
    IOCTL_STATUS_ERROR_INVALID_FILEHANDLE,
    IOCTL_STATUS_ERROR_TIMESTAMP_FORMAT,
    IOCTL_STATUS_ERROR_CREATE_MKNOD,
    IOCTL_STATUS_ERROR_CLOSE,
    IOCTL_STATUS_USLEEP_FAILED,
    IOCTL_STATUS_ERROR_SETUPDI,
    IOCTL_STATUS_ERROR_INF,
    IOCTL_STATUS_ERROR_INFNOTFOUND,
    IOCTL_STATUS_ERROR_UPDATEDRIVER,
    // Parameter Errors
    IOCTL_PARAMETER_ERROR_SBDF,
    IOCTL_PARAMETER_ERROR_COMMAND,
    IOCTL_PARAMETER_ERROR_RW_SIZE,
    IOCTL_PARAMETER_ERROR_ALIGNMENT,
    IOCTL_PARAMETER_ERROR_MEMTYPE,
    IOCTL_PARAMETER_ERROR_INPUTBOUNDARY,
    IOCTL_PARAMETER_ERROR_ARRAY_SIZE,
    IOCTL_PARAMETER_ERROR_BUS_LIMIT,
    IOCTL_PARAMETER_ERROR_READVALUE_NULL,
    IOCTL_PARAMETER_ERROR_METHODTYPE,
    IOCTL_PARAMETER_ERROR_USLEEP_BOUNDARY,
    IOCTL_PARAMETER_ERROR_OVERRIDE,
    IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED
};


// PCI BUS VALUES
#define PCI_LASTFUNCTION                    0x7
#define PCI_LASTDEVICE                      0x1F
#define PCI_LASTBUS                         0XFF
#define PCI_LAST_SEGMENT                    0x10000

// I/O VALUES
#define IO_ADDR                             0xCF8
#define IO_DATA                             0xCFC

#define PCISIG_CMD_READ                     0x1
#define PCISIG_CMD_WRITE                    0x2
#define PCISIG_CMD_FREEBUF                  0x3
#define PCISIG_CMD_ALLOCBUF                 0x4
#define PCISIG_CMD_OVERRIDE                 0x5

#define PCISIG_MCFG_METHOD                  0x1
#define PCISIG_IO_METHOD                    0x2

#define PCISIG_MAP_TYPE_MMIO                0x1
#define PCISIG_MAP_TYPE_MEM                 0x2

#define PCISIG_SIZE_AUTO                    0x0
#define PCISIG_SIZE_BYTE                    0x1
#define PCISIG_SIZE_WORD                    0x2
#define PCISIG_SIZE_DWORD                   0x4

#define PCISIG_PCI_MCFG_SIZE                4096
#define PCISIG_PCI_IO_SIZE                  256
#define PCISIG_MAX_PCI_DEVICES              512
#define PCISIG_SIZE_BAR                     0x4
#define PCISIG_NUM_BARS                     0x6
#define PCISIG_NUM_BARS_BRIDGE              0x2
#define PCISIG_PCI_BAR_OFFSET               0x10
#define PCISIG_COMMAND_MASTER               0x4
#define PCISIG_PCI_VENDOR_OFFSET            0
#define PCISIG_MAX_LINE                     1024

#define MCFG_OFFSET_SIZE                    4
#define MCFG_ENTRY_SIZE                     44
#define MCFG_SEGMENT_SIZE                   16
#define MCFG_SEGMENT                        8
#define MCFG_START_BUS                      10
#define MCFG_END_BUS                        11
#define MCFG_BASE_LOW                       0
#define MCFG_BASE_HIGH                      4
#define MCFG_BUSADDR_OFFSET                 20
#define MCFG_DEVICEADDR_OFFSET              15
#define MCFG_FUNCADDR_OFFSET                12

#define PCIIO_BUSADDR_OFFSET                16
#define PCIIO_DEVICEADDR_OFFSET             11
#define PCIIO_FUNCADDR_OFFSET               8

#define PCISIG_8BIT_SET                     0xFF
#define PCISIG_16BIT_SET                    0xFFFF
#define PCISIG_32BIT_SET                    0xFFFFFFFF
#define PCISIG_32BIT_UNSET                  0x00000000
#define PCISIG_32BIT_UPPER16SET             0xFFFF0000
#define PCISIG_32BIT_LOWER16SET             0x0000FFFF

#define PCISIG_OVERRIDE_MCFG_STARTBUS       1 << 0
#define PCISIG_OVERRIDE_MCFG_ENDBUS         1 << 1
#define PCISIG_OVERRIDE_MCFG_BASELOW        1 << 2
#define PCISIG_OVERRIDE_MCFG_BASEHIGH       1 << 3

struct mCfgNodeLibOverRide {
    UINT32 bitMaskOverride;
    UINT16 segmentNum;
    UINT8  startBus;
    UINT8  endBus;
    UINT32 mcfgBaseLow;
    UINT32 mcfgBaseHigh;
};

#endif
