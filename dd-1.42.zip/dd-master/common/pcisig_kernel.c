/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_kernel.c
 
Environment:  Windows 32/64 bit Linux 32/64 bit
 
Common file for kernel code in Windows and Linux
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/

#ifndef _PCISIG_WIN_
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <acpi/acexcep.h>
#include "pcisig_common.h"
#include <linux/module.h>
#include <linux/device.h>
#include <linux/mutex.h>
#include <linux/acpi.h>
#include <linux/pci.h>

#define PCISIG_REL      1
//#undef PCISIG_REL // See debug
#define PFX "PCI-SIG: "

#ifdef PCISIG_REL
#undef pr_info
#define pr_info(fmt, ...)
#undef pr_warn
#define pr_warn(fmt, ...)
#endif

#else
#define _NO_CRT_STDIO_INLINE
#include "Driver.h"
#include <aux_klib.h>

#include "pcisig_common.h"
#define PFX "PCI-SIG: "
#define MAX_DRIVER_NAME_CCH 74
#define PCI_SIG_SIGNATURE   'PSIG'

extern VOID pr_info(__in PCCHAR  DebugMessage, ...);
#endif

#ifndef _PCISIG_WIN_
// Mcfg linked list structure
// One is created for each segment
// Dynamically allocated and torn down
struct mCfgNode {
    PVOID  pMcfg;
    UINT16 segmentNum;
    UINT8  startBus;
    UINT8  endBus;
    UINT32 mcfgBaseLow;
    UINT32 mcfgBaseHigh;
    struct mCfgNode* next;
};

struct mCfgNode             *gsMcfg = NULL;
PVOID                       gtestMem = NULL;

#endif

#ifdef _PCISIG_WIN_
void local_irq_disable(void) {
    return;
}

void local_irq_enable(void) {
    return;
}
#endif

#ifndef _PCISIG_WIN_
// Free up the linked list holding the MCfg structure
void pcisig_freeList(void)
{
    // Lets free up all the nodes on the linked list
    struct mCfgNode* tmp;

    while (gsMcfg != NULL)
    {
        tmp = gsMcfg;
        gsMcfg = gsMcfg->next;
        pr_info( PFX "[%s] tmp = %p gsMcfg = 0x%p, tmp->pMcfg = %p\n", __func__ , tmp, gsMcfg, tmp->pMcfg);
        if (tmp->pMcfg != NULL)
        {
            iounmap( tmp->pMcfg );
            tmp->pMcfg = NULL;
        }
        kfree(tmp);
     }
}
#else
// Free up the linked list holding the MCfg structure
void pcisig_freeList(struct mCfgNode **gsMcfg)
{
    // Lets free up all the nodes on the linked list
    struct mCfgNode* tmp;

    while (*gsMcfg != NULL)
    {
        tmp = *gsMcfg;
        *gsMcfg = (*gsMcfg)->next;
        pr_info( PFX "[%s] tmp = %p gsMcfg = 0x%p, tmp->pMcfg = %p\n", __func__ , tmp, *gsMcfg, tmp->pMcfg);
        if (tmp->pMcfg != NULL)
        {
            MmUnmapIoSpace(tmp->pMcfg, (tmp->endBus - tmp->startBus + 1) * PCISIG_PCI_IO_SIZE * PCISIG_PCI_MCFG_SIZE);
            tmp->pMcfg = NULL;
        }
        MmFreeNonCachedMemory(tmp, sizeof(struct mCfgNode));
     }
}
#endif

// Given a segment number, locate the correct MCFG address
// Function walks the MCFG table mapping the segment
// On success, it will return the correct structure
#ifndef _PCISIG_WIN_
struct mCfgNode* pcisig_MapSegmentToMcfg(UINT16 findSegment)
#else
struct mCfgNode* pcisig_MapSegmentToMcfg(struct mCfgNode *gsMcfg, UINT16 findSegment)
#endif
{
    struct mCfgNode* tmp = gsMcfg;
    while (tmp != NULL)
    {
        //pr_info( PFX "[%s] tmp->segmentNum = 0x%x findSegment = 0x%x\n", __func__ , tmp->segmentNum, findSegment);
        if (tmp->segmentNum == findSegment)
        {
            return tmp;
        }
        tmp = tmp->next;
    }
    return NULL;
}

// Read from Config Space
UINT32 pcisig_ReadConfigIO(UINT32 IOSize, UINT32 inputAddr, UINT8 offset)
{
    // pr_warn( PFX "[%s] IOSize = %x, inputAddr = %x, offset = %x\n", __func__ , IOSize, inputAddr, offset);
#if defined(_M_ARM64) && defined(_PCISIG_WIN_)
ASSERTMSG(FALSE, "Arm64 does not support IOPort access\n");
UNREFERENCED_PARAMETER(IOSize);
UNREFERENCED_PARAMETER(inputAddr);
UNREFERENCED_PARAMETER(offset);
#elif defined(_M_ARM64) //Arm linux
#else //non-Arm
#ifndef _PCISIG_WIN_
    outl(inputAddr, (UINT16) IO_ADDR);
    if (IOSize == PCISIG_IO_8)
    {
        return (UINT32) inb(IO_DATA + (offset&3));
    }
    else if (IOSize == PCISIG_IO_16)
    {
        return (UINT32) inw(IO_DATA + (offset&2));
    }
    else if (IOSize == PCISIG_IO_32)
    {
        return (UINT32) inl(IO_DATA);
    }

#else
    __outdword((UINT16) IO_ADDR, (ULONG) inputAddr);
    if (IOSize == PCISIG_IO_8)
    {
        return (UINT32) __inbyte((USHORT) (IO_DATA + (offset&3)));
    }
    else if (IOSize == PCISIG_IO_16)
    {
        return (UINT32) __inword((USHORT) (IO_DATA + (offset&2)));
    }
    else if (IOSize == PCISIG_IO_32)
    {
        return (UINT32) __indword((USHORT) (IO_DATA ));
    }
#endif
#endif
    return 0;
}

// Write to Config Space
void pcisig_WriteConfigIO(UINT32 IOSize, UINT32 inputAddr, UINT8 offset, UINT32 inputData)
{
    //pr_info( PFX "[%s] IOSize = %x, inputAddr = %x inputData = %x, offset = %x\n", __func__ , IOSize, inputAddr, inputData, offset);
#if defined(_M_ARM64) && defined(_PCISIG_WIN_)
ASSERTMSG(FALSE, "Arm64 does not support IOPort access\n");
UNREFERENCED_PARAMETER(IOSize);
UNREFERENCED_PARAMETER(inputAddr);
UNREFERENCED_PARAMETER(offset);
UNREFERENCED_PARAMETER(inputData);
#elif defined(_M_ARM64) //Arm linux
#else //non Arm
#ifndef _PCISIG_WIN_
    outl(inputAddr, (UINT16) IO_ADDR);
    if (IOSize == PCISIG_IO_8)
    {
        outb((UINT8) inputData,  IO_DATA + (offset&3));
    }
    else if (IOSize == PCISIG_IO_16)
    {
        outw((UINT16) inputData, IO_DATA + (offset&2));
    }
    else if (IOSize == PCISIG_IO_32)
    {
        outl((UINT32) inputData, IO_DATA);
    }
#else
    __outdword((UINT16) IO_ADDR, (ULONG) inputAddr);
    if (IOSize == PCISIG_IO_8)
    {
        __outbyte((UINT16) (IO_DATA + (offset&3)), (UCHAR) inputData);
    }
    else if (IOSize == PCISIG_IO_16)
    {
        __outword((UINT16) (IO_DATA + (offset&2)), (USHORT) inputData);
    }
    else if (IOSize == PCISIG_IO_32)
    {
        __outdword((UINT16) (IO_DATA), (ULONG) inputData);
    }
#endif
#endif
}

#if !defined(_M_ARM64) // Arm64 does not support IOPort access 
// Read from legacy I/O Ports
// Returns 0 for a read if it fails
// However the library will scan the parameters
UINT32 pcisig_ReadIO(UINT32 IOSize, UINT32 inputAddr)
{
    //pr_info( PFX "[%s] IOSize = %x, inputAddr = %x\n", __func__ , IOSize, inputAddr);
#ifndef _PCISIG_WIN_
    if (IOSize == PCISIG_IO_8)
    {
        return (UINT32) inb(inputAddr);
    }
    else if (IOSize == PCISIG_IO_16)
    {
        return (UINT32) inw(inputAddr);
    }
    else if (IOSize == PCISIG_IO_32)
    {
        return (UINT32) inl(inputAddr);
    }
#else
    if (IOSize == PCISIG_IO_8)
    {
        return (UINT32) __inbyte((USHORT) inputAddr);
    }
    else if (IOSize == PCISIG_IO_16)
    {
        return (UINT32) __inword((USHORT) inputAddr);
    }
    else if (IOSize == PCISIG_IO_32)
    {
        return (UINT32) __indword((USHORT) inputAddr);
    }
#endif
    return 0;
}

// Write to the legacy I/O Ports
void pcisig_WriteIO(UINT32 IOSize, UINT32 inputAddr, UINT32 inputData)
{
    //pr_info( PFX "[%s] IOSize = %x, inputAddr = %x inputData = %x\n", __func__ , IOSize, inputAddr, inputData);
#ifndef _PCISIG_WIN_
    if (IOSize == PCISIG_IO_8)
    {
        outb((UINT8) inputData, (UINT16) inputAddr);
    }
    else if (IOSize == PCISIG_IO_16)
    {
        outw((UINT16) inputData, (UINT16) inputAddr);
    }
    else if (IOSize == PCISIG_IO_32)
    {
        outl((UINT32) inputData, (UINT16) inputAddr);
    }
#else
    if (IOSize == PCISIG_IO_8)
    {
        __outbyte((UINT16) inputAddr, (UCHAR) inputData);
    }
    else if (IOSize == PCISIG_IO_16)
    {
        __outword((UINT16) inputAddr, (USHORT) inputData);
    }
    else if (IOSize == PCISIG_IO_32)
    {
        __outdword((UINT16) inputAddr, (ULONG) inputData);
    }
#endif
}
#endif

// Reads from Memory Mapped I/O
UINT32 pcisig_ReadMemory(UINT32 IOSize, UINT8* inputAddr, UINT32 offset)
{
#ifndef _PCISIG_WIN_
    if (IOSize == PCISIG_MEM_8)
    {
        return (UINT32) readb((PVOID)(inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_16)
    {
        return (UINT32) readw((PVOID)(inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_32)
    {
        return (UINT32) readl((PVOID)(inputAddr + offset));
    }
#else
    if (IOSize == PCISIG_MEM_8)
    {
        return (UINT32) READ_REGISTER_UCHAR((PUCHAR) (inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_16)
    {
        return (UINT32) READ_REGISTER_USHORT((PUSHORT) (inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_32)
    {
        return (UINT32) READ_REGISTER_ULONG((PULONG) (inputAddr + offset));
    }
#endif
    return 0;
}

// Writes to Memory Mapped I/O
void pcisig_WriteMemory(UINT32 IOSize, UINT8* inputAddr, UINT32 offset, UINT32 inputData)
{
    //pr_info( PFX    "[%s] IOSize = %x, inputAddr = %p offset = %x inputData = %x\n", __func__ ,
     //                       IOSize, inputAddr, offset, inputData);
#ifndef _PCISIG_WIN_
    if (IOSize == PCISIG_MEM_8)
    {
        writeb((UINT8)inputData, (PVOID)(inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_16)
    {
        writew((UINT16)inputData, (PVOID)(inputAddr + offset));
    }
    else if (IOSize == PCISIG_MEM_32)
    {
        writel((UINT32)inputData, (PVOID)(inputAddr + offset));
    }
#else
    if (IOSize == PCISIG_MEM_8)
    {
        WRITE_REGISTER_UCHAR((PUCHAR) (inputAddr + offset), (UCHAR) inputData);
    }
    else if (IOSize == PCISIG_MEM_16)
    {
        WRITE_REGISTER_USHORT((PUSHORT) (inputAddr + offset), (USHORT) inputData);
    }
    else if (IOSize == PCISIG_MEM_32)
    {
        WRITE_REGISTER_ULONG((PULONG) (inputAddr + offset), (ULONG) inputData);
    }
#endif
}

#ifdef _PCISIG_WIN_
#define ACPI_TABLE_SIZE 1024 // Number of bytes for ACPI table

NTSTATUS getPdoPropertyData(
    __in PDEVICE_OBJECT                           pdo,
    __in const DEVPROPKEY*                        propKey,    
    __deref_out PUCHAR*                           propDataBuf,
    __out PULONG                                  propDataSize
    )
{
    NTSTATUS    status              = STATUS_SUCCESS;
    DEVPROPTYPE type                = 0;

    // Find out how big of a buffer we need
    status =
        IoGetDevicePropertyData(
            pdo,
            propKey,
            LOCALE_NEUTRAL,
            0,
            0,
            (PVOID)(*propDataBuf),
            propDataSize,
            &type
        );
    if (status != STATUS_BUFFER_TOO_SMALL) return status;


    // Allocate the buffer to hold the property data
    *propDataBuf = ExAllocatePool2(POOL_FLAG_PAGED, *propDataSize, PCI_SIG_SIGNATURE);
    if (*propDataBuf == NULL)
    {
        status = STATUS_INSUFFICIENT_RESOURCES;
        return status;
    }

    // Get the property data
    status =
        IoGetDevicePropertyData(
            pdo,
            propKey,
            LOCALE_NEUTRAL,
            0,
            *propDataSize,
            (PVOID)(*propDataBuf),
            propDataSize,
            &type
       );

    return status;
}

BOOLEAN ParseSBDF(
    __in    LPWSTR      str,
    __out   PULONG      seg,
    __out   PULONG      bus,
    __out   PULONG      dev,
    __out   PULONG      func
    )
{
    WCHAR marker[] = L";(";
    WCHAR *start = NULL;
    ULONG numTokens = 0;

    start = wcsstr(str, marker);

    numTokens =
        swscanf_s(
            start,
            L";(%u,%u,%u,%u)",
            seg,
            bus,
            dev,
            func
        );

    if (numTokens == 4)
        return TRUE;

    // EP 2023/07/19 - The seg, bus and dev pointers are assigned when the pre-
    // vious swscanf_s call fails. To prevent segPowerArray from being indexed
    // with invalid segment number, clear seg pointer before parsing BDF.

    *seg = 0;

    numTokens =
        swscanf_s(
            start,
            L";(%u,%u,%u)",
            bus,
            dev,
            func
        );

    return (numTokens == 3);
}

NTSTATUS getPCIBusDevObj(
    __deref_out PFILE_OBJECT*     fileObj,
    __deref_out PDEVICE_OBJECT*     devObj
    )
{
    NTSTATUS            status = STATUS_SUCCESS;
    UNICODE_STRING      devName;

    RtlInitUnicodeString(&devName, L"\\Device\\PciControl");

    status = IoGetDeviceObjectPointer(
        &devName,
        FILE_READ_ACCESS,
        fileObj,
        devObj
    );

    return status;
}


// Using IoEnumerateDeviceObjectList() to list all the PCI device objects
// happens to work but it is not guaranteed to work in the future as
// IoEnumerateDeviceObjectList() is intented to be used by filesystem drivers.
// But there is no great alternative to walk powered portion of the PCIe tree
// in the kernel on Windows.
NTSTATUS getChildDevObjs(
    __in PDRIVER_OBJECT             driverObj,
    __out PULONG                    numDevObjs,
    __deref_out PDEVICE_OBJECT**    devObjArray
)
{
    NTSTATUS            status = STATUS_SUCCESS;

    *numDevObjs = 0;
    *devObjArray = NULL;

    //
    // Determine the number of device objects that current exist in the
    // system and it is attached to driver object
    // This will not work if PCIe devices are being hot plugged into
    // the system. If we need to cover hot plugging as well,
    // then a retry loop would be needed.
    status =
        IoEnumerateDeviceObjectList(
            driverObj,
            NULL,
            0,
            numDevObjs
        );

    // Expecting STATUS_BUFFER_TOO_SMALL if successful
    if (status != STATUS_BUFFER_TOO_SMALL) return status;

    // Clean up status
    status = STATUS_SUCCESS;

    *devObjArray =
        ExAllocatePool2(
            POOL_FLAG_PAGED,
            (*numDevObjs) * sizeof(PDEVICE_OBJECT),
            PCI_SIG_SIGNATURE
        );
    if (*devObjArray == NULL)
    {
        status = STATUS_INSUFFICIENT_RESOURCES;
        return status;
    }

    //
    // Enumerate all of the device objects for real this time
    //
    status =
        IoEnumerateDeviceObjectList(
            driverObj,
            *devObjArray,
            *numDevObjs * sizeof(PDEVICE_OBJECT),
            numDevObjs
        );

    return status;
}

NTSTATUS querySegPowerStatus(
    PBOOLEAN segPowStatus
    )
{
    NTSTATUS        status      = STATUS_SUCCESS;
    PFILE_OBJECT    fileObj     = NULL;
    PDEVICE_OBJECT  devObj      = NULL;
    ULONG           numDevObjs  = 0;
    PDEVICE_OBJECT* devObjArray = NULL;

    status = getPCIBusDevObj(&fileObj, &devObj);
    if (!NT_SUCCESS(status) || fileObj == NULL || devObj == NULL)
        goto querySegPowerStatus_exit;

    status = 
        getChildDevObjs(
            devObj->DriverObject,
            &numDevObjs,
            &devObjArray
        );
    if (!NT_SUCCESS(status)) goto querySegPowerStatus_exit;

    //
    // Iterate over each enumerated child device object.
    //
    for (ULONG i = 0; i < numDevObjs; i++)
    {
        PDEVICE_OBJECT pdo = NULL;
        PUCHAR locationInfoBuffer = NULL;
        ULONG bufferSize = 0;

        if (devObjArray[i] == NULL) continue;

        pdo = IoGetDeviceAttachmentBaseRef(devObjArray[i]); // will increment ref count on device object

        if (pdo != NULL && pdo->DeviceObjectExtension->DeviceNode != NULL)
        {
            status = getPdoPropertyData(
                        pdo,
                        &DEVPKEY_Device_LocationInfo,
                        &locationInfoBuffer,
                        &bufferSize);

            if (status == STATUS_OBJECT_NAME_NOT_FOUND)
                status = STATUS_SUCCESS;

            if (NT_SUCCESS(status) && locationInfoBuffer != NULL)
            {
                ULONG   seg = 0;
                ULONG   bus = 0;
                ULONG   dev = 0;
                ULONG   func = 0;
                ParseSBDF(
                    (LPWSTR)locationInfoBuffer,
                    &seg,
                    &bus,
                    &dev,
                    &func
                );

                ExFreePoolWithTag(locationInfoBuffer, PCI_SIG_SIGNATURE);

                PUCHAR powerDataBuffer = NULL;
                status = getPdoPropertyData(
                    pdo,
                    &DEVPKEY_Device_PowerData,
                    &powerDataBuffer,
                    &bufferSize);

                if (NT_SUCCESS(status) && powerDataBuffer != NULL)
                {
                    PCM_POWER_DATA powerData = (PCM_POWER_DATA)powerDataBuffer;
                    if (powerData->PD_MostRecentPowerState == PowerDeviceD0)
                        segPowStatus[seg] = TRUE;

                    ExFreePoolWithTag(powerDataBuffer, PCI_SIG_SIGNATURE);
                }
            }
        }

        if (devObjArray[i]) ObDereferenceObject(devObjArray[i]);
    }

querySegPowerStatus_exit:
    if (devObjArray) ExFreePoolWithTag(devObjArray, PCI_SIG_SIGNATURE);
    if (fileObj) ObDereferenceObject(fileObj);
    return status;
}

// Get the ACPI Mcfg Table
// This function will fill in our linked list
UINT32 pcisig_getMcfgACPI(struct mCfgNode **gsMcfg, pcisigIoctl* inIoctl, pcisigIoctl* outParam, UINT32 updateList)
{
    UINT8                       *cpTable;
    UINT8                       *base; // Base offset to each segment entry
    UINT32                      acpiTableSize;
    UINT16                      totalSegments;
    PHYSICAL_ADDRESS            physAddr;
    UINT32                      loop; // loop variable for each Segment Entry
    struct mCfgNode             *tail;
    struct mCfgNode             *tmp; // Current store for each Segment Entry parameters
    UINT32                      retStatus = IOCTL_STATUS_SUCCESS;
    struct mCfgNodeLibOverRide  overRide = {0,0,0,0,0,0};
    NTSTATUS                    status;
    PCHAR                       acpiTable[ACPI_TABLE_SIZE];
    ULONG                       returnSize = 0;
    PBOOLEAN                    segPowArray = NULL;

    pr_info( PFX"[%s] updateList = 0x%x\n", __func__ , updateList);
   // Check if we currently have a populated linked list
    // If so, lets free it and repopulate
    if ((*gsMcfg != NULL) && (updateList == TRUE))
    {
        pcisig_freeList(gsMcfg);
    }

    if (updateList == TRUE)
    {
        // Lets see if we have an override structure
        if (inIoctl->command == PCISIG_CMD_OVERRIDE)
        {
            overRide.bitMaskOverride = inIoctl->bitMaskOverride;
            overRide.segmentNum = inIoctl->segment;
            overRide.startBus = inIoctl->startBus;
            overRide.endBus = inIoctl->endBus;
            overRide.mcfgBaseLow = inIoctl->requestAddrLow;
            overRide.mcfgBaseHigh = inIoctl->requestAddrHigh;
        }
    }
    
    // OS function to get the MCFG ACPITable
    // It returns a structure which will need to free up
    status = AuxKlibInitialize();
    status = AuxKlibGetSystemFirmwareTable('ACPI','GFCM', (PVOID)&acpiTable, sizeof(acpiTable), &returnSize);
    pr_info( PFX"[%s] returnSize = 0x%x\n", __func__ , returnSize);
    if (status != STATUS_SUCCESS)
    {
        retStatus = IOCTL_STATUS_ACPI_ERROR;
        goto pcisig_getMcfgACPI_end;
    }

    // Extract the MCFG from the table
    // Definition is here: https://wiki.osdev.org/PCI_Express
    // Note: We need offset 44
        
    // Get a character pointer to the table
    cpTable = (UINT8*) acpiTable;
        
    // The size of the table is at offset 4
    acpiTableSize = *(UINT32 *) (cpTable + MCFG_OFFSET_SIZE);
    totalSegments = (UINT16)(acpiTableSize - MCFG_ENTRY_SIZE)/MCFG_SEGMENT_SIZE;

    segPowArray =
        ExAllocatePool2(
            POOL_FLAG_PAGED,
            sizeof(UINT16) * totalSegments,
            PCI_SIG_SIGNATURE
        );
    if (segPowArray == NULL)
    {
        retStatus = IOCTL_STATUS_ALLOC_ERROR;
        goto pcisig_getMcfgACPI_end;
    }

    status = querySegPowerStatus(segPowArray);
    if (!NT_SUCCESS(status))
    {
        retStatus = IOCTL_STATUS_IO_ERROR;
        goto pcisig_getMcfgACPI_end;
    }

    // There are n structures for each bridge, we will just get the first one
    pr_info( PFX"[%s] acpiTableSize = 0x%x\n", __func__ , acpiTableSize);
    pr_info( PFX"[%s] PCI Segment Groups: = 0x%x\n", __func__ , totalSegments);
    if ((updateList == TRUE) && (acpiTableSize >= (MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE)))
    {
        tail = NULL;
        for (loop=0; loop < totalSegments; loop++)
        {
            UINT16 segmentNum = *(UINT16*) (cpTable + MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE*loop + MCFG_SEGMENT);

            // If the segment is not powered on, skip it
            if (segPowArray[segmentNum] == FALSE)
                continue;

            tmp = MmAllocateNonCachedMemory(sizeof(struct mCfgNode));
            if (!tmp) {
                retStatus = IOCTL_STATUS_ALLOC_ERROR;
                goto pcisig_getMcfgACPI_end;
            }
            memset(tmp, 0, sizeof(struct mCfgNode));

            // Setup the linked list, if we don't have a tail it means we don't have a head
            if (tail == NULL)
            {
                *gsMcfg = tmp;
            }
            else
            {
                tail->next = tmp;                
            }

            tail = tmp;
            base = cpTable + MCFG_ENTRY_SIZE + (MCFG_SEGMENT_SIZE * loop); // Base offset to Segment Entry

            tmp->segmentNum   = *(UINT16*)(base + MCFG_SEGMENT); // JPL 5/24/23 - corrected offset to segment Number
            tmp->mcfgBaseLow  = *(UINT32*)(base + MCFG_BASE_LOW);
            tmp->mcfgBaseHigh = *(UINT32*)(base + MCFG_BASE_HIGH);
            tmp->startBus     = *(UINT8*)(base + MCFG_START_BUS);
            tmp->endBus       = *(UINT8*)(base + MCFG_END_BUS);

            // Now let's override as necessary
            if ((inIoctl->command == PCISIG_CMD_OVERRIDE) && (overRide.segmentNum == tmp->segmentNum))
            {
                if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_STARTBUS)
                    tmp->startBus = overRide.startBus;
                if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_ENDBUS)
                    tmp->endBus = overRide.endBus;
                if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASELOW)
                    tmp->mcfgBaseLow = overRide.mcfgBaseLow;
                if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASEHIGH)
                    tmp->mcfgBaseHigh = overRide.mcfgBaseHigh;
            }
            pr_info( PFX "[%s] mcfgBaseLow = 0x%X mcfgBaseHigh = 0x%X\n", __func__ , tmp->mcfgBaseLow, tmp->mcfgBaseHigh);
            pr_info( PFX "[%s] gsMcfg = 0x%p tail = 0x%p tmp = 0x%p\n", __func__ , gsMcfg, tail, tmp);
            pr_info( PFX "[%s] Reading Segment = 0x%X\n", __func__ , tmp->segmentNum);
            pr_info( PFX "[%s] startBus = 0x%X endBus = 0x%X\n", __func__ , tmp->startBus, tmp->endBus);

#ifdef CONFIG_X86_32
            physAddr = (phys_addr_t) tmp->mcfgBaseLow;
#else
            //  physAddr = ((ULONG)tmp->mcfgBaseHigh << 32) | tmp->mcfgBaseLow;
            physAddr.u.LowPart = tmp->mcfgBaseLow;
            physAddr.u.HighPart = tmp->mcfgBaseHigh;
#endif
            pr_info( PFX "[%s] ACPI MCFG phys_addr = 0x%llX\n", __func__ , physAddr);
            // Map the MCFG Address from the physical address to a virtual Address
            tmp->pMcfg = MmMapIoSpace(physAddr, (tmp->endBus - tmp->startBus + 1) * PCISIG_PCI_IO_SIZE * PCISIG_PCI_MCFG_SIZE, MmNonCached);
            pr_info( PFX "[%s] tmp->pMcfg = 0x%p\n", __func__ , tmp->pMcfg);
            if (tmp->pMcfg == NULL)
            {
                pr_info( PFX "[%s] calling pcisg_freeList since tmp->pMcfg is NULL\n", __func__);
                pcisig_freeList(gsMcfg);
                retStatus = IOCTL_STATUS_IOMAP_ERROR;
                goto pcisig_getMcfgACPI_end;
            }
        }
        
        // EP 2023/07/19 - tail points to the last MCFG node

        if (tail)
            tail->next = NULL;

    }
    retStatus = IOCTL_STATUS_SUCCESS;
    memcpy(outParam->pciData, acpiTable, acpiTableSize);
    outParam->outNumSegments = totalSegments;

pcisig_getMcfgACPI_end:

    if (segPowArray)
        ExFreePoolWithTag(segPowArray, PCI_SIG_SIGNATURE);

    return retStatus;
}
#else
// Linux
// Get the ACPI Mcfg Table
// This function will fill in our linked list
UINT32 pcisig_getMcfgACPI(pcisigIoctl* inIoctl, pcisigIoctl* outParam, BOOLEAN updateList)
{
    struct acpi_table_header    *acpiTable;
    UINT8                       *cpTable;
    UINT8                       *base; // Base offset to each segment entry
    UINT32                      acpiTableSize;
    UINT16                      totalSegments;
    phys_addr_t                 physAddr;
    struct mCfgNode             *tail;
    struct mCfgNode             *tmp;
    UINT32                      segmentEntryLoop;
    UINT32                      retStatus = IOCTL_STATUS_SUCCESS;
    struct mCfgNodeLibOverRide  overRide;

    pr_info( PFX"[%s] updateList = 0x%x\n", __func__ , updateList);

    // Check if we currently have a populated linked list
    // If so, lets free it and repopulate
    if ((gsMcfg != NULL) && (updateList == TRUE))
    {
        pcisig_freeList();
    }

    if (updateList == TRUE)
    {
        // Lets see if we have an override structure
        if (inIoctl->command == PCISIG_CMD_OVERRIDE)
        {
            overRide.bitMaskOverride = inIoctl->bitMaskOverride;
            overRide.segmentNum = inIoctl->segment;
            overRide.startBus = inIoctl->startBus;
            overRide.endBus = inIoctl->endBus;
            overRide.mcfgBaseLow = inIoctl->requestAddrLow;
            overRide.mcfgBaseHigh = inIoctl->requestAddrHigh;
        }
    }
    
    // OS function to get the MCFG ACPITable
    // It returns a structure which will need to free up
    retStatus = acpi_get_table(ACPI_SIG_MCFG, 0, &acpiTable);
    if (ACPI_SUCCESS(retStatus))
    {
        // Extract the MCFG from the table
        // Definition is here: https://wiki.osdev.org/PCI_Express
        // Note: We need offset 44
        
        // Get a character pointer to the table
        cpTable = (UINT8*) acpiTable;
        
        // The size of the table is at offset 4
        acpiTableSize = *(UINT32 *) (cpTable + MCFG_OFFSET_SIZE);
        totalSegments = (acpiTableSize - MCFG_ENTRY_SIZE)/MCFG_SEGMENT_SIZE;

        // There are n structures for each bridge, we will just get the first one
    
        pr_info( PFX"[%s] acpiTableSize = 0x%x\n", __func__ , acpiTableSize);
        pr_info( PFX"[%s] PCI Segment Groups: = 0x%x\n", __func__ , totalSegments);
        if ((updateList == TRUE) && (acpiTableSize >= (MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE)))
        {
            tail = NULL;
            for (segmentEntryLoop=0; segmentEntryLoop < totalSegments; segmentEntryLoop++)
            {
                tmp = kmalloc(sizeof(struct mCfgNode), GFP_KERNEL);
                if (tmp == NULL)
                {
                    return IOCTL_STATUS_ALLOC_ERROR;
                }
                memset(tmp, 0, sizeof(struct mCfgNode));
                // Setup the linked list, if we don't have a tail it means we don't have a head
                if (tail == NULL)
                    gsMcfg = tmp;
                else
                    tail->next = tmp;
                
                tail = tmp;
                base = cpTable + MCFG_ENTRY_SIZE + (MCFG_SEGMENT_SIZE * segmentEntryLoop); // Base offset to Segment Entry

                tmp->segmentNum   = *(UINT16*)(base + MCFG_SEGMENT); // JPL 5/24/23 - corrected offset to segment Number
                tmp->mcfgBaseLow  = *(UINT32*)(base + MCFG_BASE_LOW);
                tmp->mcfgBaseHigh = *(UINT32*)(base + MCFG_BASE_HIGH);
                tmp->startBus     = *(UINT8*) (base + MCFG_START_BUS);
                tmp->endBus       = *(UINT8*) (base + MCFG_END_BUS);

                // Now let's override as necessary
                if ((inIoctl->command == PCISIG_CMD_OVERRIDE) && (overRide.segmentNum == tmp->segmentNum))
                {
                    if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_STARTBUS)
                        tmp->startBus = overRide.startBus;
                    if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_ENDBUS)
                        tmp->endBus = overRide.endBus;
                    if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASELOW)
                        tmp->mcfgBaseLow = overRide.mcfgBaseLow;
                    if (overRide.bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASEHIGH)
                        tmp->mcfgBaseHigh = overRide.mcfgBaseHigh;
                }
                pr_info( PFX "[%s] mcfgBaseLow = 0x%X mcfgBaseHigh = 0x%X\n", __func__ , tmp->mcfgBaseLow, tmp->mcfgBaseHigh);
                pr_info( PFX "[%s] gsMcfg = 0x%p tail = 0x%p tmp = 0x%p\n", __func__ , gsMcfg, tail, tmp);
                pr_info( PFX "[%s] Reading Segment = 0x%X\n", __func__ , tmp->segmentNum);
                pr_info( PFX "[%s] startBus = 0x%X endBus = 0x%X\n", __func__ , tmp->startBus, tmp->endBus);

#ifdef CONFIG_X86_32
                physAddr = (phys_addr_t) tmp->mcfgBaseLow;
#else
                physAddr = ((phys_addr_t) tmp->mcfgBaseHigh << 32) | tmp->mcfgBaseLow;
#endif
                pr_info( PFX "[%s] ACPI MCFG phys_addr = 0x%llX\n", __func__ , physAddr);
                // Map the MCFG Address from the physical address to a virtual Address
                tmp->pMcfg = ioremap (physAddr, (tmp->endBus - tmp->startBus + 1) * PCISIG_PCI_IO_SIZE * PCISIG_PCI_MCFG_SIZE);
                pr_info( PFX "[%s] tmp->pMcfg = 0x%p\n", __func__ , tmp->pMcfg);
                if (tmp->pMcfg == NULL)
                {
                    pcisig_freeList();
                    return IOCTL_STATUS_IOMAP_ERROR;
                }
            }
        }
        retStatus = IOCTL_STATUS_SUCCESS;
        memcpy(outParam->pciData, acpiTable, acpiTableSize);
        outParam->outNumSegments = totalSegments;
        // Free up the allocated structure from the OS
        acpi_put_table(acpiTable);
    }
    else
    {
        retStatus = IOCTL_STATUS_ACPI_ERROR;
        goto pcisig_getMcfgACPI_end;
    }

pcisig_getMcfgACPI_end:
    return retStatus;
}
#endif

// Initialize the PCI Subsystem
#ifndef _PCISIG_WIN_
UINT32 pcisig_InitPCI(pcisigIoctl* inIoctl, pcisigIoctl* driverOut)
#else
UINT32 pcisig_InitPCI(struct mCfgNode **gsMcfg, pcisigIoctl* inIoctl, pcisigIoctl* driverOut)
#endif
{
    UINT32  retStatus;
    pr_info( PFX "[%s] Initializing the PCI Registers\n", __func__ );

    // Lets get the MCFG address
    // This function populates our linked list
#ifndef _PCISIG_WIN_
    retStatus = pcisig_getMcfgACPI(inIoctl, driverOut, TRUE);
#else
    retStatus = pcisig_getMcfgACPI(gsMcfg, inIoctl, driverOut, TRUE);
#endif
    return retStatus;
}

// Closing the PCI Subsystem
#ifdef _PCISIG_WIN_
UINT32 pcisig_ClosePCI(struct mCfgNode **gsMcfg)
{
    pr_info( PFX "[%s] Closing the PCI Registers\n", __func__ );

    // Free our list
    if (*gsMcfg != NULL)
    {
        pcisig_freeList(gsMcfg);
    }
    return IOCTL_STATUS_SUCCESS;
}
#endif
// In this function, we Read PCI Config Space using MCFG or IO
// If we are passed in the mCfgNode, use it instead of mapping it
// This is primarily used by the generic Memory RW function in order to not
// duplicate code
#ifndef _PCISIG_WIN_
INT32 pcisigReadPCIConfig(BOOLEAN readIO, pcisigIoctl* inoutParam, struct mCfgNode* inNode)
#else
UINT32 pcisigReadPCIConfig(BOOLEAN readIO, struct mCfgNode **gsMcfg, pcisigIoctl* inoutParam, struct mCfgNode* inNode)
#endif
{
    UINT32              addrToReadWrite;
    UINT32              bytestoRW = 0;
    UINT32              accessSize;
    UINT32              retStatus = IOCTL_STATUS_SUCCESS;
    struct mCfgNode*    tmpNode = NULL;
    UINT8               *tmpBuf;
    UINT32              step;

    local_irq_disable();

#if defined (_M_ARM64)
    //Arm64 does not support IOPort access 
    //ASSERT(readIO == FALSE);
    if (readIO)
    {
        retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
        goto pcisigReadPCI_end;
    }
#endif

    if (inNode != NULL)
    {
        tmpNode = inNode;
    }
    else if (readIO == FALSE)
    {
        if (gsMcfg == NULL)
        {
            // Lets get the MCFG address
#ifndef _PCISIG_WIN_
            retStatus = pcisig_getMcfgACPI(inoutParam, inoutParam, TRUE);
#else
            retStatus = pcisig_getMcfgACPI(gsMcfg, inoutParam, inoutParam, TRUE);
#endif
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigReadPCI_end;
            }
        }
#ifndef _PCISIG_WIN_
        tmpNode = pcisig_MapSegmentToMcfg(inoutParam->segment);
#else
        tmpNode = pcisig_MapSegmentToMcfg(*gsMcfg, inoutParam->segment);
#endif
        if (tmpNode == NULL)
        {
            retStatus = IOCTL_STATUS_INVALID_SEGMENT;
            goto pcisigReadPCI_end;
        }

        // On x86 and x64, going past the endBus number just returns 0XFF's.
        // On Arm64, going past the endBus number blows up.
        if (inoutParam->bus > tmpNode->endBus)
        {
            retStatus = IOCTL_STATUS_PCIMCFG_SEGMENT_ERROR;
            goto pcisigReadPCI_end;
        }
    }
    bytestoRW = inoutParam->bufSize;
    accessSize = inoutParam->requestSize;
    addrToReadWrite = 0;
    if (readIO == TRUE)
    {
        addrToReadWrite =   (inoutParam->bus << PCIIO_BUSADDR_OFFSET) | (inoutParam->device << PCIIO_DEVICEADDR_OFFSET)
                            | (inoutParam->function << PCIIO_FUNCADDR_OFFSET) | PCISIG_PCI_ENABLE_BIT;
    }
    else if (inNode == NULL)
    {
        addrToReadWrite = ( (inoutParam->bus - tmpNode->startBus) << MCFG_BUSADDR_OFFSET) | (inoutParam->device << MCFG_DEVICEADDR_OFFSET) | (inoutParam->function << MCFG_FUNCADDR_OFFSET);
    }
    addrToReadWrite += inoutParam->requestOffset;

    //pr_info( PFX    "[%s] bytesToRW = 0x%X, offset = 0x%X, command = 0x%X, accessSize = 0x%X\n", __func__ , bytestoRW,
    //                inoutParam->requestOffset, inoutParam->command, accessSize);

#if defined(_M_ARM64) // Arm64 does not support misaligned access to device memory at all
    if (((accessSize == PCISIG_SIZE_DWORD) && (addrToReadWrite % 4 != 0) ) || ((accessSize == PCISIG_SIZE_WORD) && (addrToReadWrite % 2 != 0) )){ 
	    pr_info( PFX " Forced misaligned access- not supported by Arm at all"   );
	    pr_info( PFX    "[%s] bytesToRW = 0x%X, offset = 0x%X, command = 0x%X, accessSize = 0x%X\n", __func__ , bytestoRW, inoutParam->requestOffset, inoutParam->command, accessSize);
	   //accessSize = PCISIG_SIZE_AUTO;
            retStatus = IOCTL_STATUS_BUF_ERROR;
            goto pcisigReadPCI_end;
    }
#endif
    // Now we need to handle the case of AUTO
    // This means we need to find the most efficient way to read the buffer
    tmpBuf = (UINT8*) inoutParam->pciData;
    while (bytestoRW > 0)
    {
        if ((accessSize == PCISIG_SIZE_DWORD) || ((accessSize == PCISIG_SIZE_AUTO) && (addrToReadWrite % 4 == 0) && (bytestoRW >= 4)))
        {
            step = 4;
            ((UINT32*)tmpBuf)[0] = readIO == FALSE ? pcisig_ReadMemory(PCISIG_MEM_32, (UINT8*)tmpNode->pMcfg, addrToReadWrite) :
                pcisig_ReadConfigIO(PCISIG_IO_32, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET);
        }
#if 0 //covered as part of previos conndtion
        else if ((accessSize == PCISIG_SIZE_DWORD) || ((accessSize == PCISIG_SIZE_AUTO) && (addrToReadWrite % 4 == 0) && (bytestoRW == 4)))
        {
            step = 4;
            if (readIO == FALSE)
            {
                ((UINT32*)tmpBuf)[0] = pcisig_ReadMemory(PCISIG_MEM_32, (UINT8*)tmpNode->pMcfg, addrToReadWrite);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
                pr_info(PFX    "CfgRD %8X=%02X%02X %02X%02X\n",
                    addrToReadWrite, tmpBuf[3], tmpBuf[2], tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
#endif
            }
            else
            {
                ((UINT32*)tmpBuf)[0] = pcisig_ReadConfigIO(PCISIG_IO_32, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET);
            }
        }
#endif
        else if ((accessSize == PCISIG_SIZE_WORD) ||
            ((accessSize == PCISIG_SIZE_AUTO) && ((addrToReadWrite % 2 == 0) && (bytestoRW >= 2)))) // JPL 10/14/22 - Continue to let this be the case, but only for contiguous bytes, so if odd number of bytes only the last byte gets the penalty
        {
            step = 2;
            ((UINT16*)tmpBuf)[0] = readIO == FALSE ? (UINT16)pcisig_ReadMemory(PCISIG_MEM_16, (UINT8*)tmpNode->pMcfg, addrToReadWrite) :
                (UINT16)pcisig_ReadConfigIO(PCISIG_IO_16, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET);
        }
#ifndef _M_ARM64 // Arm64 does not support misaligned access to device memory at all
        else if
            ((accessSize == PCISIG_SIZE_AUTO) && (bytestoRW == 2)) // JPL 10/14/22 - Special case of single Word access where odd byte boundary should be allowed
        {
            step = 2;
            if (readIO == FALSE)
            {
                ((UINT16*)tmpBuf)[0] = (UINT16)pcisig_ReadMemory(PCISIG_MEM_16, (UINT8*)tmpNode->pMcfg, addrToReadWrite);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
                if ((addrToReadWrite % 2) == 0)
                    pr_info(PFX    "CfgRD %8X=%02X%02X\n",
                        addrToReadWrite, tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
                else // Make odd word access standout
                    pr_info(PFX    "CfgRD*%8X=%02X%02X\n",
                        addrToReadWrite, tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
#endif
            }
            else {
                ((UINT16*)tmpBuf)[0] = (UINT16)pcisig_ReadConfigIO(PCISIG_IO_16, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET);
            }
        }
#endif
        else if (addrToReadWrite % 1 == 0) // TODO - huh? Always true
        {
            step = 1;
            ((UINT8*)tmpBuf)[0] = readIO == FALSE ? (UINT8)pcisig_ReadMemory(PCISIG_MEM_8, (UINT8*)tmpNode->pMcfg, addrToReadWrite) :
                (UINT8)pcisig_ReadConfigIO(PCISIG_IO_8, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
            pr_info(PFX    "CfgRD %8X=%02X\n",
                addrToReadWrite, tmpBuf[0]); // 
#endif
        }
        else
        {
            retStatus = IOCTL_STATUS_BUF_ERROR;
            goto pcisigReadPCI_end;
        }
        bytestoRW -= step;
        addrToReadWrite += step;
        tmpBuf += step;
    };
    
pcisigReadPCI_end:
    local_irq_enable();
    return retStatus;
}

// In this function, we Write PCI Config Space using MCFG or IO
// If we are passed in the mCfgNode, use it instead of mapping it
// This is primarily used by the generic Memory RW function in order to not
// duplicate code
#ifndef _PCISIG_WIN_
INT32 pcisigWritePCIConfig(BOOLEAN writeIO, pcisigIoctl* inoutParam, struct mCfgNode* inNode)
#else
UINT32 pcisigWritePCIConfig(BOOLEAN writeIO, struct mCfgNode **gsMcfg, pcisigIoctl* inoutParam, struct mCfgNode* inNode)
#endif
{
    UINT32              addrToReadWrite;
    UINT32              bytestoRW = 0;
    UINT32              accessSize;
    UINT32              retStatus = IOCTL_STATUS_SUCCESS;
    struct mCfgNode*    tmpNode = NULL;
    UINT8               *tmpBuf;
    UINT32              step;


    local_irq_disable();

#if defined (_M_ARM64)
    //Arm64 does not support IOPort access 
    //ASSERT(writeIO == FALSE);
    if (writeIO)
    {
        retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
        goto pcisigWritePCI_end;
    }
#endif

    if (inNode != NULL)
    {
        tmpNode = inNode;
    }
    else if (writeIO == FALSE)
    {
        if (gsMcfg == NULL)
        {
            // Lets get the MCFG address
#ifndef _PCISIG_WIN_
            retStatus = pcisig_getMcfgACPI(inoutParam, inoutParam, TRUE);
#else
            retStatus = pcisig_getMcfgACPI(gsMcfg, inoutParam, inoutParam, TRUE);
#endif
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigWritePCI_end;
            }
        }
#ifndef _PCISIG_WIN_
        tmpNode = pcisig_MapSegmentToMcfg(inoutParam->segment);
#else
        tmpNode = pcisig_MapSegmentToMcfg(*gsMcfg, inoutParam->segment);
#endif
        if (tmpNode == NULL)
        {
            retStatus = IOCTL_STATUS_INVALID_SEGMENT;
            goto pcisigWritePCI_end;
        }

        if (inoutParam->bus > tmpNode->endBus)
        {
            retStatus = IOCTL_STATUS_PCIMCFG_SEGMENT_ERROR;
            goto pcisigWritePCI_end;
        }
    }

    bytestoRW = inoutParam->bufSize;
    accessSize = inoutParam->requestSize;
    addrToReadWrite = 0;
    if (writeIO == TRUE)
    {
        addrToReadWrite =   (inoutParam->bus << PCIIO_BUSADDR_OFFSET) | (inoutParam->device << PCIIO_DEVICEADDR_OFFSET)
                            | (inoutParam->function << PCIIO_FUNCADDR_OFFSET) | PCISIG_PCI_ENABLE_BIT;
    }
    else if (inNode == NULL)
    {
        addrToReadWrite = ( (inoutParam->bus - tmpNode->startBus) << MCFG_BUSADDR_OFFSET) | (inoutParam->device << MCFG_DEVICEADDR_OFFSET) | (inoutParam->function << MCFG_FUNCADDR_OFFSET);
    }
    addrToReadWrite += inoutParam->requestOffset;

    //pr_info( PFX    "[%s] bytesToRW = 0x%X, offset = 0x%X, command = 0x%X, accessSize = 0x%X\n", __func__ , bytestoRW,
    //                inoutParam->requestOffset, inoutParam->command, accessSize);

#if defined(_M_ARM64) // Arm64 does not support misaligned access to device memory at all
    if (((accessSize == PCISIG_SIZE_DWORD) && (addrToReadWrite % 4 != 0) ) || ((accessSize == PCISIG_SIZE_WORD) && (addrToReadWrite % 2 != 0) )){ 
	    pr_info( PFX " Forced misaligned access- not supported by Arm at all- converting to auto"   );
	    pr_info( PFX    "[%s] bytesToRW = 0x%X, offset = 0x%X, command = 0x%X, accessSize = 0x%X\n", __func__ , bytestoRW, inoutParam->requestOffset, inoutParam->command, accessSize);
	   //accessSize = PCISIG_SIZE_AUTO;
            retStatus = IOCTL_STATUS_BUF_ERROR;
            goto pcisigWritePCI_end;
    }
#endif
    // Now we need to handle the case of AUTO
    // This means we need to find the most efficient way to read the buffer
    tmpBuf = (UINT8*) inoutParam->pciData;
    while (bytestoRW > 0)
    {
        if ((accessSize == PCISIG_SIZE_DWORD) || ((accessSize == PCISIG_SIZE_AUTO) && (addrToReadWrite % 4 == 0) && (bytestoRW >= 4)))
        {
            step = 4;
            if (writeIO == FALSE)
            {
                pcisig_WriteMemory(PCISIG_MEM_32, (UINT8*)tmpNode->pMcfg, addrToReadWrite, ((UINT32*)tmpBuf)[0]);
            }
            else
            {
                pcisig_WriteConfigIO(PCISIG_IO_32, addrToReadWrite, 0, ((UINT32*)tmpBuf)[0]);
            }
        }
#if 0 // covered as part of previous condition
        else if ((accessSize == PCISIG_SIZE_DWORD) || ((accessSize == PCISIG_SIZE_AUTO) && (addrToReadWrite % 4 == 0) && (bytestoRW == 4))) // Exactly a DWORD
        {
            step = 4;
            if (writeIO == FALSE)
            {
                pcisig_WriteMemory(PCISIG_MEM_32, (UINT8*)tmpNode->pMcfg, addrToReadWrite, ((UINT32*)tmpBuf)[0]);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
                pr_info(PFX    "CfgWR %8X=%02X%02X %02X%02X\n",
                    addrToReadWrite, tmpBuf[3], tmpBuf[2], tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
#endif
            }
            else
            {
                pcisig_WriteConfigIO(PCISIG_IO_32, addrToReadWrite, 0, ((UINT32*)tmpBuf)[0]);
            }
        }
#endif
        else if ((accessSize == PCISIG_SIZE_WORD) ||
            ((accessSize == PCISIG_SIZE_AUTO) && ((addrToReadWrite % 2 == 0) && (bytestoRW >= 2)))) // JPL 10/14/22 - Continue to let this be the case, but only for contiguous bytes, so if odd number of bytes only the last byte gets the penalty
        {
            step = 2;
            if (writeIO == FALSE)
            {
                pcisig_WriteMemory(PCISIG_MEM_16, (UINT8*)tmpNode->pMcfg, addrToReadWrite, ((UINT16*)tmpBuf)[0]);
            }
            else
            {
                pcisig_WriteConfigIO(PCISIG_IO_16, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET, ((UINT16*)tmpBuf)[0]);
            }
        }
#if !defined(_M_ARM64) // Arm64 does not support misaligned access to device memory at all
        else if ((accessSize == PCISIG_SIZE_AUTO) && (bytestoRW == 2)) // JPL 10/14/22 - Special case of single Word access where odd byte boundary should be allowed
        {
            step = 2;
            if (writeIO == FALSE)
            {
                pcisig_WriteMemory(PCISIG_MEM_16, (UINT8*)tmpNode->pMcfg, addrToReadWrite, ((UINT16*)tmpBuf)[0]);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
                if (addrToReadWrite % 2 == 0)
                    pr_info(PFX    "CfgWR %8X=%02X%02X\n",
                        addrToReadWrite, tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
                else // Make odd word access standout
                    pr_info(PFX    "CfgWR*%8X=%02X%02X\n",  // * highlights the difference with a odd boundary access
                        addrToReadWrite, tmpBuf[1], tmpBuf[0]); // JPL 10/14/22 - Purposely print out as little endian
#endif
            }
            else
            {
                pcisig_WriteConfigIO(PCISIG_IO_16, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET, ((UINT16*)tmpBuf)[0]);
            }
        }
#endif
        else if (addrToReadWrite % 1 == 0) // TODO - huh? Always true if we get here, so don't see the purpose
        {
            step = 1;
            if (writeIO == FALSE)
            {
                pcisig_WriteMemory(PCISIG_MEM_8, (UINT8*)tmpNode->pMcfg, addrToReadWrite, ((UINT8*)tmpBuf)[0]);
#if !defined(_PCISIG_WIN_) && !defined(PCISIG_REL)
                pr_info(PFX    "CfgWR %8X=%02X\n",
                addrToReadWrite, tmpBuf[0]); // 
#endif
            }
            else
            {
                pcisig_WriteConfigIO(PCISIG_IO_8, addrToReadWrite, (UINT8)addrToReadWrite & PCISIG_8BIT_SET, ((UINT8*)tmpBuf)[0]);
            }
        }
        else
        {
            retStatus = IOCTL_STATUS_BUF_ERROR;
            goto pcisigWritePCI_end;
        }
        bytestoRW -= step;
        addrToReadWrite += step;
        tmpBuf += step;
    };
    
pcisigWritePCI_end:
    local_irq_enable();
    return retStatus;
}

// Function to allocate some kernel memory and pass back the physical address
// We check for a special code that tells us to kfree the buffer
#ifndef _PCISIG_WIN_
UINT32 pcisig_TestFunctionMemory(pcisigIoctl* inParam, pcisigIoctl* outParam)
#else
UINT32 pcisig_TestFunctionMemory(PVOID *gtestMem, pcisigIoctl* inParam, pcisigIoctl* outParam)
#endif
{
    UINT32              retStatus = IOCTL_STATUS_SUCCESS;
#ifndef _PCISIG_WIN_
    phys_addr_t         physAddr;
#else
    PHYSICAL_ADDRESS    physAddr;
#endif
    INT32               iLoop;
 
    if (inParam->command == PCISIG_CMD_FREEBUF)
    {
#ifndef _PCISIG_WIN_
        kfree(gtestMem);
        gtestMem = NULL;
#else
        if (*gtestMem != NULL)
        {
            MmFreeNonCachedMemory(*gtestMem, sizeof(char) * PCISIG_PCI_MCFG_SIZE);
            *gtestMem = NULL;
        }
#endif
        goto pcisig_TestFunctionMemory_end;
    }
    
#ifndef _PCISIG_WIN_
    if (gtestMem == NULL)
    {
        gtestMem = kmalloc(sizeof(char) * PCISIG_PCI_MCFG_SIZE, GFP_KERNEL);
        if (gtestMem == NULL)
#else
    if (*gtestMem == NULL)
    {
        *gtestMem = MmAllocateNonCachedMemory(sizeof(char) * PCISIG_PCI_MCFG_SIZE);
        if (*gtestMem == NULL)
#endif
        {
            retStatus = IOCTL_STATUS_BUFALLOC_FAILED;
            goto pcisig_TestFunctionMemory_end;
        }
    }
#ifndef _PCISIG_WIN_
    physAddr = virt_to_phys(gtestMem);
#ifdef CONFIG_X86_32
    outParam->outPhysAddrLow = physAddr & PCISIG_32BIT_SET;
    outParam->outPhysAddrHigh = 0;
#else
    outParam->outPhysAddrLow = physAddr & PCISIG_32BIT_SET;
    outParam->outPhysAddrHigh = physAddr >> 32;
#endif
#else
    physAddr = MmGetPhysicalAddress(*gtestMem);
    outParam->outPhysAddrLow = physAddr.u.LowPart;
    outParam->outPhysAddrHigh = physAddr.u.HighPart;
#endif

    pr_info(PFX "[%s] phys = 0x%X:0x%X\n", __func__, outParam->outPhysAddrHigh, outParam->outPhysAddrLow );

    // Pre-populate the buffer
    for (iLoop=0; iLoop<(PCISIG_PCI_MCFG_SIZE); iLoop++)
    {
#ifndef _PCISIG_WIN_
        ((PCHAR)gtestMem)[iLoop] = iLoop & PCISIG_8BIT_SET;
#else
        ((PCHAR)*gtestMem)[iLoop] = iLoop & PCISIG_8BIT_SET;
#endif
    }

pcisig_TestFunctionMemory_end:
    return retStatus;
}

// Function to Read/Write from Memory Mapped I/O or Regular Memory
// The input is a physical address
UINT32 pcisig_RWMemory(pcisigIoctl* inoutParam)
{
#ifndef _PCISIG_WIN_
    UINT8*              pMappedAddr;
    phys_addr_t         physAddr;
    UINT32              loop;
#else
    PHYSICAL_ADDRESS    physAddr;
#endif
    UINT32              retStatus = IOCTL_STATUS_SUCCESS;
    struct              mCfgNode tmpNode;

    tmpNode.next = NULL;
    tmpNode.pMcfg = NULL;
    // The address we are given needs to be mapped
    
    // First we check if it's memory mapped I/O
    // This will fail if it's not so then we can try getting the virtual address
#ifndef _PCISIG_WIN_
#ifdef CONFIG_X86_32
    physAddr = (phys_addr_t) inoutParam->requestAddrLow;
#else
    physAddr = ((phys_addr_t) inoutParam->requestAddrHigh << 32) | inoutParam->requestAddrLow;
#endif
#else
    physAddr.u.LowPart = inoutParam->requestAddrLow;
    physAddr.u.HighPart = inoutParam->requestAddrHigh;
#endif
    
    pr_info( PFX "[%s] Phys_addr to map = 0x%llX size = %x, offset = %x\n", __func__ , physAddr, inoutParam->bufSize, inoutParam->requestOffset);
#ifndef _PCISIG_WIN_
    if (inoutParam->useMcfg == PCISIG_MAP_TYPE_MMIO)
#endif
    {
#ifndef _PCISIG_WIN_
        tmpNode.pMcfg = ioremap (physAddr, inoutParam->bufSize + inoutParam->requestOffset);
        // Now call into MCFG function to piggyback off it
        if (tmpNode.pMcfg != NULL)
        {
            if (inoutParam->command == PCISIG_CMD_READ)
            {
                retStatus = pcisigReadPCIConfig(FALSE, inoutParam, &tmpNode);
            }
            else
            {
                retStatus = pcisigWritePCIConfig(FALSE, inoutParam, &tmpNode);
            }
            iounmap(tmpNode.pMcfg);
            goto pcisig_RWMemory_end;
        }
#else
        tmpNode.pMcfg = MmMapIoSpace(physAddr, inoutParam->bufSize + inoutParam->requestOffset, MmNonCached);
        // Now call into MCFG function to piggyback off it
        if (tmpNode.pMcfg != NULL)
        {
            if (inoutParam->command == PCISIG_CMD_READ)
            {
                retStatus = pcisigReadPCIConfig(FALSE, NULL, inoutParam, &tmpNode);
            }
            else
            {
                retStatus = pcisigWritePCIConfig(FALSE, NULL, inoutParam, &tmpNode);
            }
            MmUnmapIoSpace(tmpNode.pMcfg, inoutParam->bufSize + inoutParam->requestOffset);
            goto pcisig_RWMemory_end;
        }
#endif
    }
    // If we get to this point, then it's regular memory.  Lets map it and then just read/write from it as normal
#ifndef _PCISIG_WIN_
    else
    {
        pr_info( PFX "[%s] Mapping as not mmio so regular memory\n", __func__);

        // Failed as Memory mapped I/O so lets attempt to get the virtual address
        pMappedAddr = phys_to_virt(physAddr);
        pMappedAddr = pMappedAddr + inoutParam->requestOffset;
        if (pMappedAddr != NULL)
        {
            if (inoutParam->requestSize != PCISIG_SIZE_AUTO)
            {
                if (inoutParam->requestSize == PCISIG_SIZE_BYTE)
                {
                    for (loop = 0; loop < inoutParam->bufSize; loop++)
                    {
                        if (inoutParam->command == PCISIG_CMD_READ)
                            ((UINT8*)inoutParam->pciData)[loop] = (UINT8)*(((UINT8*)pMappedAddr)+loop);
                        else
                            *(((UINT8*)pMappedAddr)+loop) = ((UINT8*) inoutParam->pciData)[loop];
                    }
                }
                else if (inoutParam->requestSize == PCISIG_SIZE_WORD)
                {
                    for (loop = 0; loop < inoutParam->bufSize/PCISIG_SIZE_WORD; loop++)
                    {
                        if (inoutParam->command == PCISIG_CMD_READ)
                            ((UINT16*)inoutParam->pciData)[loop] = (UINT16)*(((UINT16*)pMappedAddr)+loop);
                        else
                            *(((UINT16*)pMappedAddr)+loop) = ((UINT16*) inoutParam->pciData)[loop];
                    }
                }
                else if (inoutParam->requestSize == PCISIG_SIZE_DWORD)
                {
                    for (loop = 0; loop < inoutParam->bufSize/PCISIG_SIZE_DWORD; loop++)
                    {
                        if (inoutParam->command == PCISIG_CMD_READ)
                            ((UINT32*)inoutParam->pciData)[loop] = (UINT32)*(((UINT32*)pMappedAddr)+loop);
                        else
                            *(((UINT32*)pMappedAddr)+loop) = ((UINT32*) inoutParam->pciData)[loop];
                    }
                }
            }
            else
            {
                if (inoutParam->command == PCISIG_CMD_READ)
                {
                    memcpy(inoutParam->pciData, pMappedAddr, inoutParam->bufSize);
                }
                else
                {
                    memcpy(pMappedAddr, inoutParam->pciData, inoutParam->bufSize);
                }
            }
            retStatus = IOCTL_STATUS_SUCCESS;
            goto pcisig_RWMemory_end;
        }
        retStatus = IOCTL_STATUS_PHYSTOVIRT_ERROR;
    }
#endif
pcisig_RWMemory_end:
    return retStatus;
}




