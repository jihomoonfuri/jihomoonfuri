/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_library.c
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#ifndef _PCISIG_WIN_
// Linux
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <memory.h>
#include <malloc.h>
#include <libgen.h>
#include <errno.h>
#include <fcntl.h>
#ifdef _PCISIG_SEM_
#include <semaphore.h>
#endif
#include <asm/types.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/hdreg.h>
#include <linux/if.h>
#include <sys/time.h>
#include "pcisig_common.h"
#include "pcisiglib_interface.h"
#else
// Windows
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <malloc.h>
#if MSVC_TOOLSET_VERSION < 142
#define __func__ __FUNCTION__
#else
#include <synchapi.h>
#endif
#include <time.h>
#include "pcisig_common.h"
#include "pcisiglib_interface.h"
#endif

#ifndef _PCISIG_WIN_
// Linux version
#define PCISIG_LIB_VERSION 0x0142
#else
// Windows version
#define PCISIG_LIB_VERSION 0x0142
#endif

// Globals
// Linux & Windows
pcisigIoctl inIoctl;
static FILE*    gDebugFile = NULL;
static UINT8    gLogLevelAccept = 0;

#ifdef _PCISIG_SEM_
sem_t*   gSemId = 0;
#endif

// Used to store the physical memory allocated for testing
UINT32   gMemPhysAddrLow = 0;
UINT32   gMemPhysAddrHigh = 0;
static const char *logLevelString[] = {
  "Err", "Dbg", "", "Inf", "", "", "ALL"
};
struct timeval   gstartTime, glastTime;
UINT8            gTimeStampFormat = 0;

extern INT32 pcisigSendIOCTL(deviceData* devHandle, INT32 command, pcisigIoctl* ioctl);

#ifdef _PCISIG_WIN_
// Windows Only
extern int gettimeofday(struct timeval * tp, struct timezone * tzp);
#define DECLDIR __declspec(dllexport)

# define timersub(a, b, result)                                                      \
      do {                                                                              \
        (result)->tv_sec = (a)->tv_sec - (b)->tv_sec;                              \
        (result)->tv_usec = (a)->tv_usec - (b)->tv_usec;                              \
        if ((result)->tv_usec < 0) {                                              \
          --(result)->tv_sec;                                                      \
          (result)->tv_usec += 1000000;                                              \
        }                                                                              \
      } while (0)

#endif

// Initialize the logging subsystem
// Note: Only the 1st Person attaching can set the basic log framework
void pcisigLoggingInit(UINT8 logLevelAccept, PCHAR filename, UINT8 logTimestampFormat)
{
    if (filename != NULL)
    {
#ifndef _PCISIG_WIN_
        gDebugFile = fopen(filename, "w");
#else
        fopen_s(&gDebugFile, filename, "w");
#endif
    }
    gLogLevelAccept = logLevelAccept;
    gTimeStampFormat = logTimestampFormat;
    return;
}

// Once all the attached processes finish, we shut down the logging subsystem
void pcisigLoggingFinish(void)
{
    if (gDebugFile != NULL)
    {
        fclose(gDebugFile);
        gDebugFile = NULL;
    }
    gLogLevelAccept = 0;
}

// Actual logging mechanism
// We expect the function name, a log level and the actual log message
// The logLevel is set by the first person to attach along with the decision to use a file
void pcisigLog(UINT8 logLevel, const PCHAR function, const PCHAR message, ...)
{
    va_list args;
    struct timeval currentTime, tmpTime;

    if (logLevel & gLogLevelAccept)
    {
        char tmpBuf[4096];
        gettimeofday(&currentTime, NULL);

        if (gTimeStampFormat == PCISIG_TIMESTAMP_ABSOLUTE)
        {
            timersub(&currentTime, &gstartTime, &tmpTime);
        }
        else
        {
            timersub(&currentTime, &glastTime, &tmpTime);
            gettimeofday(&glastTime, NULL);
        }
#ifndef _PCISIG_WIN_
        sprintf(tmpBuf, "%05ld:%06ld %s[%s] ", tmpTime.tv_sec & 0xFFFF, tmpTime.tv_usec, logLevelString[logLevel-1], function);
#else
        sprintf_s(tmpBuf, 4096, "%05ld:%06ld %s[%s] ", tmpTime.tv_sec & 0xFFFF, tmpTime.tv_usec, logLevelString[logLevel-1], function);
#endif
        va_start(args, message);
        if (gDebugFile)
        {
            fprintf(gDebugFile, "%s", tmpBuf);
            vfprintf(gDebugFile, message, args);
            fflush(gDebugFile);
        }
        else
        {
            fprintf(stdout, "%s", tmpBuf);
            vfprintf(stdout, message, args);
            fflush(stdout);
        }
        va_end(args);
    }
}

void pcisigFreeList(struct mCfgNodeLib* pcinode)
{
    // Lets free up all the nodes on the linked list
    struct mCfgNodeLib* tmp;
    
    pcisigLog(PCISIGLOG_INFO, __func__, "Freeing list.\n");
    while (pcinode != NULL)
    {
        tmp = pcinode;
        pcinode = pcinode->next;
        free(tmp);
    }
    return;
}

// Get the Library and Driver versions
UINT32 pcisigGetVersionInfo(deviceData* devHandle, UINT32 *pLibVer, UINT32 *pDrvVer)
{
    UINT32 retStatus = 0;
    
    // Check for valid variables
    if ((pLibVer == NULL) || (pDrvVer == NULL))
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "pLibVer or pDrvVer is NULL!\n");
        return IOCTL_STATUS_NOTFOUND;
    }
  
    *pLibVer = PCISIG_LIB_VERSION;
    
    // Call the driver in order to get the correct version
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_GET_DRV_VERSION, &inIoctl);
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        *pDrvVer = inIoctl.outReturnData;
        pcisigLog(PCISIGLOG_INFO, __func__, "LibVer = 0x%x, DrvVer = 0x%x\n", *pLibVer, *pDrvVer);
    }
    return retStatus;
}


// Function gets the MCFG Address from the Driver
// Returns the complete MCFG ACPI Table in the Buffer
DECLDIR UINT32 pcisigGetMCFGAddr(deviceData* devHandle, PCHAR buf)
{
    UINT32  retStatus;
    
    // Check the input Parameters
    if (buf == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    // Call the driver in order to get the correct version
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, calling the IOCTL\n");
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_GET_MCFG, &inIoctl);
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        // Copy out the MCFG structure
        memcpy(buf, inIoctl.pciData, PCISIG_PCI_MCFG_SIZE);
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
    return retStatus;
}


// Read from an I/O Port
DECLDIR INT32 pcisigReadIO(deviceData* devHandle, UINT32 dataSize, UINT32 readAddress, UINT32 *data)
{
    UINT32  retStatus;
#if defined (_M_ARM64)
    retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
    goto pcisigReadIO_end;
#endif

    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function\n");
    // Zero out the IOCTL
  //  memset (&inIoctl, 0, sizeof(pcisigIoctl));
    // Validate the parameters
    if (data == NULL)
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "data pointer is NULL\n");
        return IOCTL_STATUS_BUF_ERROR;
    }
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    pcisigLog(PCISIGLOG_INFO, __func__, "dataSize 0x%x\n", dataSize);

    switch (dataSize)
    {
        case PCISIG_IO_SIZE_8:
            inIoctl.requestSize = PCISIG_IO_8;
            break;
        case PCISIG_IO_SIZE_16:
            inIoctl.requestSize = PCISIG_IO_16;
            break;
        case PCISIG_IO_SIZE_32:
            inIoctl.requestSize = PCISIG_IO_32;
            break;
        default:
            return IOCTL_STATUS_BUF_SIZE_ERROR;
    }
    inIoctl.requestAddrLow = readAddress;
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_READ_IO, &inIoctl);
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        pcisigLog(PCISIGLOG_INFO, __func__, "Returned valid data = 0x%x\n", inIoctl.outReturnData);
        *data = inIoctl.outReturnData;
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
pcisigReadIO_end:
    return retStatus;
}

// Write to an I/O Port
DECLDIR INT32 pcisigWriteIO(deviceData* devHandle, UINT32 dataSize, UINT32 writeAddress, UINT32 data)
{
    UINT32  retStatus;
#if defined (_M_ARM64)
    retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
    goto pcisigWriteIO_end;
#endif

    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function\n");
    // Zero out the IOCTL
  //  memset (&inIoctl, 0, sizeof(pcisigIoctl));
    // Validate the parameters
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    pcisigLog(PCISIGLOG_INFO, __func__, "dataSize 0x%x, data 0x%x\n", dataSize, data);
    switch (dataSize)
    {
        case PCISIG_IO_SIZE_8:
            inIoctl.requestSize = PCISIG_IO_8;
            break;
        case PCISIG_IO_SIZE_16:
            inIoctl.requestSize = PCISIG_IO_16;
            break;
        case PCISIG_IO_SIZE_32:
            inIoctl.requestSize = PCISIG_IO_32;
            break;
        default:
            return IOCTL_STATUS_BUF_SIZE_ERROR;
    }
    inIoctl.requestAddrLow = writeAddress;
    inIoctl.inputData = data;
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_WRITE_IO, &inIoctl);
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
pcisigWriteIO_end:
    return retStatus;
}

// Walk the PCI Bus using the legacy I/O (CFC/CF8)
DECLDIR INT32 pcisigLibWalkPCIBusLegacy(deviceData* devHandle, pciDevice* arrayDevices, UINT32 numTotal,
                                 UINT32 *retDevices, UINT8 startBus, UINT8 lastBus)
{
    UINT8       bus=0, device=0, function=0;
    UINT32      tmpVendor = 0;
    INT32       retStatus = IOCTL_STATUS_SUCCESS;
#if defined (_M_ARM64)
    retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
    goto pcisigLibWalkPCIBusLegacy_end;
#endif
    // Accepts an array of pciDevice structures, we will use this to fill in the device data
    // The User can then call back into the Library with a specific b:d:f to get more information
    // Our max array size is 512 (defined in pcisig_common.h)
    if (numTotal > PCISIG_MAX_PCI_DEVICES)
    {
        retStatus = IOCTL_PARAMETER_ERROR_ARRAY_SIZE;
        goto pcisigLibWalkPCIBusLegacy_end;
    }
    if (devHandle->pcinode->segmentNum != 0)
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "segmentNum = %d invalid for Legacy I/O access method\n", devHandle->pcinode->segmentNum);
        retStatus = IOCTL_STATUS_PCIMCFG_SEGMENT_ERROR;
        goto pcisigLibWalkPCIBusLegacy_end;
    }
    if ((startBus < devHandle->pcinode->startBus) || (lastBus > devHandle->pcinode->endBus))
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "startBus or EndBus invalid, returning 0\n");
        retStatus = IOCTL_PARAMETER_ERROR_BUS_LIMIT;
        goto pcisigLibWalkPCIBusLegacy_end;
    }
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, about to iterate all devices until Bus 0x%X\n", lastBus);

    *retDevices = 0;
    bus = startBus;
    // Lets start with B:D:F of 0:0:0 then iterate
    while(bus <= lastBus)
    {
        while (device <= PCI_LASTDEVICE)
        {
            while (function <= PCI_LASTFUNCTION)
            {
                // Read the first 4 Bytes to see if we have a valid Device
                retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO,
                                                    (PCHAR)&tmpVendor, PCISIG_PCI_VENDOR_OFFSET, PCISIG_SIZE_BAR);
                if (retStatus != IOCTL_STATUS_SUCCESS)
                {
                    pcisigLog(PCISIGLOG_ERROR, __func__, "Reading Config Space error = 0x%X. Returning 0 devices\n", retStatus);
                    *retDevices = 0;
                    retStatus = IOCTL_STATUS_ERROR_READ_CONFIG;
                    goto pcisigLibWalkPCIBusLegacy_end;
                }
                if (!(tmpVendor == 0xffffffff || tmpVendor == 0x00000000 || tmpVendor == 0x0000ffff || tmpVendor == 0xffff0000))
                {
                    pcisigLog(PCISIGLOG_INFO, __func__, "Found b:d:f = %X:%X:%X\n",bus, device, function);
                    // Store this in our array
                    arrayDevices[*retDevices].bus = bus;
                    arrayDevices[*retDevices].device = device;
                    arrayDevices[*retDevices].function = function;
                    arrayDevices[*retDevices].vendorId = (0xFFFF & tmpVendor);
                    arrayDevices[*retDevices].deviceId = (0xFFFF0000 & tmpVendor) >> 16;
                    (*retDevices)++;
                }
                function++;
            }
        device++;
        function = 0;
        }
        if (bus == PCI_LASTBUS)
        {
            break;
        }
        bus++;
        device = 0;
        function = 0;
    }
pcisigLibWalkPCIBusLegacy_end:
    return retStatus;
}


// Walk the PCI Bus using the ACPI MCFG Register
DECLDIR INT32 pcisigWalkPCIBusMcfg(deviceData* devHandle, UINT16 segment, pciDevice* arrayDevices, UINT32 numTotal,
                           UINT32 *retDevices, UINT8 startBus, UINT8 lastBus)
{
    UINT8       bus=0, device=0, function=0;
    UINT32      tmpVendor;
    INT32       retStatus = IOCTL_STATUS_SUCCESS;

    // Accepts an array of pciDevice structures, we will use this to fill in the device data
    // The User can then call back into the Library with a specific b:d:f to get more information
    // Our max array size is 512 (defined in pcisig_common.h)
    if (numTotal > PCISIG_MAX_PCI_DEVICES)
    {
        retStatus = IOCTL_PARAMETER_ERROR_ARRAY_SIZE;
        goto pcisigWalkPCIBusMcfg_end;
    }
    if ((startBus < devHandle->pcinode->startBus) || (lastBus > devHandle->pcinode->endBus))
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "startBus or EndBus invalid, returning 0\n");
        retStatus = IOCTL_PARAMETER_ERROR_BUS_LIMIT;
        goto pcisigWalkPCIBusMcfg_end;
    }
    
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, about to iterate all devices until Bus 0x%X\n", lastBus);

    *retDevices = 0;
    bus = startBus;
    // Lets start with S:B:D:F of S:0:0:0 then iterate
    while(bus <= lastBus)
    {
        while (device <= PCI_LASTDEVICE)
        {
            while (function <= PCI_LASTFUNCTION)
            {
                // Read the first 4 Bytes to see if we have a valid Device
                retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                                      PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&tmpVendor, PCISIG_PCI_VENDOR_OFFSET, PCISIG_SIZE_BAR);
                if (retStatus == IOCTL_STATUS_SUCCESS) {
                    if (!(tmpVendor == PCISIG_32BIT_SET || tmpVendor == PCISIG_32BIT_UNSET || tmpVendor == PCISIG_32BIT_LOWER16SET || tmpVendor == PCISIG_32BIT_UPPER16SET))
                    {
                        pcisigLog(PCISIGLOG_INFO, __func__, "Found s:b:d:f = %X:%X:%X:%X\n", segment, bus, device, function);
                        // Store this in our array
                        arrayDevices[*retDevices].segment = segment;
                        arrayDevices[*retDevices].bus = bus;
                        arrayDevices[*retDevices].device = device;
                        arrayDevices[*retDevices].function = function;
                        arrayDevices[*retDevices].vendorId = (PCISIG_32BIT_LOWER16SET & tmpVendor);
                        arrayDevices[*retDevices].deviceId = (PCISIG_32BIT_UPPER16SET & tmpVendor) >> 16;
                        (*retDevices)++;
                    }
                }
                else
                    pcisigLog(PCISIGLOG_ERROR, __func__, "%04X:%02X:%02X:%1X Cfg Rd Error = 0x%X \n", segment, bus, device, function, retStatus);
                function++;
            }
        device++;
        function = 0;
        }
        if (bus == PCI_LASTBUS)
        {
            break;
        }
        bus++;
        device = 0;
        function = 0;
    }
    
pcisigWalkPCIBusMcfg_end:
    return retStatus;
}

// Function to allocate physical memory for RW testing

INT32 pcisigAllocTestMemory(deviceData* devHandle, UINT32 command, UINT32 *PhysAddressLow,  UINT32 *PhysAddressHigh)
{
    INT32 retStatus = IOCTL_STATUS_SUCCESS;

    if ((command != PCISIG_CMD_ALLOCBUF) && (command != PCISIG_CMD_FREEBUF))
    {
        return IOCTL_PARAMETER_ERROR_COMMAND;
    }
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, calling the IOCTL\n");

    // Zero out the IOCTL Structure
//    memset (&inIoctl, 0, sizeof(pcisigIoctl));
   
    inIoctl.command = command;

    // Call the driver in order to get the physical address, or free the buffer
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_TEST_MEM, &inIoctl);
    pcisigLog(PCISIGLOG_INFO, __func__, "pcisigSendIOCTL status = 0x%x\n", retStatus);

    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        *PhysAddressLow = inIoctl.outPhysAddrLow;
        *PhysAddressHigh = inIoctl.outPhysAddrHigh;
    }
    return retStatus;
}

// Function to read/write from memory
INT32 pcisigRWMemory(   deviceData* devHandle, UINT32 command, UINT32 bufSize, UINT32 rwSize, UINT32 memType,
                        UINT32 RWAddressLow, UINT32 RWAddressHigh, PCHAR retBuffer, UINT32 startOffset)
{
    INT32           retStatus = IOCTL_STATUS_SUCCESS;

    // Verify the input Parameters
    if (retBuffer == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
    if ((command != PCISIG_CMD_READ) && (command != PCISIG_CMD_WRITE))
    {
        return IOCTL_PARAMETER_ERROR_COMMAND;
    }
    if ((rwSize != PCISIG_SIZE_AUTO) && (rwSize != PCISIG_SIZE_BYTE) && (rwSize != PCISIG_SIZE_WORD) && (rwSize != PCISIG_SIZE_DWORD))
    {
        return IOCTL_PARAMETER_ERROR_RW_SIZE;
    }
    // Check the boundary cases
    if ((rwSize == PCISIG_SIZE_WORD) && (bufSize % 2 != 0) && (startOffset % 2 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
    if ((rwSize == PCISIG_SIZE_DWORD) && (bufSize % 4 != 0) && (startOffset % 4 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
    if ((memType != PCISIG_MAP_TYPE_MMIO) && (memType != PCISIG_MAP_TYPE_MEM))
    {
        return IOCTL_PARAMETER_ERROR_MEMTYPE;
    }
    if ((RWAddressLow & PAGE_MASK) > 0)
    {
        return IOCTL_PARAMETER_ERROR_INPUTBOUNDARY;
    }
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, calling the IOCTL\n");

    // Zero out the IOCTL Structure
//    memset (&inIoctl, 0, sizeof(pcisigIoctl));
   
    inIoctl.bufSize = bufSize;
    inIoctl.command = command;
    inIoctl.requestAddrLow = RWAddressLow;         // Lower 32 bits of the Physical Address
    inIoctl.requestAddrHigh = RWAddressHigh;    // Upper 32 bits of the Physical Address
    inIoctl.requestSize = rwSize;
    inIoctl.useMcfg = memType;
    inIoctl.requestOffset = startOffset;
    
    pcisigLog(PCISIGLOG_INFO, __func__, "bufSize = %x, command = %x\n", inIoctl.bufSize, inIoctl.command);

    if (command == PCISIG_CMD_WRITE)
    {
        memcpy((PCHAR)inIoctl.pciData, retBuffer, bufSize);
    }
    
    // Call the driver in order to get the correct version
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_RW_MEM_ADDR, &inIoctl);
    pcisigLog(PCISIGLOG_INFO, __func__, "pcisigSendIOCTL status = 0x%x\n", retStatus);

    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        if (command == PCISIG_CMD_READ)
        {
            // If we have success, then copy back our buffer that was read
            memcpy(retBuffer, (PCHAR) inIoctl.pciData, bufSize);
        }
    }
    else
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "IOCTL Failure status = 0x%x\n", retStatus);

    }
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        char    outString[4096*3+2];
		int		iLoop;
        
        for (iLoop=0; iLoop<(int)bufSize; iLoop++)
        {
#ifndef _PCISIG_WIN_
            sprintf(&outString[iLoop*3], "%02X ", retBuffer[iLoop] & 0xFF);
#else
            sprintf_s(&outString[iLoop*3], sizeof(char)*((4096-iLoop)*3+2), "%02X ", retBuffer[iLoop] & 0xFF);
#endif
        }
        //outString[bufSize*3] = '\0';
        // This will print out the result as consise as possible
        if (command == PCISIG_CMD_READ)
        {
            pcisigLog(PCISIGLOG_DEBUG, "MR", "[%X:%X@%X] = %s\n", RWAddressHigh, RWAddressLow, startOffset, outString);
        }
        else
        {
            pcisigLog(PCISIGLOG_DEBUG, "MW", "[%X:%X@%X] = %s\n", RWAddressHigh, RWAddressLow, startOffset, outString);
        }
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
    return retStatus;
}

// Function to Get or Set data in PCI Config Space using the MCFG Register
INT32 pcisigGetSetPciConfigMcfg(    deviceData* devHandle, UINT16 segment, UINT8 bus, UINT8 device, UINT8 function,
                                    UINT32 command, UINT32 rwSize, PCHAR retBuffer, UINT32 startOffset, UINT32 bufSize)
{
    INT32 retStatus = IOCTL_STATUS_SUCCESS;

    // Verify the input Parameters
    // We can't access outside PCISIG_PCI_MCFG_SIZE using the MCFG Register
    if (((bufSize+startOffset) > PCISIG_PCI_MCFG_SIZE) || retBuffer == NULL)
    {
        return IOCTL_STATUS_PCIMCFG_SIZE_ERROR;
    }
    if ((segment > PCI_LAST_SEGMENT) || (bus > PCI_LASTBUS) || (device > PCI_LASTDEVICE) || (function > PCI_LASTFUNCTION))
    {
        return IOCTL_PARAMETER_ERROR_SBDF;
    }
    if ((command != PCISIG_CMD_READ) && (command != PCISIG_CMD_WRITE))
    {
        return IOCTL_PARAMETER_ERROR_COMMAND;
    }
    // JPL 10/12/22 - No need to be so restrictive on checking rwSize as misaligned accesses should be allowed and handle by IOctl directly
    //if ((rwSize != PCISIG_SIZE_AUTO) && (rwSize != PCISIG_SIZE_BYTE) && (rwSize != PCISIG_SIZE_WORD) && (rwSize != PCISIG_SIZE_DWORD))
    //{
    //    return IOCTL_PARAMETER_ERROR_RW_SIZE;
    //}
    //// Check the boundary cases
    //if ((rwSize == PCISIG_SIZE_WORD) && (bufSize % 2 != 0) && (startOffset % 2 != 0))
    //{
    //    return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    //}
    //if ((rwSize == PCISIG_SIZE_DWORD) && (bufSize % 4 != 0) && (startOffset % 4 != 0))
    //{
    //    return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    //}
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, calling the IOCTL\n");

    // Zero out the IOCTL Structure
//    memset (&inIoctl, 0, sizeof(pcisigIoctl));
   
    inIoctl.segment = segment;
    inIoctl.bus = bus;
    inIoctl.device = device;
    inIoctl.function = function;
    inIoctl.bufSize = bufSize;
    inIoctl.requestOffset = startOffset;
    inIoctl.command = command;
    inIoctl.requestSize = rwSize;
    pcisigLog(PCISIGLOG_INFO, __func__, "bufSize = %x, startOffset = %x, command = %x rwSize = %x\n", bufSize, startOffset, command, rwSize);

    if (command == PCISIG_CMD_WRITE)
    {
        memcpy((PCHAR)inIoctl.pciData, retBuffer, bufSize);
    }
    
    // Call the driver in order to get the correct version
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_GETSET_PCI_CONFIG_MCFG, &inIoctl);
    pcisigLog(PCISIGLOG_INFO, __func__, "pcisigSendIOCTL status = 0x%x\n", retStatus);

    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        if (command == PCISIG_CMD_READ)
        {
            memcpy(retBuffer, (PCHAR) inIoctl.pciData, bufSize);
        }
    }
    else
    {
        inIoctl.segment = segment;
        inIoctl.bus = bus;
        inIoctl.device = device;
        inIoctl.function = function;
        inIoctl.bufSize = bufSize;
        inIoctl.requestOffset = startOffset;
        inIoctl.command = command;
        inIoctl.requestSize = rwSize;

        pcisigLog(PCISIGLOG_ERROR, __func__, "[%X:%X:%X:%X@%X] bufsize=%d rwSize=%d cmd=%X IOCTL = 0x%X; \n", segment, bus, device, function, startOffset, bufSize, rwSize, command, retStatus);

    }
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        char    outString[4096*3+2];
		int		iLoop;
        
        for (iLoop=0; iLoop<(int)bufSize; iLoop++)
        {
#ifndef _PCISIG_WIN_
            sprintf(&outString[iLoop*3], "%02X ", retBuffer[iLoop] & 0xFF);
#else
            sprintf_s(&outString[iLoop*3], sizeof(char)*((4096-iLoop)*3+2), "%02X ", retBuffer[iLoop] & 0xFF);
#endif
        }
        //outString[bufSize*3] = '\0';
        // This will print out the result as consise as possible
        if (command == PCISIG_CMD_READ)
        {
            pcisigLog(PCISIGLOG_DEBUG, "CMR", "[%X:%X:%X:%X@%X] = %s\n", segment, bus, device, function, startOffset, outString);
        }
        else
        {
            pcisigLog(PCISIGLOG_DEBUG, "CMW", "[%X:%X:%X:%X@%X] = %s\n", segment, bus, device, function, startOffset, outString);
        }
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
    return retStatus;
}


// Function to Get or Set data in PCI Config Space using the Port IO Register
INT32 pcisigGetSetPciConfigIO(deviceData* devHandle, UINT8 bus, UINT8 device, UINT8 function, UINT32 command,
                              UINT32 rwSize, PCHAR retBuffer, UINT32 startOffset, UINT32 bufSize)
{
    INT32 retStatus = 0;
    pcisigLog(PCISIGLOG_INFO, __func__, "Bus 0x%X, Device 0x%X, function 0x%x\n", bus, device, function);
#if defined (_M_ARM64)
    retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
    goto pcisigGetSetPciConfigIO_end;
#endif
    // Verify the input parameters
    // We can't access outside PCISIG_PCI_IO_SIZE using the I/O registers
    if (((bufSize+startOffset) > PCISIG_PCI_IO_SIZE) || (retBuffer == NULL))
    {
        return IOCTL_STATUS_PCIIO_SIZE_ERROR;
    }
    if ((bus > PCI_LASTBUS) || (device > PCI_LASTDEVICE) || (function > PCI_LASTFUNCTION))
    {
        return IOCTL_PARAMETER_ERROR_SBDF;
    }
    if ((command != PCISIG_CMD_READ) && (command != PCISIG_CMD_WRITE))
    {
        return IOCTL_PARAMETER_ERROR_COMMAND;
    }
    if ((rwSize != PCISIG_SIZE_AUTO) && (rwSize != PCISIG_SIZE_BYTE) && (rwSize != PCISIG_SIZE_WORD) && (rwSize != PCISIG_SIZE_DWORD))
    {
        return IOCTL_PARAMETER_ERROR_RW_SIZE;
    }
    // Check the boundary cases
    if ((rwSize == PCISIG_SIZE_WORD) && (bufSize % 2 != 0) && (startOffset % 2 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
    if ((rwSize == PCISIG_SIZE_DWORD) && (bufSize % 4 != 0) && (startOffset % 4 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
#ifdef _PCISIG_SEM_
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function, calling the IOCTL using rwSize=0x%X\t", rwSize);

    // Zero out the IOCTL Structure
//    memset (&inIoctl, 0, sizeof(pcisigIoctl));
   
    inIoctl.bus = bus;
    inIoctl.device = device;
    inIoctl.function = function;
    inIoctl.bufSize = bufSize;
    inIoctl.requestOffset = startOffset;
    inIoctl.command = command;
    inIoctl.requestSize = rwSize;
    pcisigLog(PCISIGLOG_INFO, __func__, "bufSize = %x, startOffset = %x rwSize = %x\n", bufSize, startOffset, inIoctl.requestSize);

    if (command == PCISIG_CMD_WRITE)
    {
        memcpy((PCHAR)inIoctl.pciData, retBuffer, bufSize);
    }
    
    // Call the driver in order to get the correct version
    retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_GETSET_PCI_CONFIG_IO, &inIoctl);
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        if (command == PCISIG_CMD_READ)
        {
            memcpy(retBuffer, (PCHAR) inIoctl.pciData, bufSize);
        }
    }
    else
        pcisigLog(PCISIGLOG_ERROR, __func__, "[%X:%X:%X@%X] bufsize=%d rwSize=%d cmd=%X IOCTL = 0x%X; \n", bus, device, function, startOffset, bufSize, rwSize, command, retStatus);

    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        char    outString[4096*3+2];
		int		iLoop;
        
        for (iLoop=0; iLoop<(int)bufSize; iLoop++)
        {
#ifndef _PCISIG_WIN_
            sprintf(&outString[iLoop*3], "%02X ", retBuffer[iLoop] & 0xFF);
#else
            sprintf_s(&outString[iLoop*3], sizeof(char)*((4096-iLoop)*3+2), "%02X ", retBuffer[iLoop] & 0xFF);
#endif
        }
        //outString[bufSize*3] = '\0';
        // This will print out the result as concise as possible
        if (command == PCISIG_CMD_READ)
        {
            pcisigLog(PCISIGLOG_DEBUG, "CIR", "[%X:%X:%X@%X] = %s\n", bus, device, function, startOffset, outString);
        }
        else
        {
            pcisigLog(PCISIGLOG_DEBUG, "CIW", "[%X:%X:%X@%X] = %s\n", bus, device, function, startOffset, outString);
        }
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
pcisigGetSetPciConfigIO_end:
    return retStatus;
}


// Function to Size the BARS for a particular S:B:D:F
// If we are using I/O, then we ignore the segment
DECLDIR INT32 pcisigSizeBar(deviceData* devHandle, UINT16 segment, UINT8 bus, UINT8 device, UINT8 function, BOOLEAN bBridgeDevice, BOOLEAN bUseMcfg,
    PCHAR retBuffer, UINT32 bufSize)
{
    INT32           retStatus = IOCTL_STATUS_SUCCESS;
    INT32           maxBufSize = 0;
    UINT32          oldBarValue;
    UINT32          tmpSizeValue;
    UINT32* tmpDWORDBuf;
    UINT32          loop;
    UINT32          numBars;

#if defined (_M_ARM64)
    if (!bUseMcfg)
    {
        retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
        goto pcisigSizeBar_end;
    }
#endif
    // Verify the input Parameters
    if ((segment > PCI_LAST_SEGMENT) || (bus > PCI_LASTBUS) || (device > PCI_LASTDEVICE) || (function > PCI_LASTFUNCTION))
    {
        return IOCTL_PARAMETER_ERROR_SBDF;
    }
    // Calculate the maximum buffer size
    if (bBridgeDevice == TRUE)
    {
        maxBufSize = (sizeof(char) * PCISIG_NUM_BARS_BRIDGE * PCISIG_SIZE_BAR);  // 2 Bars, 4 Bytes Each
    }
    else
    {
        maxBufSize = (sizeof(char) * PCISIG_NUM_BARS * PCISIG_SIZE_BAR);  // 6 Bars, 4 Bytes Each
    }
    if (bufSize != maxBufSize)  // Size must match exactly
    {
        return IOCTL_STATUS_BUF_SIZE_ERROR;
    }
    
    // Note: We assume that retBuffer is at least 4096 bytes
    pcisigLog(PCISIGLOG_INFO, __func__, "Entering function\n");

    // New Code
    tmpDWORDBuf = (UINT32*) retBuffer;
    if (bUseMcfg != TRUE)
    {
        // We will use standard I/O Access to the Bars
        // Loop and read all the bars
        numBars = bufSize / PCISIG_SIZE_BAR;   // 4 Bytes per BAR
        
        for (loop=0; loop<numBars; loop++)
        {
            // Read the oldBarValue
            retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO,
                                            (PCHAR)&oldBarValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            // Write 0xFFFFFFFF
            tmpSizeValue = 0xFFFFFFFF;
            retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO,
                                            (PCHAR)&tmpSizeValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            // Read the Bar
            retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO,
                                            (PCHAR)&tmpSizeValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            tmpSizeValue &= 0xFFFFFFF0; // Clear out the last 4 bits
            tmpSizeValue = ~tmpSizeValue; // Invert all the bits
            tmpSizeValue += 1; // Add 1, which gives us our final Bar Size
            tmpDWORDBuf[loop] = tmpSizeValue;
            // Write back the original bar
            tmpSizeValue = 0xFFFFFFFF;
            retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO,
                                            (PCHAR)&oldBarValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
        }
    }
    else
    {
        // We will use MMIO Access to the Bars with and without trying to optimize Cfg access
        // Loop and read all the bars
        numBars = bufSize / PCISIG_SIZE_BAR;   // 4 Bytes per BAR
        
        for (loop=0; loop<numBars; loop++)
        {
            // Read the oldBarValue
            retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO,
                                            (PCHAR)&oldBarValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            // Write 0xFFFFFFFF
            tmpSizeValue = 0xFFFFFFFF;
            retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO,
                                            (PCHAR)&tmpSizeValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            // Read the Bar
            retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO,
                                            (PCHAR)&tmpSizeValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }
            tmpSizeValue &= 0xFFFFFFF0; // Clear out the last 4 bits
            tmpSizeValue = ~tmpSizeValue; // Invert all the bits
            tmpSizeValue += 1; // Add 1, which gives us our final Bar Size
            tmpDWORDBuf[loop] = tmpSizeValue;
            // Write back the original bar
            tmpSizeValue = 0xFFFFFFFF;
            retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO,
                                            (PCHAR)&oldBarValue, PCISIG_PCI_BAR_OFFSET+(loop*4), PCISIG_SIZE_BAR);
            if (retStatus != IOCTL_STATUS_SUCCESS)
            {
                goto pcisigSizeBar_end;
            }

        }
    }

pcisigSizeBar_end:
    return retStatus;
}

// Function to Write a value to Config Space, delay x usec and then Read back the value
// The value read is returned in rdVal
DECLDIR INT32 pcisigwrRdCfgReg(deviceData* devHandle, UINT8 method, UINT16 segment, UINT8 bus, UINT8 device, UINT8 function, UINT16 offset,
                               UINT32 dataSize, UINT32 wrVal, useconds_t delay, UINT32 *rdVal)
{
    INT32 retStatus = IOCTL_STATUS_SUCCESS;
#if defined (_M_ARM64)
    if (method != PCISIG_MCFG_METHOD)
    {
        retStatus = IOCTL_PARAMETER_ERROR_PORT_IO_UNSUPPORTED;
        goto pcisigwrRdCfgReg_end;
    }
#endif  
    // Validate the input parameters
    // Verify the input Parameters
    if ((dataSize != PCISIG_SIZE_BYTE) && (dataSize != PCISIG_SIZE_WORD) && (dataSize != PCISIG_SIZE_DWORD))
    {
        return IOCTL_PARAMETER_ERROR_RW_SIZE;
    }
    if ((method != PCISIG_MCFG_METHOD) && (method != PCISIG_IO_METHOD))
    {
        return IOCTL_PARAMETER_ERROR_METHODTYPE;
    }
    // We can't access outside PCISIG_PCI_MCFG_SIZE using the MCFG Register
    if (( (dataSize+offset) > PCISIG_PCI_MCFG_SIZE ) && (method == PCISIG_MCFG_METHOD))
    {
        return IOCTL_STATUS_PCIMCFG_SIZE_ERROR;
    }
    if (( (dataSize+offset) > PCISIG_PCI_IO_SIZE ) && (method == PCISIG_IO_METHOD))
    {
        return IOCTL_STATUS_PCIIO_SIZE_ERROR;
    }
    if (rdVal == NULL)
    {
        return IOCTL_PARAMETER_ERROR_READVALUE_NULL;
    }
    if ((segment > PCI_LAST_SEGMENT) || (bus > PCI_LASTBUS) || (device > PCI_LASTDEVICE) || (function > PCI_LASTFUNCTION))
    {
        return IOCTL_PARAMETER_ERROR_SBDF;
    }
    // Check the boundary cases
    if ((dataSize == PCISIG_SIZE_WORD) && (offset % 2 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
    if ((dataSize == PCISIG_SIZE_DWORD) && (offset % 4 != 0))
    {
        return IOCTL_PARAMETER_ERROR_ALIGNMENT;
    }
    if ((delay < 0) || (delay > PCISIG_MAX_USLEEP))
    {
        return IOCTL_PARAMETER_ERROR_USLEEP_BOUNDARY;
    }
 
    pcisigLog(PCISIGLOG_INFO, __func__, "Performing Write/Delay/Read\n");
    
    // First lets write the value
    if (method == PCISIG_MCFG_METHOD)
    {
        retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_WRITE, dataSize, (PCHAR)&wrVal, offset, dataSize);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            goto pcisigwrRdCfgReg_end;
        }
    }
    else
    {
        retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_WRITE, dataSize, (PCHAR)&wrVal, offset, dataSize);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            goto pcisigwrRdCfgReg_end;
        }
    }
#ifndef _PCISIG_WIN_
    // Now let's delay via usleep
    if (usleep(delay) != 0)
    {
        retStatus = IOCTL_STATUS_USLEEP_FAILED;
        goto pcisigwrRdCfgReg_end;
    }
#else
    // In Windows, we can only sleep in milliseconds
    SleepEx(delay/1000, FALSE);
#endif

    // Now read back the value and return it to the user
    if (method == PCISIG_MCFG_METHOD)
    {
        retStatus = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_READ, dataSize, (PCHAR)rdVal, offset, dataSize);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            goto pcisigwrRdCfgReg_end;
        }
    }
    else
    {
        retStatus = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, dataSize, (PCHAR)rdVal, offset, dataSize);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            goto pcisigwrRdCfgReg_end;
        }
    }
    
pcisigwrRdCfgReg_end:
    return retStatus;
}

// Function to Initialize the PCI functionality
// Gets the MCFG, etc so we can use the rest of the driver functions
UINT32 gendrivePCIInit(deviceData* devHandle, struct mCfgNodeLibOverRide *overRide, BOOLEAN bInitial)
{
    INT32 retStatus;
    pcisigLog(PCISIGLOG_INFO, __func__, "Initializing PCI\n");

    if ((bInitial == TRUE) && (overRide->bitMaskOverride > 0))
    {
        // Zero out the IOCTL Structure
       // memset (&inIoctl, 0, sizeof(pcisigIoctl));
        inIoctl.command = PCISIG_CMD_OVERRIDE;
        // Now update the parameters
        inIoctl.bitMaskOverride = overRide->bitMaskOverride;
        inIoctl.segment = overRide->segmentNum;
        inIoctl.startBus = overRide->startBus;
        inIoctl.endBus = overRide->endBus;
        inIoctl.requestAddrLow = overRide->mcfgBaseLow;
        inIoctl.requestAddrHigh = overRide->mcfgBaseHigh;
 
        memcpy((PCHAR)inIoctl.pciData, overRide, sizeof(struct mCfgNodeLibOverRide));
    }
    // Call the driver in order to get the correct version
    if (bInitial == TRUE)
    {
        retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_INIT_PCI, &inIoctl);
    }
    else
    {
        retStatus = pcisigSendIOCTL (devHandle, PCISIG_IOCTL_GET_MCFG, &inIoctl);
    }
    if (retStatus == IOCTL_STATUS_SUCCESS)
    {
        UINT8                       *cpTable;
        UINT32                      acpiTableSize;
        UINT16                      totalSegments;
        struct mCfgNodeLib          *tail;
        UINT32                      loop;
        struct mCfgNodeLib          *tmp;
        UINT8                       *base;

        cpTable = (UINT8*) inIoctl.pciData;

        // The size of the table is at offset 4
        acpiTableSize = *(UINT32 *) (cpTable + MCFG_OFFSET_SIZE);
        totalSegments = (acpiTableSize - MCFG_ENTRY_SIZE)/MCFG_SEGMENT_SIZE;

        // There are n structures for each bridge, we will just get the first one
        pcisigLog(PCISIGLOG_INFO, __func__, "acpiTableSize = 0x%d, PCI Segment Groups: = 0x%x\n",
                  acpiTableSize, totalSegments);

        if (acpiTableSize >= (MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE))
        {
            tail = NULL;
            // Check some basic parameters
            if (totalSegments == 0)
            {
                retStatus = IOCTL_STATUS_PCIMCFG_SEGMENT_ERROR;
                goto gendrivePCIInit_end;
            }
            for (loop = 0; loop < totalSegments; loop++)
            {
                tmp = malloc(sizeof(struct mCfgNodeLib));
                if (tmp == NULL)
                {
                    retStatus = IOCTL_STATUS_ALLOC_ERROR;
                    goto gendrivePCIInit_end;
                }
                memset(tmp, 0, sizeof(struct mCfgNodeLib));
                // Setup the linked list, if we don't have a tail it means we don't have a head
                if (tail == NULL)
                {
                    devHandle->pcinode = tmp;
                    tail = tmp;
                }
                else
                {
                    tail->next = tmp;
                    tail = tmp;
                }
                base = cpTable + MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE * loop; // Base offset into each segment entry
                tmp->segmentNum   = *(UINT16 *)(base + MCFG_SEGMENT); // JPL 5/20/23 - correct offset for all segments > 0
                tmp->startBus     = *(UINT8 *) (base + MCFG_START_BUS);
                tmp->endBus       = *(UINT8 *) (base + MCFG_END_BUS);
                tmp->mcfgBaseLow  = *(UINT32 *)(base + MCFG_BASE_LOW);
                tmp->mcfgBaseHigh = *(UINT32 *)(base + MCFG_BASE_HIGH);
                if ((overRide != NULL) && (overRide->segmentNum == tmp->segmentNum))
                {
                    if (overRide->bitMaskOverride & PCISIG_OVERRIDE_MCFG_STARTBUS)
                        tmp->startBus = overRide->startBus;
                    if (overRide->bitMaskOverride & PCISIG_OVERRIDE_MCFG_ENDBUS)
                        tmp->endBus = overRide->endBus;
                    if (overRide->bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASELOW)
                        tmp->mcfgBaseLow = overRide->mcfgBaseLow;
                    if (overRide->bitMaskOverride & PCISIG_OVERRIDE_MCFG_BASEHIGH)
                        tmp->mcfgBaseHigh = overRide->mcfgBaseHigh;
                }
                pcisigLog(PCISIGLOG_INFO, __func__, "ioctl call returned %d\n", retStatus);

                pcisigLog(PCISIGLOG_INFO, __func__, "devHandle->pcinode = 0x%p tail = 0x%p tmp = 0x%p\n",
                          devHandle->pcinode, tail, tmp);
                pcisigLog(PCISIGLOG_INFO, __func__, "Reading Segment = 0x%X\n", tmp->segmentNum);
                pcisigLog(PCISIGLOG_INFO, __func__, "startBus = 0x%X endBus = 0x%X\n", tmp->startBus, tmp->endBus);
                pcisigLog(PCISIGLOG_INFO, __func__, "mcfgBaseLow = 0x%X mcfgBaseHigh = 0x%X\n",
                          tmp->mcfgBaseLow, tmp->mcfgBaseHigh);
            }
        }
        else
        {
            // The ACPI Table size is incorrect, return an error
            retStatus = IOCTL_STATUS_PCIMCFG_SIZE_ERROR;
            goto gendrivePCIInit_end;
        }
    }
gendrivePCIInit_end:
    return retStatus;
}







