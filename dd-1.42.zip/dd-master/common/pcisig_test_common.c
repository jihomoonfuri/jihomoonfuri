/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_test.c
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#ifdef _PCISIG_WIN_
#include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <memory.h>
#ifndef _PCISIG_WIN_
// Linux
#include <sys/ioctl.h>
#include <semaphore.h>
#include <unistd.h>
#include <asm/types.h>
#include <sys/types.h>
#include <sys/time.h>
#else
// Windows
#include <initguid.h>
#include <BaseTsd.h>

#if MSVC_TOOLSET_VERSION < 142
#define __func__ __FUNCTION__
#endif

#endif

#include "pcisig_common.h"
#include "pcisiglib_interface.h"

#ifdef _PCISIG_WIN_
// Local implementation of getopt as it does not exist in Windows
char* optarg = NULL;
int optIndex = 1;

int getopt(int argC, char *const argV[], const char *optStr)
{
    int opt;
    const char *outOpt;
    
    // Check our boundary conditions
    // Every argument needs to start with '-'
    if ((optIndex >= argC) || (argV[optIndex][0] != '-') || (argV[optIndex][0] == 0))
    {
        return -1;
    }

    opt = argV[optIndex][1];
    outOpt = strchr(optStr, opt);

    if (outOpt == NULL)
    {
        return '?';
    }
    if (outOpt[1] == ':')
    {
        optIndex++;
        if (optIndex >= argC)
        {
            return '?';
        }
        optarg = argV[optIndex];
        optIndex++;
    }
    else
    {
        optarg = NULL;
        optIndex++;
    }
    return opt;
}
#endif

// #defines just for the test code to help with clarity
#define  MAX_BINARY_BYTES           16

void dumpBinary(PUCHAR p, UINT32 size)
{
    UINT32  iLoop, iLoopInner;
    UINT32  maxSize = 0;
    iLoop = 0;
    do
    {
        printf("0x%03X: ", iLoop);
        maxSize = (iLoop + MAX_BINARY_BYTES) <= size ? MAX_BINARY_BYTES : (size - iLoop);
        for (iLoopInner=0; iLoopInner<maxSize; iLoopInner++)
        {
            printf("%02X ", p[iLoop+iLoopInner]);
            //printf("%02x ", (tmpBuffer[iLoop+iLoopInner]));
            if (iLoopInner == 7)
            {
                printf(" ");
            }
        }
        printf("\n");
        iLoop +=MAX_BINARY_BYTES;
        
    } while (iLoop < size);
    return;
}

UINT32 compBinary(PUCHAR buf, PUCHAR bufTmp, UINT32 bufSize)
{
    UINT32 iLoop;
    
    for (iLoop = 0; iLoop < bufSize; iLoop++)
    {
        if (buf[iLoop] != bufTmp[iLoop])
            return 1;
    }
    return 0;
    
}

void dumpBars(UINT32* p, UINT32 size)
{
    UINT32  iLoop;
    
    for (iLoop = 0; iLoop < 6; iLoop++)
    {
        printf("Bar #%d: 0x%08X\n", iLoop, p[iLoop]);
    }
    return;
}

void DumpPCIArray(pciDevice*   devArray, UINT32 arraySize)
{
    UINT32 iLoop;

    printf("   BDF  VenID DevID\n");
    for (iLoop=0; iLoop < arraySize; iLoop++)
    {
        printf("[%02X:%02X:%01X]=%04X %04X\n",
               devArray[iLoop].bus, devArray[iLoop].device, devArray[iLoop].function,
               devArray[iLoop].vendorId, devArray[iLoop].deviceId);

    }
}

void DumpPCIArrayMcfg(UINT16 segment, pciDevice*   devArray, UINT32 arraySize)
{
    UINT32 iLoop;

    printf("  SBDF  VenID DevID\n");
    for (iLoop=0; iLoop < arraySize; iLoop++)
    {
        printf("[%04X:%02X:%02X:%01X]=%04X %04X\n",
	       segment, devArray[iLoop].bus, devArray[iLoop].device, devArray[iLoop].function,
               devArray[iLoop].vendorId, devArray[iLoop].deviceId);

    }
}

void dumpMcfgTable(PCHAR buf, UINT32 *mcfgBaseLow, UINT32 *mcfgBaseHigh)
{
    UINT32 acpiTableSize = 0;
    UINT8 acpiStartBus, acpiEndBus;
    UINT16 segment, segmentNum;
    UINT16 numSeg; // Number of Segments 
    PCHAR base;

    acpiTableSize = *(UINT32 *) (buf + 4); // size of the table = Mcfg->Length at Offset 4
    numSeg = (acpiTableSize - MCFG_ENTRY_SIZE) / 16; // = (Mcfg->Length - 44) / 16

    printf("acpiTableSize = %d\n",  acpiTableSize);
    printf("PCI Segment Groups: = 0x%x\n", (acpiTableSize - MCFG_ENTRY_SIZE)/MCFG_SEGMENT_SIZE);
    for (segment = 0; segment < numSeg; segment++) {
        base = buf + MCFG_ENTRY_SIZE + MCFG_SEGMENT_SIZE * segment;
        *mcfgBaseLow = *(UINT32*)base;
        *mcfgBaseHigh = *(UINT32*)(base + 4);
        printf("\nMMIO CFG BaseAddress = 0x%08X %08X\n", *mcfgBaseHigh, *mcfgBaseLow);

        segmentNum = *(UINT16*)(base + MCFG_SEGMENT);
        printf("        PCIe Segment = %d\n", segmentNum);
        
        acpiStartBus = *(UINT8*)(base + MCFG_START_BUS);
        printf("        Start Bus    = 0x%02X\n", acpiStartBus);
        acpiEndBus = *(UINT8*)(base + MCFG_END_BUS);
        printf("        Last  Bus    = 0x%02X\n", acpiEndBus);
    };
    printf("------- End dumping MCFG ACPI Table\n");
}


void ExerciseOddAccessMCFG(deviceData* devHandle, UINT16 segment, UINT8 bus, UINT8 device, UINT8 function)
{
//    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
    UINT32      status;
    UINT16      classcode;
    UINT32      buffer32bits;
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];

    printf("\nExercising the Odd Addresses for %X:%X:%X:%X\n", segment, bus, device, function);

    
    printf("First lets test aligned access\n");
    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 0x20 bytes at offset 0x0 using BYTE\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_BYTE, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 0x20 bytes at offset 0x0 using WORD\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 0x20 bytes at offset 0x0 using DWORD\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_DWORD, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);

    //goto ExerciseOddAccess_end;

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 0x2 bytes at offset 0x1 using AUTO\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 1, 0x2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x2);




    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 1 bytes at offset 0x9\n");
    classcode = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&classcode, 0x9, 1);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    printf("Read: 0x%02X\n", classcode);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 2 bytes at offset 0x9\n");
    classcode = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&classcode, 0x9, 2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
    printf("Read: 0x%02X\n", classcode);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 3 bytes at offset 0x9 using AUTO\n");
    buffer32bits = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
   // printf("Read: 0x%02X\n", buffer32bits);
    dumpBinary((PUCHAR)&buffer32bits, 0x3);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 3 bytes at offset 0x9 using BYTES\n");
    buffer32bits = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseOddAccessMCFG_end;
    }
   // printf("Read: 0x%02X\n", buffer32bits);
    dumpBinary((PUCHAR)&buffer32bits, 0x3);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 3 bytes at offset 0x9 with force WORD access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 5 bytes at offset 0x9 with force WORD access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&buffer32bits, 0x9, 5);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 5 bytes at offset 0x9 with force DWORD access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_DWORD, (PCHAR)&buffer32bits, 0x9, 5);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    
    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 9 bytes at offset 0x9 with AUTO access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 9);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x9);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 10 bytes at offset 0x9 with AUTO access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 10);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 10);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read 23 bytes at offset 0x9 with AUTO access\n");
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 23);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 23);

ExerciseOddAccessMCFG_end:
    return;
    
}

//For Arm64 expect this function to return failure
void ExerciseOddAccessIO(deviceData* devHandle, UINT8 bus, UINT8 device, UINT8 function)
{
//    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
    UINT32      status;
    UINT16      classcode;
    UINT32      buffer32bits;
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];

    printf("\nExercising the Odd Addresses for %X:%X:%X\n", bus, device, function);

    
    printf("First lets test aligned access\n");
    printf ("Lets use the pcisigGetSetPciConfigIO to read 0x20 bytes at offset 0x0 using BYTE\n");
#if defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nExpect ConfigIO call to return failure for Arm64\n");
#endif

    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_BYTE, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);
    printf ("Lets use the pcisigGetSetPciConfigIO to read 0x20 bytes at offset 0x0 using WORD\n");
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);


    printf ("Lets use the pcisigGetSetPciConfigIO to read 0x20 bytes at offset 0x0 using DWORD\n");
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_DWORD, tmpBuffer, 0, 0x20);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x20);

    //goto ExerciseOddAccess_end;

    printf ("Lets use the pcisigGetSetPciConfigIO to read 0x2 bytes at offset 0x1 using AUTO\n");
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 1, 0x2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x2);


    printf ("Lets use the pcisigGetSetPciConfigIO to read 1 bytes at offset 0x9\n");
    classcode = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&classcode, 0x9, 1);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    printf("Read: 0x%02X\n", classcode);


    printf ("Lets use the pcisigGetSetPciConfigIO to read 2 bytes at offset 0x9\n");
    classcode = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&classcode, 0x9, 2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
    printf("Read: 0x%02X\n", classcode);

    printf ("Lets use the pcisigGetSetPciConfigIO to read 3 bytes at offset 0x9 using AUTO\n");
    buffer32bits = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
//    printf("Read: 0x%02X\n", buffer32bits);
    dumpBinary((PUCHAR)&buffer32bits, 0x3);

    printf ("Lets use the pcisigGetSetPciConfigIO to read 3 bytes at offset 0x9 using BYTES\n");
    buffer32bits = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseOddAccessIO_end;
    }
//    printf("Read: 0x%02X\n", buffer32bits);
    dumpBinary((PUCHAR)&buffer32bits, 0x3);

    printf ("Lets use the pcisigGetSetPciConfigIO to read 3 bytes at offset 0x9 with force WORD access\n");
    status = pcisigGetSetPciConfigIO( devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&buffer32bits, 0x9, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    printf ("Lets use the pcisigGetSetPciConfigIO to read 5 bytes at offset 0x9 with force WORD access\n");
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&buffer32bits, 0x9, 5);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    printf ("Lets use the pcisigGetSetPciConfigIO to read 5 bytes at offset 0x9 with force DWORD access\n");
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_DWORD, (PCHAR)&buffer32bits, 0x9, 5);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    printf("expecting a failure\n");

    
    printf ("Lets use the pcisigGetSetPciConfigIO to read 9 bytes at offset 0x9 with AUTO access\n");
    //memset(tmpBuffer, 0, PCISIG_PCI_MCFG_SIZE);
    status = pcisigGetSetPciConfigIO( devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 9);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 0x9);

    printf ("Lets use the pcisigGetSetPciConfigIO to read 10 bytes at offset 0x9 with AUTO access\n");
    status = pcisigGetSetPciConfigIO( devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 10);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 10);
    
    printf ("Lets use the pcisigGetSetPciConfigIO to read 23 bytes at offset 0x9 with AUTO access\n");
    status = pcisigGetSetPciConfigIO( devHandle, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, 0x9, 23);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
    }
    dumpBinary((PUCHAR)tmpBuffer, 23);

    
ExerciseOddAccessIO_end:
    return;
    
}
//For Arm64 expect this function to return failure
void ExerciseGetSetRoutineWritesOddIO(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        tmpBufferOrig[PCISIG_PCI_MCFG_SIZE];
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
    UINT32      barsFF[PCISIG_NUM_BARS];
    UINT32      status;
    UINT32      bufSize;
    int         loop;

    printf("\nExercising the ExerciseGetSetRoutineWritesOdd Routines for %X:%X:%X:%X\n", segment, bus, device, function);

    printf ("First lets use the pcisigGetSetPciConfigIO to read all the Bars using AUTO\n");
#if defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nExpect ConfigIO call to return failure for Arm64\n");
#endif

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBufferOrig, bufSize);

    for (loop=0;loop<PCISIG_NUM_BARS;loop++)
    {
        barsFF[loop] = 0xFFFFFFFF;
  //      printf("bars[%d] = 0x%x\n", loop, barsFF[loop]);
    }
    printf ("Use the pcisigGetSetPciConfigIO to write to FFs to all the bars using DWORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigIO to write back the original bars using WORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_WORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigIO to write to FFs to all the bars using BYTE\n");

    printf("For bar #1, lets write the first 3 bytes, then the remaining bytes after using AUTO");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_BYTE, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }

    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET+3, (bufSize-3));
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }

    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigIO to write back the original bars using WORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_WORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);


    printf ("Use the pcisigGetSetPciConfigIO WORD to write to FFs to all the bars using DWORD\n");

    

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }

    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigIO DWORD to write back the original bars\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }

    printf("Read back the bars\n");
 
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesIOOdd_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);
    printf("end of pcisigGetSetPciConfigMcfg\n");

ExerciseGetSetRoutineWritesIOOdd_end:
    return;
}

void ExerciseGetSetRoutineWritesOddMCFG(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        tmpBufferOrig[PCISIG_PCI_MCFG_SIZE];
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
  //  char        barsFF[PCISIG_PCI_MCFG_SIZE];
    UINT32      barsFF[PCISIG_NUM_BARS];
    UINT32      status;
    UINT32      bufSize;
    int         loop;

    printf("\nExercising the ExerciseGetSetRoutineWritesOddMCFG Routines for %X:%X:%X:%X\n", segment, bus, device, function);

    printf ("First lets use the pcisigGetSetPciConfigMcfg to read all the Bars using AUTO\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBufferOrig, bufSize);

    for (loop=0;loop<PCISIG_NUM_BARS;loop++)
    {
        barsFF[loop] = 0xFFFFFFFF;
//        printf("bars[%d] = 0x%x\n", loop, ((UINT32*)barsFF)[loop]);
    }

    printf ("Use the pcisigGetSetPciConfigMcfg to write to FFs to all the bars using DWORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    
    printf("Read back the bars");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigMcfg to write back the original bars\n");

    printf("Writing original back using WORD\n");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_WORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
      
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigMcfg to write to FFs to all the bars using BYTE\n");

    printf("For bar #1, lets write the first 3 bytes, then the remaining bytes after using AUTO");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_BYTE, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, 3);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }

    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET+3, (bufSize-3));
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }

    printf("Read back the bars");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigMcfg to write back the original bars using WORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_WORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);


    printf ("Use the pcisigGetSetPciConfigMcfg to write to FFs to all the bars using DWORD\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, (PCHAR)barsFF, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf ("Use the pcisigGetSetPciConfigMcfg to write back the original bars\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD, tmpBufferOrig, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    
    printf("Read back the bars");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutineWritesOddMCFG_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf("exiting ExerciseGetSetRoutineWritesOddMCFG\n");
ExerciseGetSetRoutineWritesOddMCFG_end:
    return;
}
//For Arm64 expect the pcisigGetSetPciConfigIO to report failure
void ExerciseGetSetRoutines(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
    UINT32      status;
    UINT32      bar, oldbar;

    printf("\nExercising the GetSet Routines for %X:%X:%X:%X\n", segment, bus, device, function);

    printf ("Lets use the pcisigGetSetPciConfigMcfg to read/write Bar 0 using WORD\n");
    printf ("Writing 0xFFFFFFF to Bar 0, then read it back\n");
    
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }
    oldbar = ((UINT32*)tmpBuffer)[0];
    printf("Bar #0: 0x%08X\n", oldbar);
    
    printf("Writing 0xFFFFFFFF to Bar #0\n");
    ((UINT32*)tmpBuffer)[0] = 0xFFFFFFFF;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }
    bar = ((UINT32*)tmpBuffer)[0];
    printf("Read back Bar #0: 0x%08X\n", bar);
    printf("Writing back original Bar #0 of 0x%08X\n", oldbar);
    ((UINT32*)tmpBuffer)[0] = oldbar;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
                                       PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }

    printf("\nLets use the pcisigGetSetPciConfigMcfg to read/write Bar 0 from segment 1 expect an error\n");

    segment = 1;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function,
        PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if (status != IOCTL_STATUS_SUCCESS)
    {
        printf("As expected pcisigGetSetPciConfigMcfg failed with 0x%x\n", status);
    }
//For Arm64 expect this section to report failure

    printf ("\n\nLets use the pcisigGetSetPciConfigIO to read/write Bar 0\n");
    printf ("Writing 0xFFFFFFF to Bar 0, then read it back\n");
    
#if defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nExpect ConfigIO call to return failure for Arm64\n");
#endif
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }
    oldbar = ((UINT32*)tmpBuffer)[0];
    printf("Bar #0: 0x%08X\n", oldbar);
    
    printf("Writing 0xFFFFFFFF to Bar #0\n");
    ((UINT32*)tmpBuffer)[0] = 0xFFFFFFFF;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
   }
    bar = ((UINT32*)tmpBuffer)[0];
    printf("Read back Bar #0: 0x%08X\n", bar);
    printf("Writing back original Bar #0 of 0x%08X\n", oldbar);
    ((UINT32*)tmpBuffer)[0] = oldbar;
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_WRITE, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_BAR);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExerciseGetSetRoutines_end;
    }

ExerciseGetSetRoutines_end:
    return;
}

void ExerciseRWMemory(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function, UINT32 memHigh, UINT32 memLow, UINT32 memOffset, BOOLEAN specData, UINT32 dataDirection, UINT32 dataSize, UINT32 dataValue)
{
    char        buf[PCISIG_PCI_MCFG_SIZE];
    char        bufOdd[8];
    UINT32      bufSize;
    UINT32      status;
    UINT32      oldbar;
    UINT8       buf8bits;
    UINT16      buf16bits;
    UINT32      buf32bits;
    UINT32      mcfgBaseLow, mcfgBaseHigh;
    UINT32      offset;
    //UINT8       lastBus;
    UINT32      physAddressLow, physAddressHigh;

    // Now lets test Read/Writing Memory
    // Let's use the MCFG registers as they are known MMIO
    printf("\nExercising RWMemory for %X:%X:%X:%X\n", segment, bus, device, function);
    status = pcisigGetMCFGAddr(devHandle, buf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetMCFGAddr failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    // Dump out the full MCFG Table
    dumpMcfgTable(buf, &mcfgBaseLow, &mcfgBaseHigh);
    printf("\nLets test the Read/Writing of Memory using MCFG. Low = 0x%08X, High = 0x%08X\n", mcfgBaseLow, mcfgBaseHigh);
    bufSize = 8;
    offset = ((bus << MCFG_BUSADDR_OFFSET) | (device << MCFG_DEVICEADDR_OFFSET) | (function << MCFG_FUNCADDR_OFFSET)) + PCISIG_PCI_BAR_OFFSET;
    printf("Offset = 0x%x\n", offset);
    // Lets read the equivalent of the first 8 bytes
    // Read the first 8 bytes of the device
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow, mcfgBaseHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    dumpBinary((PUCHAR)buf, bufSize);

    printf("Lets Read 1/2/3/4 Bytes and dump it out ");
    buf32bits = 0;
    bufSize = 4;
    // Lets read the equivalent of the first 4 bytes
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Four Bytes = 0x%08X\n", buf32bits);

    printf("Lets Read 1/2/3/4 Bytes and dump it out ");
    buf32bits = 0;
    bufSize = 3;
    // Lets read the equivalent of the first 2 bytes

    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Three Bytes = 0x%04X\n", buf32bits);

    printf("Lets Read 1/2/4 Bytes and dump it out ");
    buf32bits = 0;
    bufSize = 2;
    // Lets read the equivalent of the first 2 bytes
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf16bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Two Bytes = 0x%04X\n", buf16bits);

    printf("Lets Read 1/2/4 Bytes and dump it out ");
    buf32bits = 0;
    bufSize = 1;
    // Lets read the equivalent of the first byte
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf8bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("One Byte = 0x%02X\n", buf8bits);
    
    printf("\nLets use pcisigRWMemory to Read the Bar #0 at %X:%X:%X:%X\n", segment, bus, device, function);
    buf32bits = 0;
    bufSize = 4;
    offset = ((bus << 20) | (device << 15) | (function << 12)) + PCISIG_PCI_BAR_OFFSET;
    printf("offset = %x\n", offset);
    // Lets read the equivalent of the first bar
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Bar#0 Bytes = 0x%08X\n", buf32bits);

    oldbar = buf32bits;
    buf32bits = 0xFFFFFFFF;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_WRITE, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    buf32bits = 0;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Bar#0 Bytes = 0x%08X\n", buf32bits);
    printf("Restoring original\n");
    status = pcisigRWMemory(devHandle, PCISIG_CMD_WRITE, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&oldbar, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    buf32bits = 0;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)&buf32bits, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("Bar#0 Bytes = 0x%08X\n", buf32bits);

    printf("Read all the bars using pcisigRWMemory\n");
    bufSize = (sizeof(char) * PCISIG_NUM_BARS * PCISIG_SIZE_BAR);

    offset = ((bus << 20) | (device << 15) | (function << 12)) + PCISIG_PCI_BAR_OFFSET;
    printf("offset = %x\n", offset);
    // Lets read the equivalent of the first bar
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MMIO, mcfgBaseLow , mcfgBaseHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    dumpBars((UINT32*)buf, bufSize);

    
    // Now test physical memory
    if (devHandle->memPhysAddrLow == 0)
    {
        printf( "We dont have a physical memory for testing, must have failed in Open()\n");
        goto ExerciseRWMemory_end;

    }

    printf("We got a physical address of high = 0x%X low = 0x%X\n", devHandle->memPhysAddrHigh, devHandle->memPhysAddrLow );
    
    // Dump out the 0x400 bytes of our allocated memory
    printf("\nLets test the Read the physical buffer. Low = 0x%08X, High = 0x%08X\n", devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh);
     bufSize = 0x400;
    offset = 0;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    dumpBinary((PUCHAR)buf, bufSize);

    printf("Testing an Odd Write.  Lets write the pattern ABCDEF12DEADBEEF to offset 0x3 total 8 bytes\n");
    ((UINT8*)bufOdd)[0] = 0xAB;
    ((UINT8*)bufOdd)[1] = 0xCD;
    ((UINT8*)bufOdd)[2] = 0xEF;
    ((UINT8*)bufOdd)[3] = 0x12;
    ((UINT8*)bufOdd)[4] = 0xDE;
    ((UINT8*)bufOdd)[5] = 0xAD;
    ((UINT8*)bufOdd)[6] = 0xBE;
    ((UINT8*)bufOdd)[7] = 0xEF;
    bufSize = 0x8;
    offset = 0x3;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_WRITE, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)bufOdd, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
 
    bufSize = 0x20;
    offset = 0;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("\n Now lets see the modification using AUTO\n");
    dumpBinary((PUCHAR)buf, bufSize);

    bufSize = 0x400;
    offset = 0;
    ((UINT32*)buf)[0x10] = 0xFFFFFFFF;
    ((UINT32*)buf)[0x20] = 0xABCDEF12;
    status = pcisigRWMemory(devHandle, PCISIG_CMD_WRITE, bufSize, PCISIG_SIZE_AUTO, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
 
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_BYTE, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("\n Now lets see the modification using BYTE\n");
    dumpBinary((PUCHAR)buf, bufSize);

 
    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_WORD, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("\n Now lets see the modification using WORD\n");
    dumpBinary((PUCHAR)buf, bufSize);

 

    status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_DWORD, PCISIG_MAP_TYPE_MEM, devHandle->memPhysAddrLow, devHandle->memPhysAddrHigh, (PCHAR)buf, offset);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigRWMemory failed with 0x%x\n", status );
        goto ExerciseRWMemory_end;
    }
    printf("\n Now lets see the modification using DWORD\n");
    dumpBinary((PUCHAR)buf, bufSize);


    if (memLow == 0x0)
    {
        goto ExerciseRWMemory_end;
    }

    printf("We received a PHYSICAL address using -m\n");

    // Now test physical memory
    physAddressLow = memLow;
    physAddressHigh = memHigh;
    printf("\nLets test the physical buffer. Low = 0x%08X, High = 0x%08X, Offset = 0x%02X\n", physAddressLow, physAddressHigh, memOffset);

    if (specData != TRUE)
    {

        printf("Read or Write not specified so we will read a DWORD by default\n");
        buf32bits = 0;
        bufSize = 0x4;
        offset = memOffset;
        status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, PCISIG_SIZE_DWORD, PCISIG_MAP_TYPE_MMIO, physAddressLow, physAddressHigh, (PCHAR)&buf32bits, offset);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigRWMemory failed with 0x%x\n", status );
            goto ExerciseRWMemory_end;
        }
        printf("We read back 0x%X\n", buf32bits);
    }
    if ((specData == TRUE) && (dataDirection == PCISIG_CMD_READ))
    {

        printf("Reading specified so we will read %d bytes\n", dataSize);
        buf32bits = 0;
        bufSize = dataSize;
        offset = memOffset;
        status = pcisigRWMemory(devHandle, dataDirection, bufSize, dataSize, PCISIG_MAP_TYPE_MMIO, physAddressLow, physAddressHigh, (PCHAR)&buf32bits, offset);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigRWMemory failed with 0x%x\n", status );
            goto ExerciseRWMemory_end;
        }
        printf("We read back 0x%X\n", buf32bits);
    }
    if ((specData == TRUE) && (dataDirection == PCISIG_CMD_WRITE))
    {

        printf("Writing specified so we will first read %d bytes\n", dataSize);
        buf32bits = 0;
        bufSize = dataSize;
        offset = memOffset;
        status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, dataSize, PCISIG_MAP_TYPE_MMIO, physAddressLow, physAddressHigh, (PCHAR)&buf32bits, offset);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigRWMemory failed with 0x%x\n", status );
            goto ExerciseRWMemory_end;
        }
        printf("We read back 0x%X\n", buf32bits);
        printf("Going to sleep for 2 seconds\n");
#ifndef _PCISIG_WIN_
        usleep(2000*1000);
#else
        Sleep(2000);
#endif
        printf("Writing %d bytes of 0x%X\n", dataSize, dataValue);
        buf32bits = dataValue;
        bufSize = dataSize;
        offset = memOffset;
        status = pcisigRWMemory(devHandle, PCISIG_CMD_WRITE, bufSize, dataSize, PCISIG_MAP_TYPE_MMIO, physAddressLow, physAddressHigh, (PCHAR)&buf32bits, offset);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigRWMemory failed with 0x%x\n", status );
            goto ExerciseRWMemory_end;
        }
        printf("Now lets read back %d bytes\n", dataSize);
        buf32bits = 0;
        bufSize = dataSize;
        offset = memOffset;
        status = pcisigRWMemory(devHandle, PCISIG_CMD_READ, bufSize, dataSize, PCISIG_MAP_TYPE_MMIO, physAddressLow, physAddressHigh, (PCHAR)&buf32bits, offset);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigRWMemory failed with 0x%x\n", status );
            goto ExerciseRWMemory_end;
        }
        printf("We read back 0x%X\n", buf32bits);
    }

ExerciseRWMemory_end:
    return;
}


void ExercisePCIBits(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    UINT32      status;
    UINT8       parity;
    UINT16      intdisable;

    printf("\nExercising PCI Bits for %X:%X:%X:%X\n", segment, bus, device, function);
    printf("Test MCFG 1/2 sizes: Lets test by toggling bit 6, read the lower 8 bits, toggle bit 6 and write back\n");
    parity = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&parity, PCISIG_COMMAND_MASTER, 1);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    printf("For Parity, we read 0x%02X\n", parity);

    parity ^= 1UL << 6;
    printf("For Parity, we will write 0x%02X\n", parity);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_BYTE, (PCHAR)&parity, PCISIG_COMMAND_MASTER, 1);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    parity = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&parity, PCISIG_COMMAND_MASTER, 1);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    printf("For Parity, we read 0x%02X\n", parity);

    printf("Lets test by toggling bit 10, read 16 bits, toggle bit 10 and write back\n");
    intdisable = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&intdisable, PCISIG_COMMAND_MASTER, 2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    
    printf("For int disable, we read 0x%04X\n", intdisable);
    intdisable ^= 1UL << 10;
    printf("For int disable, we will write 0x%04X\n", intdisable);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_WORD, (PCHAR)&intdisable, PCISIG_COMMAND_MASTER, 2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    intdisable = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_WORD, (PCHAR)&intdisable, PCISIG_COMMAND_MASTER, 2);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisePCIBits_end;
    }
    printf("For int disable, we read 0x%04X\n", intdisable);

ExercisePCIBits_end:
    return;
}

void ExerciseBars(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        tmpBuffer[PCISIG_PCI_MCFG_SIZE];
    UINT32      bufSize;
    UINT32      status;
    
    printf("\nExercising the BARS for %X:%X:%X:%X\n", segment, bus, device, function);

    printf("\nLets dump the BARS using MCFG\n");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExerciseBars_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf("\nAttempting to size the BARS using MCFG\n");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    // Lets Size the BARS
    status = pcisigSizeBar(devHandle, segment, bus, device, function, FALSE, TRUE, tmpBuffer, bufSize);
    if (status != IOCTL_STATUS_SUCCESS)
    {
        printf("pcisigSizeBar failed with 0x%x\n", status);
        goto ExerciseBars_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);


#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space 

    printf("\nLets dump the BARS using I/O\n");
    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    status = pcisigGetSetPciConfigIO(devHandle, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, tmpBuffer, PCISIG_PCI_BAR_OFFSET, bufSize);
    if (status != IOCTL_STATUS_SUCCESS)
    {
        printf("pcisigGetSetPciConfigIO failed with 0x%x\n", status);
        goto ExerciseBars_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);

    printf("\nAttempting to size the BARS using I/O\n");

    bufSize = (sizeof(char) * PCISIG_SIZE_BAR * PCISIG_NUM_BARS);
    // Lets Size the BARS
    status = pcisigSizeBar(devHandle, segment,bus,device,function, FALSE, FALSE, tmpBuffer, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigSizeBar failed with 0x%x\n", status );
        goto ExerciseBars_end;
    }
    dumpBars((UINT32*)tmpBuffer, bufSize);
#endif
  
ExerciseBars_end:
    return;
}

void ExercisewrDelayRdFunction(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    UINT8       value8w, value8r;
    UINT16      value16w, value16r;
    UINT32      value32w, value32r, baroriginal;
    UINT32      status;
    
    printf("\nExercising the new pcisigwrRdCfgReg for %X:%X:%X:%X\n", segment, bus, device, function);

    
    printf("Testing using Method MCFG\n");
    printf("Lets test by toggling bit 6, read the lower 8 bits, toggle bit 6 and write back\n");
    value8w = value8r = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&value8w, PCISIG_COMMAND_MASTER, PCISIG_SIZE_BYTE);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("For Parity, we read 0x%02X\n", value8w);

    value8w ^= 1UL << 6;
    printf("For Parity, we will write 0x%02X\n", value8w);
    status = pcisigwrRdCfgReg(devHandle, PCISIG_MCFG_METHOD, segment,bus,device,function, PCISIG_COMMAND_MASTER,
                              PCISIG_SIZE_BYTE, value8w,100000,(UINT32*)&value8r);

    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value16r = 0x%X\n", status, value8r);

 
    // For Byte/Word, lets seed with what's in the command register.
    printf("Lets test by toggling bit 10, read 16 bits, toggle bit 10 and write back\n");
    
    value16w = value16r = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_WORD,
                                       (PCHAR)&value16w, PCISIG_COMMAND_MASTER, PCISIG_SIZE_WORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }

    printf("For int disable, we read 0x%04X and now lets toggle bit 10\n", value16w);
    value16w ^= 1UL << 10;
    printf("For int disable, we will write 0x%04X\n", value16w);
    
    status = pcisigwrRdCfgReg(devHandle, PCISIG_MCFG_METHOD, segment,bus,device,function, PCISIG_COMMAND_MASTER,
                              PCISIG_SIZE_WORD, value16w,100000,(UINT32*)&value16r);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value16r = 0x%X\n", status, value16r);
    
    // For Byte/Word, lets seed with what's in the command register.
    printf("Lets test DWORD by reading bar#0, writting 0xFFFFFFFF and then writing back back the original\n");
    
    value32w = value32r = 0;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_DWORD,
                                       (PCHAR)&value32w, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_DWORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }

    baroriginal = value32w;
    value32w = 0xFFFFFFFF;
    printf("original bar = 0x%08X \n", baroriginal);
    
    status = pcisigwrRdCfgReg(devHandle, PCISIG_MCFG_METHOD, segment,bus,device,function, PCISIG_PCI_BAR_OFFSET,
                              PCISIG_SIZE_DWORD, value32w,100000,(UINT32*)&value32r);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value32r = 0x%X\n", status, value32r);
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD,
                                       (PCHAR)&baroriginal, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_DWORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }

#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nTesting using Method I/O\n");
    printf("Lets test by toggling bit 6, read the lower 8 bits, toggle bit 6 and write back\n");
    value8w = value8r = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_BYTE, (PCHAR)&value8w, PCISIG_COMMAND_MASTER, PCISIG_SIZE_BYTE);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("For Parity, we read 0x%02X\n", value8w);

    value8w ^= 1UL << 6;
    printf("For Parity, we will write 0x%02X\n", value8w);
    status = pcisigwrRdCfgReg(devHandle, PCISIG_IO_METHOD, segment,bus,device,function, PCISIG_COMMAND_MASTER,
                              PCISIG_SIZE_BYTE, value8w,100000,(UINT32*)&value8r);

    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value16r = 0x%X\n", status, value8r);

 
    // For Byte/Word, lets seed with what's in the command register.
    printf("Lets test by toggling bit 10, read 16 bits, toggle bit 10 and write back\n");
    
    value16w = value16r = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_WORD,
                                       (PCHAR)&value16w, PCISIG_COMMAND_MASTER, PCISIG_SIZE_WORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }

    printf("For int disable, we read 0x%04X and now lets toggle bit 10\n", value16w);
    value16w ^= 1UL << 10;
    printf("For int disable, we will write 0x%04X\n", value16w);
    
    status = pcisigwrRdCfgReg(devHandle, PCISIG_IO_METHOD, segment,bus,device,function, PCISIG_COMMAND_MASTER,
                              PCISIG_SIZE_WORD, value16w,100000,(UINT32*)&value16r);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value16r = 0x%X\n", status, value16r);
    
    // For Byte/Word, lets seed with what's in the command register.
    printf("Lets test DWORD by reading bar#0, writting 0xFFFFFFFF and then writing back back the original\n");
    
    value32w = value32r = 0;
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_DWORD,
                                       (PCHAR)&value32w, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_DWORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }

    baroriginal = value32w;
    value32w = 0xFFFFFFFF;
    printf("original bar = 0x%08X \n", baroriginal);
    
    status = pcisigwrRdCfgReg(devHandle, PCISIG_IO_METHOD, segment,bus,device,function, PCISIG_PCI_BAR_OFFSET,
                              PCISIG_SIZE_DWORD, value32w,100000,(UINT32*)&value32r);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigwrRdCfgReg failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
    printf("We got back status = 0x%x, and value32r = 0x%X\n", status, value32r);
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_WRITE, PCISIG_SIZE_DWORD,
                                       (PCHAR)&baroriginal, PCISIG_PCI_BAR_OFFSET, PCISIG_SIZE_DWORD);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto ExercisewrDelayRdFunction_end;
    }
#endif

ExercisewrDelayRdFunction_end:
    return;
}

void DumpSpecficPCIDev(deviceData* devHandle, BOOLEAN runAllTests, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        buf[PCISIG_PCI_MCFG_SIZE];
    UINT32      bufSize;
    UINT32      status;
    
    
    printf("\nExercising the Device %X:%X:%X:%X\n", segment, bus, device, function);
    printf("\nDumping the first 256 bytes using the MCFG address\n");
    bufSize = PCISIG_PCI_IO_SIZE;
    status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, buf, 0, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
        goto DumpSpecficPCIDev_end;
    }
    dumpBinary((PUCHAR)buf, bufSize);

#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space - use Mcfg method for reference value  as well.
  
    printf("\nDumping the contents the I/O address\n");
    bufSize = PCISIG_PCI_IO_SIZE;
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, buf, 0, bufSize);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto DumpSpecficPCIDev_end;
    }
    dumpBinary((PUCHAR)buf, bufSize);
#endif
    
DumpSpecficPCIDev_end:
    return;
}

UINT32 StressDumpSpecficPCIDev(deviceData* devHandle, UINT8 segment, UINT8 bus, UINT8 device, UINT8 function)
{
    char        buf[PCISIG_PCI_MCFG_SIZE];
    char        bufTmp[PCISIG_PCI_MCFG_SIZE];
    UINT32      bufSize;
    UINT32      status;
    UINT32      iLoop;
    UINT32      retStatus = 0;
    
    
    printf("\nReading the contents of PCI Config using I/O then will compare with MCFG\n");
    bufSize = PCISIG_PCI_IO_SIZE;
#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space - use Mcfg method for reference value  as well.
    status = pcisigGetSetPciConfigIO(devHandle, bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, buf, 0, bufSize);
#else
    status = pcisigGetSetPciConfigMcfg(devHandle, segment, bus, device, function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, buf, 0, bufSize);
#endif
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetSetPciConfigIO failed with 0x%x\n", status );
        goto StressDumpSpecficPCIDev;
    }

    printf("About to loop 1000 times comparing config space\n");
    for (iLoop = 0; iLoop < 1000; iLoop++)
    {
//        printf("Loop = %d\n", iLoop);
        bufSize = PCISIG_PCI_IO_SIZE;
        memset(bufTmp, 0, bufSize);
        status = pcisigGetSetPciConfigMcfg(devHandle, segment,bus,device,function, PCISIG_CMD_READ, PCISIG_SIZE_AUTO, bufTmp, 0, bufSize);
        if ( status != IOCTL_STATUS_SUCCESS )
        {
            printf( "pcisigGetSetPciConfigMcfg failed with 0x%x\n", status );
            goto StressDumpSpecficPCIDev;
        }
        if (compBinary((PUCHAR)buf, (PUCHAR)bufTmp, bufSize) != 0)
        {
            printf( "StressDumpSpecficPCIDev failed comparison at iLoop = %d - exiting\n", iLoop);
            retStatus = 1;
            goto StressDumpSpecficPCIDev;
        }
    }
StressDumpSpecficPCIDev:
    return retStatus;
}

//For Arm64 expect this function to report failure
void ExerciseIO(deviceData* devHandle)
{

    UINT32      dataBuf;
    
    UINT32      status = 0;
#if defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nExpect IO call to return failure for Arm64\n");
#endif
    printf("\n Exercising the I/O functions\n");

    dataBuf = PCISIG_PCI_ENABLE_BIT;   // Lets read from BDF 0:0:0
    printf("Writing 32 bits to 0xCF8 = 0x%X\n", dataBuf);
    status = pcisigWriteIO(devHandle, PCISIG_IO_SIZE_32, IO_ADDR, dataBuf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
            printf( "pcisigWriteIO failed with 0x%x\n", status );
            goto ExerciseIO_end;
    }

    dataBuf=0;
    printf("Reading 32 bits from 0xCFC = 0x%X\n", dataBuf);
    status = pcisigReadIO(devHandle, PCISIG_IO_SIZE_32, IO_DATA, &dataBuf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
            printf( "pcisigWriteIO failed with 0x%x\n", status );
            goto ExerciseIO_end;
    }

    dataBuf=0;
    printf("Reading 16 bits from 0xCFC = 0x%X\n", dataBuf);
    status = pcisigReadIO(devHandle, PCISIG_IO_SIZE_16, IO_DATA, &dataBuf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
            printf( "pcisigWriteIO failed with 0x%x\n", status );
            goto ExerciseIO_end;
    }

    dataBuf=0;
    printf("Reading 8 bits from 0xCFC = 0x%X\n", dataBuf);
    status = pcisigReadIO(devHandle, PCISIG_IO_SIZE_8, IO_DATA, &dataBuf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
            printf( "pcisigWriteIO failed with 0x%x\n", status );
            goto ExerciseIO_end;
    }

ExerciseIO_end:
    return;
}

// For Arm64 pcisigLibWalkPCIBusLegacy is expected to report failure
void EnumeratePCI(deviceData* devHandle)
{
    UINT32      status;
    char        buf[PCISIG_PCI_MCFG_SIZE];
    UINT32      arraySizeIO, arraySize;
    pciDevice   devArray[PCISIG_MAX_PCI_DEVICES];
    UINT32      mcfgBaseLow, mcfgBaseHigh;

    
    // Get the MCFG ACPI Value, it will be returned in the buffer
    status = pcisigGetMCFGAddr(devHandle, buf);
    if ( status != IOCTL_STATUS_SUCCESS )
    {
        printf( "pcisigGetMCFGAddr failed with 0x%x\n", status );
        goto Enumerate_PCI_end;
    }
    
    dumpMcfgTable(buf, &mcfgBaseLow, &mcfgBaseHigh); // Dump out the full MCFG Table     
    printf("\n Enumeratng full PCIe Topology:\n");
    do {
        arraySizeIO = 0; 
        arraySize = 0;

        printf("Segment Number = 0x%X\n", devHandle->pcinode->segmentNum);
        printf(" BaseAddr = 0x%08X %08X\n", devHandle->pcinode->mcfgBaseHigh, devHandle->pcinode->mcfgBaseLow);
        printf(" StartBus = 0x%02X\n", devHandle->pcinode->startBus);
        printf(" EndBus   = 0x%02X\n", devHandle->pcinode->endBus);
        // For Arm64 pcisigLibWalkPCIBusLegacy is expected to report failure
#if defined(_M_ARM64) // Arm64 does not support IOPort access to config space 
    printf("\nExpect pcisigLibWalkPCIBusLegacy call to return failure for Arm64\n");
#endif
        status = pcisigLibWalkPCIBusLegacy(devHandle, devArray, PCISIG_MAX_PCI_DEVICES, &arraySizeIO, devHandle->pcinode->startBus, devHandle->pcinode->endBus);
        if (status == IOCTL_STATUS_SUCCESS)
        {
            DumpPCIArray(devArray, arraySizeIO);
            printf("Devices Found via IO Method = %d = 0x%X\n\n", arraySizeIO, arraySizeIO);
        }
        else
            printf("pcisigLibWalkPCIBusLegacy failed with 0x%X - Failure expected for non-zero Segment Number\n", status);

        status = pcisigWalkPCIBusMcfg(devHandle, devHandle->pcinode->segmentNum, devArray, PCISIG_MAX_PCI_DEVICES, &arraySize, devHandle->pcinode->startBus, devHandle->pcinode->endBus);
        if (status == IOCTL_STATUS_SUCCESS)
        {
            DumpPCIArrayMcfg(devHandle->pcinode->segmentNum, devArray, arraySize);
            printf("Devices Found via ECAM method = %d = 0x%X\n\n", arraySize, arraySize);
        }
        else
            printf("pcisigWalkPCIBusMcfg failed with 0x%X\n", status);

#if !defined(_M_ARM64) // ARM64 does not support IO access to CFG space
        if (arraySizeIO != arraySize)
            printf("PCI Devices found don't match between Legacy I/O and ECAM methods:  I/O Devices=%d, ECAM Devices=%d\n", arraySizeIO, arraySize);
#endif
        
        devHandle->pcinode = devHandle->pcinode->next; // Point to next Segment Entry (if any)

    } while (devHandle->pcinode != NULL);

Enumerate_PCI_end:
    return;
}

int test_main(int argC, char *argV[])
{

    UINT32          status;
    deviceData*     devHandle;
    BOOLEAN         dumpPCI = FALSE;
    BOOLEAN         runAllTests = FALSE;
    BOOLEAN         runStress = FALSE;
    BOOLEAN         specDev = FALSE, specMem = FALSE, specLoop = FALSE, specData = FALSE;
    INT32           opt;
    PCHAR           svalue;
    UINT32          segment=0, bus=0, device=0, function=0;
    UINT32          memAddrLow=0, memOffset = 0, memAddrHigh = 0xFF;
    UINT32          dataDirection = 0, dataSize = 0, dataValue = 0;
    UINT32          iLoop, numLoop=1;
    INT32           rc;

#if 1
    PCHAR           logFileName = "Driver.log"; // Send output to file in current directory
#else
    PCHAR           logFileName = ""; // Sends output to console
#endif
    struct mCfgNodeLibOverRide overRide = {0}; // Nothing overridden by default

    memset(&overRide, 0, sizeof(struct mCfgNodeLibOverRide));
#if 1
    // Lets overRide the endbus to be 0x4
    overRide.bitMaskOverride = 0;
//    overRide.bitMaskOverride |= PCISIG_OVERRIDE_MCFG_ENDBUS;
//    overRide.endBus = 0x4;
#else // Hard-coded values consistent with Segment #1 on Wilson, Archer
    overRide.segmentNum = 1;
    overRide.bitMaskOverride = 0;
    overRide.bitMaskOverride |= PCISIG_OVERRIDE_MCFG_BASELOW;
    overRide.mcfgBaseLow = 0x90000000;
    overRide.bitMaskOverride |= PCISIG_OVERRIDE_MCFG_BASEHIGH;
    overRide.mcfgBaseHigh = 0x00000000;
    overRide.bitMaskOverride |= PCISIG_OVERRIDE_MCFG_STARTBUS;
    overRide.startBus = 0x0;
    overRide.bitMaskOverride |= PCISIG_OVERRIDE_MCFG_ENDBUS;
    overRide.endBus = 0x4; // Chop it off at 4 bus for sake of ease
#endif
    if (argC == 1)
    {
        dumpPCI = TRUE;
        goto start;
    }
    while ((opt = getopt(argC, argV, "daxh?s:m:l:r:w:")) != -1)
    {
        //printf("option = %c optarg = %s\n", opt, optarg);
        switch (opt)
        {
            case 'd':
                dumpPCI = TRUE;
                break;
           case 's':
                svalue = optarg;
                if (svalue == NULL)
                {
                    printf("s:b:d:f unreadable, exiting\n");
                    exit(0);
                }
                rc = sscanf(svalue, "%X:%X:%X:%X", (UINT32*)&segment, (UINT32*)&bus, (UINT32*)&device, (UINT32*)&function);
                if (rc != FALSE)
	           specDev = TRUE;
                //isCaseInsensitive = TRUE;
                break;
            case 'm':
                svalue = optarg;
                if (svalue == NULL)
                {
                    printf("m unreadable, exiting\n");
                    exit(0);
                }
                rc = sscanf(svalue, "0x%X:0x%X", (UINT32*)&memAddrHigh, (UINT32*)&memAddrLow);
                memOffset = memAddrLow & PAGE_MASK;
                memAddrLow &= ~PAGE_MASK; //0xFFFFF000;
                specMem = TRUE;
                break;
            case 'r':
                svalue = optarg;
                if (svalue == NULL)
                {
                    printf("r unreadable, exiting\n");
                    exit(0);
                }
                rc = sscanf(svalue, "0x%X", (UINT32*)&dataSize);
                dataDirection = PCISIG_CMD_READ;
                specData = TRUE;
                break;
            case 'w':
                svalue = optarg;
                if (svalue == NULL)
                {
                    printf("w unreadable, exiting\n");
                    exit(0);
                }
                rc = sscanf(svalue, "0x%X:0x%X", (UINT32*)&dataSize, (UINT32*)&dataValue);
                dataDirection = PCISIG_CMD_WRITE;
                specData = TRUE;
                break;
            case 'l':
                svalue = optarg;
                if (svalue == NULL)
                {
                    printf("l unreadable, exiting\n");
                    exit(0);
                }
                rc = sscanf(svalue, "0x%X", (UINT32*)&numLoop);
                specLoop = TRUE;
                //isCaseInsensitive = TRUE;
               break;
            case 'a':
                runAllTests = TRUE;
                break;
            case 'x':
                runStress = TRUE;
                break;
            case 'h':
            case '?':
            default:
                fprintf(stderr, "Usage: %s -d [-s] [s:b:d:f] -a -x -m 0x0:0x0 -l 0x0 -r 0x1 -w 0x1:0x0\n", argV[0]);
                fprintf(stderr, "No Parameters, just walks PCI 2 ways and dumps MCFG\n");
                fprintf(stderr, "-d walks PCI 2 ways and dumps MCFG\n");
                fprintf(stderr, "-s s:b:d:f  dumps out the first 256 bytes of that device\n");
                fprintf(stderr, "-a Run all tests against the specific PCI Device\n");
                fprintf(stderr, "-x Run stress test against the specific PCI Device\n");
                fprintf(stderr, "-m Memory Address for RW Tests (MMIO)\n");
                fprintf(stderr, "-r Data Size to Read for RW Tests (MMIO)\n");
                fprintf(stderr, "-w Data Size and Value to Write for RW Tests (MMIO)\n");
                fprintf(stderr, "-l Number of times to loop the test\n");
                exit(0);
                break;
        }
    }

start:
    printf("Entering PCISIG Test Program\n");

    // Open the Driver
    // ToDo: Get back a handle
    status = pcisigDriverOpen(&devHandle, PCISIGLOG_INFO | PCISIGLOG_DEBUG | PCISIGLOG_ERROR , logFileName, PCISIG_TIMESTAMP_ABSOLUTE, &overRide, TRUE);
    //status = pcisigDriverOpen(&devHandle, PCISIGLOG_ERROR | PCISIGLOG_DEBUG, logFileName, PCISIG_TIMESTAMP_ABSOLUTE, &overRide, TRUE);
    //status = pcisigDriverOpen(&devHandle, PCISIGLOG_ERROR | PCISIGLOG_DEBUG, NULL, PCISIG_TIMESTAMP_ABSOLUTE, &overRide, TRUE);
    //status = pcisigDriverOpen(&devHandle, PCISIGLOG_DEBUG, logFileName, PCISIG_TIMESTAMP_ABSOLUTE, &overRide, TRUE);
    //status = pcisigDriverOpen(&devHandle, PCISIGLOG_INFO | PCISIGLOG_DEBUG, NULL, PCISIG_TIMESTAMP_ABSOLUTE, &overRide, TRUE); //PCISIGLOG_INFO
    if ( status != IOCTL_STATUS_SUCCESS )
    {
      printf( "open interface failed with 0x%x\n", status );
      if (status == IOCTL_STATUS_DRIVER_NOTFOUND)
          printf("Driver is not found, it may not be installed\n");
      return 0;
    }
    printf("Library Version = 0x%X; Driver Version = 0x%X\n", devHandle->libVer, devHandle->drvVer);
    if (devHandle->libVer != devHandle->drvVer)
        printf("WARNING:  Driver and Library version mismatch - may cause incompatibilities.\n"); // TODO - Allow minor (non-api) mismatches; disallow Major (API change) mismatches

    if (specLoop == TRUE)
        printf("Will loop = 0x%X\n", numLoop);

    for (iLoop = 0; iLoop < numLoop; iLoop++)
    {
        if (dumpPCI == TRUE)
        {
            // Since we only have no arguments, lets only walk the PCI Bus
            EnumeratePCI(devHandle);
            // Exercise the I/O
            ExerciseIO(devHandle);
        }
        if (specMem == TRUE)
        {
            printf("memAddrHigh = 0x%X\n", memAddrHigh);
            printf("memAddrLow = 0x%X\n", memAddrLow);
            printf("memOffset = 0x%X\n", memOffset);
        }

        if (specDev == TRUE)
        {
            DumpSpecficPCIDev(devHandle, runAllTests, segment, bus, device, function);
            if (runStress == TRUE)
            {
                if (StressDumpSpecficPCIDev(devHandle, segment, bus, device, function) == 1)
                    goto end;
            }
            if (runAllTests == TRUE)
            {
                ExerciseBars(devHandle, segment, bus, device, function);
                ExerciseGetSetRoutineWritesOddIO(devHandle, segment, bus, device, function);
                ExerciseGetSetRoutineWritesOddMCFG(devHandle, segment, bus, device, function);
                ExerciseGetSetRoutines(devHandle, segment, bus, device, function);
                ExercisePCIBits(devHandle, segment, bus, device, function);
                ExerciseRWMemory(devHandle, segment, bus, device, function, memAddrHigh, memAddrLow, memOffset, specData, dataDirection, dataSize, dataValue); // TODO - too dangerous if no memory physical accessible - can crash system
                ExerciseOddAccessMCFG(devHandle, segment, bus, device, function);
                ExerciseOddAccessIO(devHandle, bus, device, function);
                ExercisewrDelayRdFunction(devHandle, segment, bus, device, function);
            }
        }
    }

end:
    pcisigCloseDriver(devHandle);

    return 0;
}

#ifndef _PCISIG_WIN_
int main(int argC, char *argV[])
{
    test_main(argC, argV);
}
#endif
