/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisiglib_interface.h
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#ifndef _pcisiglib_interface_h
#define _pcisiglib_interface_h

#ifdef _PCISIG_WIN_
#define useconds_t  unsigned int
#endif

typedef struct
{
    UINT16  segment;
    UINT8   bus;
    UINT8   device;
    UINT8   function;
    UINT8   padding;
    UINT16  padding2;
    UINT16  vendorId;
    UINT16  deviceId;
} pciDevice;

// Mcfg linked list structure
// One is created for each segment
// Dynamically allocated and torn down
struct mCfgNodeLib {
    UINT16 segmentNum;
    UINT8  startBus;
    UINT8  endBus;
    UINT32 mcfgBaseLow;
    UINT32 mcfgBaseHigh;
    struct mCfgNodeLib* next;
};

// deviceData Structure
// pcinode - Pointer to a linked list that contains the MCFG Table from the ACPI Table
//           The structure is defined above.
// semId - ID for the semaphore
// myPID - ID for this process (currently unused)
// libVer - Version of the library
// drvVer - Version of the driver
// memPhysAddr* - Address of Physical Memory allocated for testing.  See DriverOpen
typedef struct
{
    struct mCfgNodeLib*     pcinode;
#ifdef _PCISIG_SEM_
    sem_t*                  semId;
#endif
#ifndef _PCISIG_WIN_
    // Linux
    pid_t                   myPid;
    int                     hDev;
#else
    // Windows
    HANDLE                  hDev;
#endif
    UINT32                  libVer;
    UINT32                  drvVer;
    UINT32                  memPhysAddrLow;
    UINT32                  memPhysAddrHigh;
} deviceData;

#ifndef _PCISIG_WIN_
#define DECLDIR extern
#else
#define DECLDIR __declspec(dllexport)
#endif


#ifdef _PCISIG_WIN_
#ifdef __cplusplus
extern "C"
{
#endif
#endif
//
// Open a handle to the Driver.
//
// Log levels are defined in the pcisig_common.h file, they are OR'd together when calling this function
//
// Override Structure is passed in in order to override the MCFG ACPI Table value
// The mCfgNodeLibOverRide (defined in pcisig_common.h), takes a bit mask for which values need to be overriden
// The segmentNum element is used to match the segment that needs overriding.
// Passing in a NULL value means that nothing will be overriden and the ACPI MCFG Table values are used
//
// bAllocPhys when set to true, sets the memPhysAddr* values in the devHandle return structure.
// This is a 4K buffer used for testing, its preloaded with a incrementing byte pattern (0-FF)
// This physical address can be read/written using pcisigRWMemory with PCISIG_MAP_TYPE_MEM
//
DECLDIR UINT32 pcisigDriverOpen(deviceData** devHandle,                 // Handle to the instance specific structure
                               UINT8 logLevelAccept,                    // Bit Mask of which levels will be logged
                               PCHAR logFileName,                       // Pointer to the filename for the log.  NULL redirects to stdout
                               UINT8 logTimestampFormat,                // PCISIG_TIMESTAMP_ABSOLUTE or PCISIG_TIMESTAMP_RELATIVE
                               struct mCfgNodeLibOverRide *overRide,    // Structure of MCFG ACPI values to override (otherwise NULL)
                               BOOLEAN bAllocPhys);                     // When true, populates the memPhysAddr* in devHandle. Used for testing.
//
// Close the handle to the Driver
//
DECLDIR UINT32 pcisigCloseDriver(deviceData* devHandle);

//
// Get the MCFG ACPI Table
//
DECLDIR UINT32 pcisigGetMCFGAddr(deviceData* devHandle,         // Handle to the instance specific structure
                                 PCHAR buffer);                 // Pointer to a buffer of size 4096

//
// Read / Write 1, 2, 4 or up to 4096 bytes from Config Space using the MCFG register
// Note: If you request more than 4 bytes, it must be divisible by 4
//
DECLDIR INT32 pcisigGetSetPciConfigMcfg(deviceData* devHandle,  // Handle to the instance specific structure
                                        UINT16 segment,         // domain/segment number
                                        UINT8 bus,              // bus number
                                        UINT8 device,           // device number
                                        UINT8 function,         // function number
                                        UINT32 command,         // PCISIG_CMD_READ or PCISIG_CMD_WRITE
                                        UINT32 rwSize,          // Size of access (default PCISIG_SIZE_AUTO)
                                        PCHAR retBuffer,        // Buffer to return
                                        UINT32 startOffset,     // Offset into PCI Space
                                        UINT32 bufSize);        // Total Size


DECLDIR INT32 pcisigGetSetPciConfigIO(  deviceData* devHandle,  // Handle to the instance specific structure
                                        UINT8 bus,              // bus number
                                        UINT8 device,           // device number
                                        UINT8 function,         // function number
                                        UINT32 command,         // PCISIG_CMD_READ or PCISIG_CMD_WRITE
                                        UINT32 rwSize,          // Size of access (default PCISIG_SIZE_AUTO)
                                        PCHAR retBuffer,        // Buffer to return
                                        UINT32 startOffset,     // Offset into PCI Space
                                        UINT32 bufSize);        // Total Size

//
// Sizes the BAR for a specific PCI Device
// Supports Bridge Devices, and MCFG or I/O
//
DECLDIR INT32 pcisigSizeBar(            deviceData* devHandle,  // Handle to the instance specific structure
                                        UINT16 segment,         // domain/segment number
                                        UINT8 bus,              // bus number
                                        UINT8 device,           // device number
                                        UINT8 function,         // function number
                                        BOOLEAN bBridgeDevice,  // Specifies we have a Bridge Device (2 Bars)
                                        BOOLEAN bUseMcfg,       // Specifies the use of MCFG or IO
                                        PCHAR retBuffer,        // Buffer to return
                                        UINT32 bufSize);        // Total Size

DECLDIR INT32 pcisigLibWalkPCIBusLegacy(deviceData* devHandle,      // devHandle passed back in Open()
                                        pciDevice* arrayDevices,    // Array of PCI Devices (returned)
                                        UINT32 numTotal,            // Total Number of devices - 0 for error
                                        UINT32 *retDevices,         // Number of devices found
                                        UINT8 startBus,             // Override startBus
                                        UINT8 lastBus);             // Override Lastbus

DECLDIR INT32 pcisigwrRdCfgReg(         deviceData* devHandle,      // devHandle passed back in Open()
                                        UINT8 method,               // Method to be used: PCISIG_MCFG_METHOD or PCISIG_IO_METHOD
                                        UINT16 segment,             // domain/segment number
                                        UINT8 bus,                  // bus number
                                        UINT8 device,               // device number
                                        UINT8 function,             // function number
                                        UINT16 offset,              // Offset to Write/Read
                                        UINT32 dataSize,            // DataSize of data (8/16/32)
                                        UINT32 wrVal,               // Value to Write to Offset
                                        useconds_t delay,           // Delay between Write and Read in uSeconds
                                        UINT32 *rdVal);             // Value that was Read back

DECLDIR INT32 pcisigWalkPCIBusMcfg(     deviceData* devHandle,      // devHandle passed back in Open()
                                        UINT16 segment,             // domain/segment number
                                        pciDevice* arrayDevices,    // array of PCI devices (per segment)
                                        UINT32 numTotal,            // Total size of array
                                        UINT32 *retDevices,         // Number of devices found
                                        UINT8 startBus,             // Override startBus
                                        UINT8 lastBus);             // Override Lastbus

DECLDIR INT32 pcisigReadIO(             deviceData* devHandle,      // Handle to the instance specific structure
                                        UINT32 dataSize,            // DataSize of Buffer
                                        UINT32 readAddress,         // Address to Read
                                        UINT32 *data);              // Pointer to the Buffer

DECLDIR INT32 pcisigWriteIO(            deviceData* devHandle,      // Handle to the instance specific structure
                                        UINT32 dataSize,            // DataSize of Buffer
                                        UINT32 writeAddress,        // Address to Write
                                        UINT32 data);               // Pointer to the Buffer

DECLDIR INT32 pcisigRWMemory(           deviceData* devHandle,      // Handle to the instance specific structure
                                        UINT32 command,             // PCISIG_CMD_READ or PCISIG_CMD_WRITE
                                        UINT32 bufSize,             // Size of Buffer
                                        UINT32 rwSize,              // Size of access (default PCISIG_SIZE_AUTO)
                                        UINT32 memType,             // Type of Memory to Map (PCISIG_MAP_TYPE_MMIO or
                                                                    // PCISIG_MAP_TYPE_MEM)
                                        UINT32 RWAddressLow,        // Address to Read/Write - lower 32 bits
                                        UINT32 RWAddressHigh,       // Address to Read/Write - upper 32 bits
                                        PCHAR retBuffer,            // Pointer to the Buffer
                                        UINT32 startOffset);        // Offset vs the main address
#ifdef _PCISIG_WIN_
#ifdef __cplusplus
}
#endif
#endif

#define PCISIG_IO_SIZE_8                0x1
#define PCISIG_IO_SIZE_16               0x2
#define PCISIG_IO_SIZE_32               0x3
#define PCISIG_MEM_SIZE_8               0x4
#define PCISIG_MEM_SIZE_16              0x5
#define PCISIG_MEM_SIZE_32              0x6

#define PAGE_MASK                       ((1 << 12)-1)

#define PCISIG_TIMESTAMP_ABSOLUTE       0x1
#define PCISIG_TIMESTAMP_RELATIVE       0x2

#define PCISIG_MAX_USLEEP               1000000

#define FIRST_TIME_DRIVER_OPENED        1
#define WAIT_SEMAPHORE_1_SECOND         1000

#endif
