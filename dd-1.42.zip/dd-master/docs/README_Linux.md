# PCI-SIG Device Driver Build and Install Instructions

Kernel Mode Device Driver

32 Bit Specific Instructions

For 32-bit, our target is Ubuntu 18.04 LTS as this was the last supported 32-bit Ubuntu distro.

#**** IMPORTANT CHANGE FOR 32-bit LINUX ****
For 32 Bit, increase the vmalloc size using the directions at: http://thinking-electron.blogspot.com/2015/05/how-to-increase-vmalloc-size-vmalloc.html
use vmalloc=512M
*************

#** Driver Instructions for both 32 and 64 bit Linux **

For 64-bit, our target is Ubuntu 20.04.2 LTS.

1) *** Configure environment ready to build PCI-SIG Device Driver ***

From a Terminal window,

$ sudo apt install
$ sudo apt install build-essential
$ sudo apt install linux-headers-$(uname -r)

$ ls -l /usr/src/linux-headers-`uname -r`
total 1664
drwxr-xr-x 3 root root    4096 Jun 22 17:18 arch
lrwxrwxrwx 1 root root      39 Jun 16 20:25 block -> ../linux-hwe-5.8-headers-5.8.0-59/block
lrwxrwxrwx 1 root root      39 Jun 16 20:25 certs -> ../linux-hwe-5.8-headers-5.8.0-59/certs
lrwxrwxrwx 1 root root      40 Jun 16 20:25 crypto -> ../linux-hwe-5.8-headers-5.8.0-59/crypto
lrwxrwxrwx 1 root root      47 Jun 16 20:25 Documentation -> ../linux-hwe-5.8-headers-5.8.0-59/Documentation
lrwxrwxrwx 1 root root      41 Jun 16 20:25 drivers -> ../linux-hwe-5.8-headers-5.8.0-59/drivers
lrwxrwxrwx 1 root root      36 Jun 16 20:25 fs -> ../linux-hwe-5.8-headers-5.8.0-59/fs
drwxr-xr-x 4 root root    4096 Jun 22 17:18 include
lrwxrwxrwx 1 root root      38 Jun 16 20:25 init -> ../linux-hwe-5.8-headers-5.8.0-59/init
lrwxrwxrwx 1 root root      37 Jun 16 20:25 ipc -> ../linux-hwe-5.8-headers-5.8.0-59/ipc
lrwxrwxrwx 1 root root      40 Jun 16 20:25 Kbuild -> ../linux-hwe-5.8-headers-5.8.0-59/Kbuild
lrwxrwxrwx 1 root root      41 Jun 16 20:25 Kconfig -> ../linux-hwe-5.8-headers-5.8.0-59/Kconfig
drwxr-xr-x 2 root root    4096 Jun 22 17:18 kernel
lrwxrwxrwx 1 root root      37 Jun 16 20:25 lib -> ../linux-hwe-5.8-headers-5.8.0-59/lib
lrwxrwxrwx 1 root root      42 Jun 16 20:25 Makefile -> ../linux-hwe-5.8-headers-5.8.0-59/Makefile
lrwxrwxrwx 1 root root      36 Jun 16 20:25 mm -> ../linux-hwe-5.8-headers-5.8.0-59/mm
-rw-r--r-- 1 root root 1671302 Jun 16 20:25 Module.symvers
lrwxrwxrwx 1 root root      37 Jun 16 20:25 net -> ../linux-hwe-5.8-headers-5.8.0-59/net
lrwxrwxrwx 1 root root      41 Jun 16 20:25 samples -> ../linux-hwe-5.8-headers-5.8.0-59/samples
drwxr-xr-x 8 root root   12288 Jun 22 17:18 scripts
lrwxrwxrwx 1 root root      42 Jun 16 20:25 security -> ../linux-hwe-5.8-headers-5.8.0-59/security
lrwxrwxrwx 1 root root      39 Jun 16 20:25 sound -> ../linux-hwe-5.8-headers-5.8.0-59/sound
drwxr-xr-x 3 root root    4096 Jun 22 17:18 tools
lrwxrwxrwx 1 root root      40 Jun 16 20:25 ubuntu -> ../linux-hwe-5.8-headers-5.8.0-59/ubuntu
lrwxrwxrwx 1 root root      37 Jun 16 20:25 usr -> ../linux-hwe-5.8-headers-5.8.0-59/usr
lrwxrwxrwx 1 root root      38 Jun 16 20:25 virt -> ../linux-hwe-5.8-headers-5.8.0-59/virt


2) ** Build the Driver, Library Code, and Test Code **

** The unzipped files are put in the ~/dd directory **

$ ll
total 1332
drwxrwxr-x  3 pci pci    4096 Jun 30 11:10 ./
drwxr-xr-x 31 pci pci    4096 Jun 30 11:09 ../
-rw-rw-r--  1 pci pci    7141 Jun 30 10:19 boot_instructions.md
-rwxrwxr-x  1 pci pci     539 May 24 13:38 buildlib_gendrv*
-rw-rw-r--  1 pci pci 1064059 Jun  5 01:16 driver_install.txt
drwxrwxr-x  8 pci pci    4096 Jun 30 11:09 .git/
-rw-rw-r--  1 pci pci      53 Jun 30 10:19 .gitignore
-rw-rw-r--  1 pci pci    1239 Jun 30 10:19 Makefile
-rw-rw-r--  1 pci pci   30356 Jun 30 10:19 oldmodulecode.c
-rw-rw-r--  1 pci pci    7850 Jun 30 10:19 pcisig_common.h
-rw-rw-r--  1 pci pci   10277 Jun 30 10:19 pcisiglib_interface.h
-rw-rw-r--  1 pci pci   47883 Jun 30 10:19 pcisig_library.c
-rw-rw-r--  1 pci pci   61947 Jun 30 10:19 pcisig_module.c
-rwxrwxr-x  1 pci pci   70257 Jun 30 10:19 pcisig_test.c*
-rw-rw-r--  1 pci pci   19661 May 24 13:38 README.md
-rwxrwxr-x  1 pci pci     322 Jun 30 10:19 runtest.sh*

$ cd linux
$ make
make -C /usr/src/linux-headers-5.8.0-59-generic/ M=/home/pci/ddmaster modules
make[1]: Entering directory '/usr/src/linux-headers-5.8.0-59-generic'
  CC [M]  /home/pci/ddmaster/pcisig_module.o
  MODPOST /home/pci/ddmaster/Module.symvers
  CC [M]  /home/pci/ddmaster/pcisig_module.mod.o
  LD [M]  /home/pci/ddmaster/pcisig_module.ko
make[1]: Leaving directory '/usr/src/linux-headers-5.8.0-59-generic'
gcc   -D_DEBUG_LOGS_ -D_AMD64_ -Wall -Wl,-export-dynamic -fPIC -g -O2   -c -o pcisig_library.o pcisig_library.c
gcc   -D_AMD64_ -Wall -g -shared -Wl,-R -Wl,.    -o libpcisig.so pcisig_library.o -lc
gcc   -D_DEBUG_LOGS_ -D_AMD64_ -Wall -Wl,-export-dynamic -fPIC -g -O2   -c -o pcisig_test.o pcisig_test.c
gcc   -D_AMD64_ -Wall -g pcisig_test.o -L. -lpcisig -o pcisig_test -pthread

3) ** Install and verify device driver installed **

$ sudo insmod pcisig_module.ko
$ lsmod | grep pcisig_module
pcisig_module          24576  0


4) ** Run the Test Code **
Note that this script install the device driver if needed, 
and will remove the device driver after completion of the script

$ sudo ./runtest.sh pcisig_module
rmmod: ERROR: Module pcisig_module is not currently loaded
Entering PCISIG Test Program
We have a Library Version = 0x104 and Driver Version = 0x104
Dumping out the RAW (non-overriden) MCFG Table
acpiTableSize = 0x60
PCI Segment Groups: = 0x1
segment = 0x0
startBus = 0x0 endBus = 0x7F
mcfgBaseLow = 0xF0000000 mcfgBaseHigh = 0x0
------- End dumping MCFG ACPI Table

 Enumeratng the PCI Bus
The library has the following information (post override)
segment = 0x0
startBus = 0x0 endBus = 0x7F
mcfgBaseLow = 0xF0000000 mcfgBaseHigh = 0x0
About to call pcisigLibWalkPCIBusLegacy
   BDF  VenID DevID
[00:00:0]=8086 7190
[00:01:0]=8086 7191
...
...
[0000:03:00:0]=15AD 07F0
Devices Found = 49 = 0x31

About to call pcisigWalkPCIBusMcfg for segment 1, expecting failure
pcisigWalkPCIBusMcfg failed with 0x12

 Exercising the I/O functions
Writing 32 bits to 0xCF8 = 0x80000000
Reading 32 bits from 0xCFC = 0x71908086
Reading 16 bits from 0xCFC = 0x8086
Reading 8 bits from 0xCFC = 0x86

5) Study the source code to build your own application around this device driver
