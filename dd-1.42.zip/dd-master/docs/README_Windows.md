
# Installing VS2019 for Building the PCISIG Driver/Library/Test stack

Install VS2019 Professional or VS219 Community 
 
Follow the steps to install the WDK
 
https://docs.microsoft.com/en-us/windows-hardware/drivers/download-the-wdk
 
Note the directions for installing VS2019
 
<mark>When you install Visual Studio 2019, select the Desktop development with C++ workload.</mark>
 
Step 2: Install Windows 11 SDK (22000.1)
 
Make sure VS2019 is closed, run the installer in the SDK .ISO
 
Step 3: Install WDK
 
Make sure VS2019, run the WDK Installer
 
Go back and run the VS2019 Installer and select the following:

![App Screenshot](image/image.png)


Now to Build the Library and Test App, install VS2010


Driver:

To Build the Driver, open up the .sln file under pcisig_driver using VS2019.  Build the desired configuration (eg. x64 Release)

The driver will be built in a directory called pcisig_driver under x64/Release in this example

Test Application & Libary:

To Build the Test App and DLL, open the .sln file under pcisig_driver_test in VS2019, and don't let it upgrade the toolset.  It should show VS2010 in brackets next to the solution name to indicate it's a VS2010 Solution/Project
Build the desired configuration (eg. x64 Debug)
It will place the .exe and .dll under x64/Debug in this example

If you want to run the test app and have the driver load dynamically, place the binaries in this format (eg. directory is \Release)
.\Release\pcisig_driver_test.exe
.\Release\pcisig_driver_lib.dll 
.\Release\pcisig_driver (<- from the driver you built.  It will contain the .INF,.CAT and .sys file under x64 or i386)

Then run the test app from an administrator command prompt.
The 64 bit binary can dynamically load the 64 bit driver, and the 32 bit binary can dynamically load the 32 bit driver.  However, the 32 bit binary cannot dynamically load the 64 bit driver on a 64 bit system.

Please see the Linux driver README for the options, etc. when running the test code.

# Signing the Windows Driver with the EV Cert

Step 1: Build the 32 Bit Driver in Release Mode  
Step 2: Build the 64 Bit Driver in Release Mode  
Step 3: Run the batch file prepsigning.bat.  This will create the directory cabtosign with all the required files.  
Step 4: Open a command prompt as Administrator  
Step 5: C:\Users\vtm\Downloads\cabtosign>makecab /f pcisig.ddf  
Cabinet Maker - Lossless Data Compression Tool  

42,728 bytes in 3 files  
Total files:              3  
Bytes before:        42,728  
Bytes after:         20,386  
After/Before:            47.71% compression  
Time:                     0.14 seconds ( 0 hr  0 min  0.14 sec)  
Throughput:             295.93 Kb/second  
  
Step 6: Locate the .cab file under the disk1 directory  

C:\Users\vtm\Downloads\cabtosign>cd disk1  
  
C:\Users\vtm\Downloads\cabtosign\disk1>dir  
Volume in drive C has no label.  
Volume Serial Number is C2F2-8EFD  
 
Directory of C:\Users\vtm\Downloads\cabtosign\disk1  

07/31/2021  03:55 PM    \<DIR\>          .  
07/31/2021  03:55 PM    \<DIR\>          ..  
07/31/2021  03:55 PM            20,599 pcisig_driver.cab  
1 File(s)         20,599 bytes  
2 Dir(s)  220,589,465,600 bytes free  

### YubiKey Signing:

Step 7: (Use the latest SDK) cd ‘C:\Program Files (x86)\Windows Kits\10\bin\10.0.19041.0\x64’  
Step 8: Sign the file: .\signtool.exe sign /fd sha256 /tr http://ts.ssl.com /td sha256 /n "PCI-SIG" "C:\pci\Retry\pcisig_driver.cab"  
Note: /n "PCI-SIG" tells the signing tool to use the pci-sig certificate on the YubiKey token; this is the required SHA256 certificate
You should be prompted to enter the PIN for the Yubi-key at this point
Step 9: Save the newly signed pcisig_driver.cab file  

### E-Signer Signing:

Step 7: Login into https://express.esigner.com  
Step 8: Drop the pcisig_driver.cab on the page for EV Cert Signing.  Enter the 2 Factor Authentication Code.  
Step 9: Download the signed pcisig_driver.cab file  

### Submit cab file to Microsoft:

Step 10: Login into Partner Central at https://partner.microsoft.com/en-us/dashboard/hardware/Search  
Step 11: Click on Submit New Hardware  
Step 12: Follow this screenshot, put in the proper product name and check the boxes for 
         Windows 10 Client, Windows 10 Client x64, Windows 11 Client x64
Step 13: Click on Submit.  The page will automatically refresh until it's complete.  It can take an hour to fully process, but errors return much sooner.
  
  
![App Screenshot](image/install1.png)
  
![App Screenshot](image/install2.png)
  
![App Screenshot](image/install3.png)
  
![App Screenshot](image/install4.png)
  
Step 14: Download the signed .zip file and distribute.
