Instructions to have the driver load automatically during boot

user@user-Parallels-Virtual-Platform:~$ cd /etc/modules-load.d/
user@user-Parallels-Virtual-Platform:/etc/modules-load.d$ ls
cups-filters.conf  modules.conf
user@user-Parallels-Virtual-Platform:/etc/modules-load.d$ sudo vi modules.conf


Add the bottom line to the file

# /etc/modules: kernel modules to load at boot time.
#
# This file contains the names of kernel modules that should be loaded
# at boot time, one per line. Lines beginning with "#" are ignored.
gendrv_module
~
~
~


Next we need to make sure the driver is in the correct path

Place the driver at
user@user-Parallels-Virtual-Platform:~$ cd /lib/modules/$(uname -r)/kernel/drivers/char
user@user-Parallels-Virtual-Platform:/lib/modules/5.4.0-73-generic/kernel/drivers/char$ ls
agp          dtlk.ko           hangcheck-timer.ko  ipmi   mwave        nvram.ko         pcmcia    raw.ko          sonypi.ko  tpm
applicom.ko  gendrv_module.ko  hw_random           lp.ko  nsc_gpio.ko  pc8736x_gpio.ko  ppdev.ko  scx200_gpio.ko  tlclk.ko   xillybus
user@user-Parallels-Virtual-Platform:/lib/modules/5.4.0-73-generic/kernel/drivers/char$

Update the database before rebooting
user@user-Parallels-Virtual-Platform:~$ sudo depmod



Removing kernel modules

Eg. Not a kernel module but rather built into the Linux kernel
00:0e.0 RAM memory: Red Hat, Inc. Virtio memory balloon
        Subsystem: Parallels, Inc. Virtio memory balloon
        Flags: bus master, fast devsel, latency 0, IRQ 22
        I/O ports at b000 [size=32]
        Kernel driver in use: virtio-pci

You can't remove/blacklist virtio-pci since it's compiled into the Kernel.  The only way to remove it would be
to recompile the kernel and unselect the driver.

user@user-Parallels-Virtual-Platform:/etc/modprobe.d$ modprobe -r virtio-pci
modprobe: FATAL: Module virtio_pci is builtin.


Some modules will unload easily.  Eg. pata_acpi

user@user-Parallels-Virtual-Platform:/etc/modules-load.d$ sudo rmmod -f pata_acpi
[sudo] password for user:
user@user-Parallels-Virtual-Platform:/etc/modules-load.d$




If you are using Debian / Ubuntu Linux…

open /etc/modprobe.d/blacklist.conf file and add drivername using following syntax:
blacklist driver-name

In this example, we try to unload the sound driver
user@user-Parallels-Virtual-Platform:/etc/modprobe.d$ sudo modprobe -r snd_hda_intel
modprobe: FATAL: Module snd_hda_intel is in use.

So it needs to be blacklisted.

user@user-Parallels-Virtual-Platform:/etc/modules-load.d$ cd ../modprobe.d/
user@user-Parallels-Virtual-Platform:/etc/modprobe.d$ ls
alsa-base.conf                  blacklist.conf              blacklist-modem.conf      blacklist-rare-network.conf     iwlwifi.conf
amd64-microcode-blacklist.conf  blacklist-firewire.conf     blacklist-oss.conf        dkms.conf                       prl_eth.conf
blacklist-ath_pci.conf          blacklist-framebuffer.conf  blacklist-parallels.conf  intel-microcode-blacklist.conf
user@user-Parallels-Virtual-Platform:/etc/modprobe.d$ sudo vi blacklist.conf

Add the blacklist line to the end of the file

# Conflicts with dvb driver (which is better for handling this device)
blacklist snd_aw2

# Causes trackpads to stop working on Lenovo 11e 2nd gen (Ubuntu: #1802135)
# and Lenovo x240 to hang on boot (Ubuntu: #1802689)
blacklist i2c_i801

# replaced by p54pci
blacklist prism54

# replaced by b43 and ssb.
blacklist bcm43xx

# most apps now use garmin usb driver directly (Ubuntu: #114565)
blacklist garmin_gps

# replaced by asus-laptop (Ubuntu: #184721)
blacklist asus_acpi

# low-quality, just noise when being used for sound playback, causes
# hangs at desktop session start (Ubuntu: #246969)
blacklist snd_pcsp

# ugly and loud noise, getting on everyone's nerves; this should be done by a
# nice pulseaudio bing (Ubuntu: #77010)
blacklist pcspkr

# EDAC driver for amd76x clashes with the agp driver preventing the aperture
# from being initialised (Ubuntu: #297750). Blacklist so that the driver
# continues to build and is installable for the few cases where its
# really needed.
blacklist amd76x_edac

blacklist snd_hda_intel

reboot the system

user@user-Parallels-Virtual-Platform:~$ lsmod | grep snd_
user@user-Parallels-Virtual-Platform:~$ sudo modprobe snd_hda_intel
[sudo] password for user:
user@user-Parallels-Virtual-Platform:~$ lsmod | grep snd_
snd_hda_codec_generic    73728  1
ledtrig_audio          16384  1 snd_hda_codec_generic
snd_hda_intel          36864  8
snd_intel_dspcfg       24576  1 snd_hda_intel
snd_hda_codec         118784  2 snd_hda_intel,snd_hda_codec_generic
snd_hda_core           81920  3 snd_hda_intel,snd_hda_codec,snd_hda_codec_generic
snd_hwdep              16384  1 snd_hda_codec
snd_pcm                94208  5 snd_hda_intel,snd_hda_codec,snd_hda_core
snd_seq_midi           20480  0
snd_seq_midi_event     16384  1 snd_seq_midi
snd_rawmidi            32768  1 snd_seq_midi
snd_seq                61440  2 snd_seq_midi_event,snd_seq_midi
snd_seq_device         16384  3 snd_seq,snd_rawmidi,snd_seq_midi
snd_timer              32768  4 snd_seq,snd_pcm
snd                    69632  21 snd_hda_intel,snd_hwdep,snd_seq,snd_hda_codec,snd_timer,snd_rawmidi,snd_hda_codec_generic,snd_seq_device,snd_pcm
user@user-Parallels-Virtual-Platform:~$

Note: The module will still be listed in lspci even when it's unloaded. So first check lspci then check using lsmod

user@user-Parallels-Virtual-Platform:~$ lsmod | grep snd*
aesni_intel            16384  0
crypto_simd            16384  1 aesni_intel
user@user-Parallels-Virtual-Platform:~$ lspci -v -s 0:1f.4
00:1f.4 Audio device: Intel Corporation 82801I (ICH9 Family) HD Audio Controller
        Subsystem: Parallels, Inc. 82801I (ICH9 Family) HD Audio Controller
        Flags: bus master, fast devsel, latency 0, IRQ 11
        Memory at f0280000 (32-bit, non-prefetchable) [size=16K]
        Capabilities: <access denied>
        Kernel modules: snd_hda_intel

user@user-Parallels-Virtual-Platform:~$ sudo modprobe snd_hda_intel
[sudo] password for user:
user@user-Parallels-Virtual-Platform:~$ lsmod | grep snd*
snd_hda_codec_generic    73728  1
ledtrig_audio          16384  1 snd_hda_codec_generic
snd_hda_intel          36864  8
snd_intel_dspcfg       24576  1 snd_hda_intel
snd_hda_codec         118784  2 snd_hda_intel,snd_hda_codec_generic
snd_hda_core           81920  3 snd_hda_intel,snd_hda_codec,snd_hda_codec_generic
snd_hwdep              16384  1 snd_hda_codec
snd_pcm                94208  5 snd_hda_intel,snd_hda_codec,snd_hda_core
snd_seq_midi           20480  0
snd_seq_midi_event     16384  1 snd_seq_midi
snd_rawmidi            32768  1 snd_seq_midi
snd_seq                61440  2 snd_seq_midi_event,snd_seq_midi
snd_seq_device         16384  3 snd_seq,snd_rawmidi,snd_seq_midi
snd_timer              32768  4 snd_seq,snd_pcm
snd                    69632  21 snd_hda_intel,snd_hwdep,snd_seq,snd_hda_codec,snd_timer,snd_rawmidi,snd_hda_codec_generic,snd_seq_device,snd_pcm
soundcore              16384  1 snd
aesni_intel            16384  0
crypto_simd            16384  1 aesni_intel
user@user-Parallels-Virtual-Platform:~$

