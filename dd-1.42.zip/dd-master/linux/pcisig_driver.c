/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_module.c
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#include <linux/uaccess.h>
#include <linux/compiler.h>
#include <linux/pci.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/acpi.h>
#include <acpi/acexcep.h>
#include "../common/pcisig_common.h"
#include <linux/miscdevice.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/printk.h>

#define PCISIG_REL      1
#undef  PCISIG_REL      
#define PFX "PCI-SIG> "

#ifdef PCISIG_REL
#undef pr_info
#define pr_info(fmt, ...)
#undef pr_warn
#define pr_warn(fmt, ...)
#endif

// Mcfg linked list structure
// One is created for each segment
// Dynamically allocated and torn down
struct mCfgNode {
    PVOID  pMcfg;
    UINT16 segmentNum;
    UINT8  startBus;
    UINT8  endBus;
    UINT32 mcfgBaseLow;
    UINT32 mcfgBaseHigh;
    struct mCfgNode* next;
};

struct pcisig_data {
    struct miscdevice misc_dev;
};

static UINT32               gEntryCount = 0;
static struct pcisig_data   *gData;

extern struct mCfgNode      *gsMcfg;
extern PVOID                gtestMem;

MODULE_LICENSE("Proprietary");
MODULE_AUTHOR("PCISIG");
#define PCISIG_DRIVER_VERSION_STR 	"1.42"
#define PCISIG_DRIVER_VERSION_NUM   0x0142
#define PCISIG_DRIVER_NAME          "pcisig"
MODULE_DESCRIPTION("PCISIG v" PCISIG_DRIVER_VERSION_STR " (C) 2023");


extern UINT32 pcisig_InitPCI(pcisigIoctl* inIoctl, pcisigIoctl* driverOut);
extern UINT32 pcisig_getMcfgACPI(pcisigIoctl* inIoctl, pcisigIoctl* outParam,
                                 UINT32 updateList);
#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space
extern UINT32 pcisig_ReadIO(UINT32 IOSize, UINT32 inputAddr);
extern void pcisig_WriteIO(UINT32 IOSize, UINT32 inputAddr, UINT32 inputData);
#endif

extern INT32 pcisigReadWritePCIMcfg(pcisigIoctl* inParam, pcisigIoctl* outParam, struct mCfgNode* inNode);
extern INT32 pcisigReadPCIConfig(BOOLEAN readIO, pcisigIoctl* inoutParam, struct mCfgNode* inNode);
extern INT32 pcisigWritePCIConfig(BOOLEAN writeIO, pcisigIoctl* inoutParam, struct mCfgNode* inNode);
extern UINT32 pcisig_TestFunctionMemory(pcisigIoctl* inParam, pcisigIoctl* outParam);
extern UINT32 pcisig_RWMemory(pcisigIoctl* inoutParam);
extern void pcisig_freeList(void);

// The shared functionality between the 2 Ioctl functions
// The compat_ioctl is required to support 32 bit applications
// on a 64 bit kernel
void pcisig_Ioctl_common(unsigned int cmd, pcisigIoctl *inIoctl, pcisigIoctl *driverOut)
{
    switch (cmd)
    {
        case PCISIG_IOCTL_INIT_PCI:
            // Called to initialize some basic PCI variables
            driverOut->outioctlStatus = pcisig_InitPCI(inIoctl, driverOut);
            break;
        case PCISIG_IOCTL_GET_DRV_VERSION:
            driverOut->outReturnData = PCISIG_DRIVER_VERSION_NUM;
            driverOut->outioctlStatus = IOCTL_STATUS_SUCCESS;
            break;
        case PCISIG_IOCTL_GET_MCFG:
            driverOut->outioctlStatus = pcisig_getMcfgACPI(inIoctl, driverOut, FALSE);
            break;
        case PCISIG_IOCTL_GETSET_PCI_CONFIG_MCFG:
            if (inIoctl->command == PCISIG_CMD_READ)
            {
                driverOut->outioctlStatus = pcisigReadPCIConfig(FALSE,inIoctl, NULL);
            }
            else
            {
                driverOut->outioctlStatus = pcisigWritePCIConfig(FALSE, inIoctl, NULL);
            }   
            break;
#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space

        case PCISIG_IOCTL_GETSET_PCI_CONFIG_IO:
            if (inIoctl->command == PCISIG_CMD_READ)
            {
                driverOut->outioctlStatus = pcisigReadPCIConfig(TRUE,inIoctl, NULL);
            }
            else
            {
                driverOut->outioctlStatus = pcisigWritePCIConfig(TRUE, inIoctl, NULL);
            }             
            break;
        case PCISIG_IOCTL_READ_IO:
            driverOut->outReturnData = pcisig_ReadIO(inIoctl->requestSize, inIoctl->requestAddrLow);
            driverOut->outioctlStatus = IOCTL_STATUS_SUCCESS;
            break;
        case PCISIG_IOCTL_WRITE_IO:
            pcisig_WriteIO(inIoctl->requestSize, inIoctl->requestAddrLow, inIoctl->inputData);
            driverOut->outioctlStatus = IOCTL_STATUS_SUCCESS;
            break;
#endif
        case PCISIG_IOCTL_RW_MEM_ADDR:
            driverOut->outioctlStatus = pcisig_RWMemory(inIoctl);
            break;
        case PCISIG_IOCTL_TEST_MEM:
            driverOut->outioctlStatus = pcisig_TestFunctionMemory(inIoctl, driverOut);
        default:
            break;
    }
    return;
}


// Main function that handles the IOCTL
// Core of the driver, it calls the correct function and returns the status
long pcisig_Ioctl_compat(struct file *filp, unsigned int cmd, unsigned long arg)
{
    UINT32 count;
    pcisigIoctl  *inIoctl, *driverOut;
    int retGetUser;

/*  pr_info( PFX "[%s] Compat Got IOCTL = 0x%X\n", __func__ , cmd); */
    
    if (cmd < PCISIG_IOCTL_INIT_PCI || cmd > PCISIG_IOCTL_TEST_MEM)
    {
        return IOCTL_STATUS_NOTFOUND;
    }
    
    inIoctl = kmalloc(sizeof(pcisigIoctl), GFP_KERNEL);
    if (inIoctl == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
    memset(inIoctl, 0, sizeof(pcisigIoctl));
    // Now we need to copy each parameter of the Ioctl Structure individually
    
    retGetUser = get_user(inIoctl->ioctlSignature, &(((pcisigIoctl*)arg)->ioctlSignature));
    if ( retGetUser != 0 )
    {
        pr_info( PFX "[%s] Failed copy from user, for 0x%X bytes\n", __func__ , count);
        kfree(inIoctl);
        return(IOCTL_STATUS_BUF_ERROR);
    }
    get_user(inIoctl->requestAddrLow, &(((pcisigIoctl*)arg)->requestAddrLow));
    get_user(inIoctl->requestAddrHigh, &(((pcisigIoctl*)arg)->requestAddrHigh));
    get_user(inIoctl->requestSize, &(((pcisigIoctl*)arg)->requestSize));
    get_user(inIoctl->requestOffset, &(((pcisigIoctl*)arg)->requestOffset));
    get_user(inIoctl->inputData, &(((pcisigIoctl*)arg)->inputData));
    get_user(inIoctl->bitMaskOverride, &(((pcisigIoctl*)arg)->bitMaskOverride));
    get_user(inIoctl->useMcfg, &(((pcisigIoctl*)arg)->useMcfg));
    get_user(inIoctl->command, &(((pcisigIoctl*)arg)->command));
    get_user(inIoctl->segment, &(((pcisigIoctl*)arg)->segment));
    get_user(inIoctl->bus, &(((pcisigIoctl*)arg)->bus));
    get_user(inIoctl->device, &(((pcisigIoctl*)arg)->device));
    get_user(inIoctl->function, &(((pcisigIoctl*)arg)->function));
    get_user(inIoctl->startBus, &(((pcisigIoctl*)arg)->startBus));
    get_user(inIoctl->endBus, &(((pcisigIoctl*)arg)->endBus));
    get_user(inIoctl->bufSize, &(((pcisigIoctl*)arg)->bufSize));

    // Now lets copy the data buffer from User Mode
    count = copy_from_user(inIoctl->pciData, (((pcisigIoctl*)arg)->pciData), sizeof(char)*PCISIG_PCI_MCFG_SIZE);
    if ( count )
    {
        pr_info( PFX "[%s] Failed copy from user, for 0x%X bytes\n", __func__ , count);
        kfree(inIoctl);
        return(IOCTL_STATUS_BUF_ERROR);
    }

    if ( inIoctl->ioctlSignature != PCISIG_UNIQUE_SIGNATURE )
    {
        pr_info( PFX "[%s] Failed signature check, received 0x%X\n", __func__ , inIoctl->ioctlSignature);
        kfree(inIoctl);
        return(IOCTL_STATUS_SIGNATURE_ERROR );
    }
    // Now reset the signature as we will pass this back up
    driverOut = inIoctl;
    driverOut->ioctlSignature = PCISIG_UNIQUE_SIGNATURE_OUT;

    pcisig_Ioctl_common(cmd, inIoctl, driverOut);

    // Now we copy the outgoing IOCTL structure to User Mode
    // count = copy_to_user( compat_ptr(inIoctl.pOutData), &driverOut, sizeof(pcisigIoctl));
    if (driverOut->outioctlStatus == IOCTL_STATUS_SUCCESS)
    {
        put_user(driverOut->ioctlSignature, &(((pcisigIoctl*)arg)->ioctlSignature));
        put_user(driverOut->outReturnData, &(((pcisigIoctl*)arg)->outReturnData));
        put_user(driverOut->outioctlStatus, &(((pcisigIoctl*)arg)->outioctlStatus));
        put_user(driverOut->outPhysAddrLow, &(((pcisigIoctl*)arg)->outPhysAddrLow));
        put_user(driverOut->outPhysAddrHigh, &(((pcisigIoctl*)arg)->outPhysAddrHigh));
        put_user(driverOut->outNumSegments, &(((pcisigIoctl*)arg)->outNumSegments));

        // Now lets copy the data buffer from User Mode
        count = copy_to_user((((pcisigIoctl*)arg)->pciData), driverOut->pciData, sizeof(char)*PCISIG_PCI_MCFG_SIZE);
        if ( count )
        {
            pr_info( PFX "[%s] Failed copy to user, for 0x%X bytes\n", __func__ , count);
            kfree(inIoctl);
            return(IOCTL_STATUS_BUF_ERROR);
        }
    }
    kfree(inIoctl);
    return 0;
}

// Main function that handles the IOCTL
// Core of the driver, it calls the correct function and returns the status
long pcisig_Ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    UINT32 count;
    pcisigIoctl  *inIoctl, *driverOut;

/*  pr_info( PFX "[%s] Got IOCTL = 0x%X\n", __func__ , cmd); */
    
    if (cmd < PCISIG_IOCTL_INIT_PCI || cmd > PCISIG_IOCTL_TEST_MEM)
    {
        return IOCTL_STATUS_NOTFOUND;
    }
    
    inIoctl = kmalloc(sizeof(pcisigIoctl), GFP_KERNEL);
    if (inIoctl == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
    // First we copy the incoming IOCTL structure from User Mode
    count = copy_from_user(inIoctl, (void *)arg, sizeof(pcisigIoctl));
    if ( count )
    {
        pr_info( PFX "[%s] Failed copy from user, for 0x%X bytes\n", __func__ , count);
        kfree(inIoctl);
        return(IOCTL_STATUS_BUF_ERROR);
    }

    if ( inIoctl->ioctlSignature != PCISIG_UNIQUE_SIGNATURE )
    {
        pr_info( PFX "[%s] Failed signature check, received 0x%X\n", __func__ , inIoctl->ioctlSignature);
        kfree(inIoctl);
        return(IOCTL_STATUS_SIGNATURE_ERROR );
    }
    // Now reset the signature as we will pass this back up
    driverOut = inIoctl;
    driverOut->ioctlSignature = PCISIG_UNIQUE_SIGNATURE_OUT;
    pcisig_Ioctl_common(cmd, inIoctl, driverOut);

    // Now we copy the outgoing IOCTL structure to User Mode
    // count = copy_to_user( compat_ptr(inIoctl.pOutData), &driverOut, sizeof(pcisigIoctl));
    if (driverOut->outioctlStatus == IOCTL_STATUS_SUCCESS)
    {
        count = copy_to_user( (void *)arg, driverOut, sizeof(pcisigIoctl));
        if ( count )
        {
            pr_info( PFX "[%s] Failed copy to user, for 0x%X bytes\n", __func__ , count);
            kfree(inIoctl);
            return(IOCTL_STATUS_BUF_ERROR);
        }
    }
    kfree(inIoctl);
    return 0;
}

// Open our driver
// Called by the Library
static int pcisigOpen( struct inode *pInode, struct file *pFile )
{
    gEntryCount++;
    pr_info( PFX "[%s] Count = 0x%X\n", __func__ , gEntryCount);
    return 0;
}

// Close the driver
// Called by the Library
// We keep track of open handles, but only 1 library should run
// So we don't anticpate this going above 1
static int pcisigClose( struct inode *pInode, struct file *pFile )
{
    gEntryCount--;
    if ( gEntryCount == 0 )
    {
        if (gsMcfg != NULL)
        {
            pcisig_freeList();
            gsMcfg = NULL;
        }
        kfree(gtestMem);
        gtestMem = NULL;
   }
    pr_info( PFX "[%s] Count = 0x%X\n", __func__ , gEntryCount);
    return 0 ;
}

// File operations structure requried by Modules
const struct file_operations pcisig_fops = {
		owner: THIS_MODULE,
        compat_ioctl: pcisig_Ioctl_compat,
		unlocked_ioctl: pcisig_Ioctl,
        open :pcisigOpen,
        release :pcisigClose,
};

// Initialize the kernel module
// Main function is to create our device node
static int pcisig_init_module(void)
{
    char name[24];
    int err = 0;
    gData = kzalloc(sizeof(*gData), GFP_KERNEL);
    if (!gData)
        return -ENOMEM;
    snprintf(name, sizeof(name), PCISIG_DRIVER_NAME);
    gData->misc_dev.name = kstrdup(name, GFP_KERNEL);
    if (!gData->misc_dev.name)
    {
        err = -ENOMEM;
        goto err_kzalloc_free;
    }
    gData->misc_dev.minor = MISC_DYNAMIC_MINOR;
    gData->misc_dev.fops = &pcisig_fops;

    err = misc_register(&gData->misc_dev);
    if (err)
    {
        pr_err(PFX "[%s] Failed to register device\n", __func__);
        goto err_kfree_name;
    }
    printk(KERN_INFO PFX "[%s] Module v%s loaded\n", __func__, PCISIG_DRIVER_VERSION_STR);
    return err;
    
err_kfree_name:
    kfree(gData->misc_dev.name);

err_kzalloc_free:
    kfree(gData);

    return err;
}

// Called when the driver is rmmod
// Detroys all data structures and the device node
void pcisig_cleanup_module(void)
{
    printk(KERN_INFO PFX "[%s] Unregistering module v%s \n", __func__, PCISIG_DRIVER_VERSION_STR);
    misc_deregister(&gData->misc_dev);
    kfree(gData->misc_dev.name);
    kfree(gData);
}

module_init(pcisig_init_module);
module_exit(pcisig_cleanup_module);




