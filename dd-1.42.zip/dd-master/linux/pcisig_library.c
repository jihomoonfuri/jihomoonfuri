/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  pcisig_library.c
 
Environment:  Linux 32/64 bit
 
Ubuntu Kernel space. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <memory.h>
#include <malloc.h>
#include <libgen.h>
#include <errno.h>
#include <fcntl.h>
#ifdef _PCISIG_SEM_
#include <semaphore.h>
#endif
#include <asm/types.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/hdreg.h>
#include <linux/if.h>
#include <sys/time.h>
#include <stdbool.h>

#include "../common/pcisig_common.h"
#include "../common/pcisiglib_interface.h"

static int      gDriverOpenCnt = 0;    /* this is now a per-task use count */
extern UINT32   gMemPhysAddrLow;
extern UINT32   gMemPhysAddrHigh;
#ifdef _PCISIG_SEM_
extern sem_t*   gSemId;
#endif

extern pcisigIoctl inIoctl;
extern struct timeval   gstartTime, glastTime;
extern void pcisigLoggingInit(UINT8 logLevelAccept, PCHAR filename, UINT8 logTimestampFormat);
extern UINT32 gendrivePCIInit(deviceData* devHandle, struct mCfgNodeLibOverRide *overRide, BOOLEAN bInitial);
extern void pcisigLog(UINT8 logLevel, const PCHAR function, const PCHAR message, ...);
extern void pcisigLoggingFinish(void);
extern void pcisigFreeList(struct mCfgNodeLib* pcinode);
extern UINT32 pcisigGetVersionInfo(deviceData* devHandle, UINT32 *pLibVer, UINT32 *pDrvVer);
extern INT32 pcisigAllocTestMemory(deviceData* devHandle, UINT32 command, UINT32 *PhysAddressLow,  UINT32 *PhysAddressHigh);


// Master function that sends the IOCTL down to the driver
// Consolidates the return value as the actual IOCTL can be a success, but the action could have an error
INT32 pcisigSendIOCTL(deviceData* devHandle, INT32 command, pcisigIoctl* inIoctl)
{
    INT32 retStatus = IOCTL_STATUS_SUCCESS;
    
    // Check that we have a valid driver file handle
    if ( !gDriverOpenCnt )
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "Invalid open driver count!  Fatal error!\n");
        return IOCTL_STATUS_ERROR_INVALID_FILEHANDLE;
    }
    
    // Create our structure that we will pass down to the driver
    // Considered the "input" to the driver
    
    inIoctl->ioctlSignature = PCISIG_UNIQUE_SIGNATURE;
    
    // Also prepare the buffer that the driver will use to return data
    // Considered the "output" of the driver

    // Call down to the driver using the ioctl command
    retStatus = ioctl (devHandle->hDev, command, inIoctl);
    pcisigLog(PCISIGLOG_INFO, __func__, "ioctl call returned %d\n", retStatus);

    if (retStatus == 0)
    {
        // Valid Return, let's check the return signature
        if (inIoctl->ioctlSignature != PCISIG_UNIQUE_SIGNATURE_OUT)
        {
            pcisigLog(PCISIGLOG_INFO, __func__, "bad ioctl return signature\n");
            retStatus = IOCTL_STATUS_SIGNATURE_ERROR;
        }
        else
        {
            retStatus = inIoctl->outioctlStatus;
            pcisigLog(PCISIGLOG_INFO, __func__, "ioctl call returned inIoctl.outIoctlStatus %d\n", inIoctl->outioctlStatus);
        }
        
    }
    return retStatus;
}

// Open a handle to the driver and return a handle
// Note: The first concurrent process to open the driver, sets the logging
UINT32 pcisigDriverOpen(deviceData** devHandle, UINT8 logLevelAccept, PCHAR logFileName, UINT8 logTimestampFormat, struct mCfgNodeLibOverRide *overRide,
                        BOOLEAN bAllocPhys)
{
    // First check the required input fields
    if ((logTimestampFormat != PCISIG_TIMESTAMP_ABSOLUTE) && (logTimestampFormat != PCISIG_TIMESTAMP_RELATIVE))
    {
        return IOCTL_STATUS_ERROR_TIMESTAMP_FORMAT;
    }
    // Let's allocate the structure and initialize it
    *devHandle = (deviceData*) malloc(sizeof(deviceData));
    if (*devHandle == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
    (*devHandle)->myPid = getpid();
    (*devHandle)->pcinode = NULL;
    (*devHandle)->memPhysAddrLow = 0;
    (*devHandle)->memPhysAddrHigh = 0;
    (*devHandle)->hDev = 0;
#ifdef _PCISIG_SEM_
    if (gDriverOpenCnt == 0)
    {
        sem_unlink("/libpcisig_semaphore");
    }
    // In order to make the library re-entrant, we protect all access with a semaphore
    gSemId = (*devHandle)->semId= sem_open("/libpcisig_semaphore", O_CREAT, (S_IRUSR | S_IWUSR), 1);
    if(gSemId == SEM_FAILED) {
        printf("FATAL ERROR, sem_open failed!\n");
        free(*devHandle);
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
    // We initilized the semaphore at 1, if we are the first caller, it will decrement successfully
    if (sem_wait(gSemId) == EINTR)
    {
        // We got an error, lets print the error since we don't necessarily have the log setup yet
        printf("FATAL ERROR, sem_wait failed!\n");
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    if (gDriverOpenCnt == 0)
    {
        // Do our first time initializations
        // Zero out the IOCTL Structure
        memset (&inIoctl, 0, sizeof(pcisigIoctl));
        gettimeofday(&gstartTime, NULL);
        gettimeofday(&glastTime, NULL);
        // Lets open our log file
        pcisigLoggingInit(logLevelAccept, logFileName, logTimestampFormat);
        pcisigLog(PCISIGLOG_INFO, __func__, "Created the log file\n");
        if (((*devHandle)->hDev = open ("/dev/pcisig", O_RDWR)) == -1) {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure, fatal!\n");
            pcisigLoggingFinish();
#ifdef _PCISIG_SEM_
            sem_post(gSemId);
            sem_destroy(gSemId);
#endif
            free(*devHandle);
            return IOCTL_STATUS_DRIVER_NOTFOUND;
        }
        pcisigLog(PCISIGLOG_INFO, __func__, "We have a valid driver file handle\n");
    }
    gDriverOpenCnt++;
    if (gDriverOpenCnt == 1)
    {
        // Initialize the PCI registers
        if (gendrivePCIInit(*devHandle, overRide, TRUE) != IOCTL_STATUS_SUCCESS)
        {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure in gendrivePCIInit, fatal!\n");
            pcisigLoggingFinish();
#ifdef _PCISIG_SEM_
            sem_post(gSemId);
            sem_destroy(gSemId);
#endif
            pcisigFreeList((*devHandle)->pcinode);
            free(*devHandle);
            return IOCTL_STATUS_NOTFOUND;
        }
        // Allocate our Physical Buffer for Testing
        if (pcisigAllocTestMemory(*devHandle, PCISIG_CMD_ALLOCBUF,  &gMemPhysAddrLow, &gMemPhysAddrHigh) != IOCTL_STATUS_SUCCESS)
        {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure in pcisigAllocTestMemory, fatal!\n");
            pcisigLoggingFinish();
#ifdef _PCISIG_SEM_
            sem_post(gSemId);
            sem_destroy(gSemId);
#endif
            pcisigFreeList((*devHandle)->pcinode);
            free(*devHandle);
            return IOCTL_STATUS_NOTFOUND;
        }
    }
    if (bAllocPhys == true)
    {
        (*devHandle)->memPhysAddrLow = gMemPhysAddrLow;
        (*devHandle)->memPhysAddrHigh = gMemPhysAddrHigh;
    }
    pcisigGetVersionInfo(*devHandle, &((*devHandle)->libVer), &((*devHandle)->drvVer));   // Get the Driver and Library versions
    if ((*devHandle)->libVer != (*devHandle)->drvVer)
    {
        pcisigLog(PCISIGLOG_INFO, __func__, "Library Version = 0x%X; Driver Version = 0x%X\n", (*devHandle)->libVer, (*devHandle)->drvVer);
        pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG, __func__, "WARNING:  Driver and Library version mismatch - may cause unintended behavior.\n");
//        pcisigLoggingFinish();
//#ifdef _PCISIG_SEM_
//        sem_post(gSemId);
//        sem_destroy(gSemId);
//#endif
//        pcisigFreeList((*devHandle)->pcinode);
//        free(*devHandle);
//        return IOCTL_STATUS_LIB_DRV_MISMATCH_WARNING;
    }
    pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG , __func__, "Opened the pcisig Library, instance#0x%x\n",
              gDriverOpenCnt);
#ifdef _PCISIG_SEM_
    // Give up the sempaphore
    sem_post(gSemId);
#endif
    return IOCTL_STATUS_SUCCESS;
}

// Close the driver and pass in our open Handle
// If the count goes to 0, it will close up the logs, files, etc.
UINT32 pcisigCloseDriver(deviceData* devHandle)
{
#ifdef _PCISIG_SEM_
    // Grab our sempahore
    if (sem_wait(gSemId) == EINTR)
    {
        return IOCTL_STATUS_SEMAPHORE_ERROR;
    }
#endif
    gDriverOpenCnt--;
    if ( gDriverOpenCnt == 0 )
    {
        pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG, __func__, "Closing the pcisig Library\n");
        pcisigLoggingFinish();
        pcisigAllocTestMemory(devHandle, PCISIG_CMD_FREEBUF,  &gMemPhysAddrLow, &gMemPhysAddrHigh);
        close(devHandle->hDev);
#ifdef _PCISIG_SEM_
        sem_post(gSemId);
        sem_destroy(gSemId);
#endif
        pcisigFreeList(devHandle->pcinode);
        free(devHandle);
        return IOCTL_STATUS_SUCCESS;
    }
#ifdef _PCISIG_SEM_
    sem_post(gSemId);
#endif
    pcisigFreeList(devHandle->pcinode);
    free(devHandle);
    return IOCTL_STATUS_SUCCESS;
}






