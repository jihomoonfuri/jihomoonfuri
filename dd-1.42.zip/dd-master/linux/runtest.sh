#!/bin/sh

usage() {

    echo "Usage: runtest.sh <module> [args...]"
    echo "Examples:"
    echo "    ./runtest.sh pcisig_module"
    echo "Required:"
    echo "    module:    PCI-SIG kernel module (example: 'pcisig_module')"

}

main() {

    if [ ${#} -lt 1 ]; then
        usage
        exit 1
    fi

    MODULE="${1}"
    MODULE_BASE=$(basename "${MODULE}" ".ko")
    MODULE_FULL="${MODULE_BASE}.ko"
    shift

    # conditionally remove and insert module

    if grep -q "^${MODULE_BASE} " /proc/modules; then
        echo "INFO: removing ${MODULE_BASE}"
        rmmod "${MODULE_BASE}"
    fi

    echo "INFO: inserting ${MODULE_FULL}"
    insmod "${MODULE_FULL}"

    # set library search path

    LIBRARY_PATH="${LD_LIBRARY_PATH:+$LD_LIBRARY_PATH:}$(pwd)"
    echo "INFO: LD_LIBRARY_PATH is ${LIBRARY_PATH}"

    # run test program

    env LD_LIBRARY_PATH="${LIBRARY_PATH}" ./pcisig_module_test "$@"

    # remove module

    if grep -q "^${MODULE_BASE} " /proc/modules; then
        echo "INFO: removing ${MODULE_BASE}"
        rmmod "${MODULE_BASE}"
    fi

    exit 0

}

main "$@"