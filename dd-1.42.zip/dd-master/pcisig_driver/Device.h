/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  device.h
 
Environment:  Windows 10 32/64 bit
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/

#include "pcisig_common.h"
EXTERN_C_START

struct mCfgNode {
    PVOID  pMcfg;
    UINT16 segmentNum;
    UINT8  startBus;
    UINT8  endBus;
    UINT32 mcfgBaseLow;
    UINT32 mcfgBaseHigh;
    struct mCfgNode* next;
};
//
// The device context performs the same job as
// a WDM device extension in the driver frameworks
//
typedef struct _DEVICE_CONTEXT
{
    ULONG PrivateDeviceData;  // just a placeholder
    UINT32              gEntryCount;
    struct mCfgNode*    gsMcfg;
    PVOID               gtestMem;
} DEVICE_CONTEXT, *PDEVICE_CONTEXT;

//
// This macro will generate an inline function called DeviceGetContext
// which will be used to get a pointer to the device context memory
// in a type safe manner.
//
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_CONTEXT, DeviceGetContext)

//
// Function to initialize the device and its callbacks
//
NTSTATUS
pcisigdriverCreateDevice(
    _Inout_ PWDFDEVICE_INIT DeviceInit
    );
VOID
pcisigdriverDeviceFileCreate(
    IN WDFDEVICE            Device,
    IN WDFREQUEST Request,
    IN WDFFILEOBJECT        FileObject
);
VOID
pcisigdriverFileClose(
    IN WDFFILEOBJECT    FileObject
);

EXTERN_C_END
