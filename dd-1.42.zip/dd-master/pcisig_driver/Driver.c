/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  driver.c
 
Environment:  Windows 10 32/64 bit
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/

#define _NO_CRT_STDIO_INLINE

#include "driver.h"
#include <ntstrsafe.h>

#ifdef ALLOC_PRAGMA
#pragma alloc_text (INIT, DriverEntry)
#pragma alloc_text (PAGE, pcisigdriverEvtDeviceAdd)
#pragma alloc_text (PAGE, pcisigdriverEvtDriverContextCleanup)
#endif


#define PFX "PCI-SIG: "
VOID pr_info(__in PCCHAR  DebugMessage, ...)
{
    UNREFERENCED_PARAMETER(DebugMessage);
#ifndef PCISIG_REL
#define     TEMP_BUFFER_SIZE        1024
    va_list    list;
    UCHAR      debugMessageBuffer[TEMP_BUFFER_SIZE];
     NTSTATUS status;

    va_start(list, DebugMessage);

    if (DebugMessage) {

        //
        // Using new safe string functions instead of _vsnprintf. This function takes
        // care of NULL terminating if the message is longer than the buffer.
        //
        status = RtlStringCbVPrintfA((NTSTRSAFE_PSTR)debugMessageBuffer, sizeof(debugMessageBuffer),
                                    DebugMessage, list);
        if(!NT_SUCCESS(status)) {

            KdPrint ((PFX "RtlStringCbVPrintfA failed %x\n", status));
            return;
        }
        KdPrint(("%s", debugMessageBuffer));
    }
    va_end(list);
    return;
#endif
}

//
//     DriverEntry initializes the driver and is the first routine called by the
//     system after the driver is loaded. DriverEntry specifies the other entry
//     points in the function driver, such as EvtDevice and DriverUnload.
//
//     DriverObject - represents the instance of the function driver that is loaded
//                    into memory.
//     RegistryPath - represents the driver specific path in the Registry.
//
NTSTATUS DriverEntry(_In_ PDRIVER_OBJECT  DriverObject, _In_ PUNICODE_STRING RegistryPath)
{
    WDF_DRIVER_CONFIG config;
    NTSTATUS status;
    WDF_OBJECT_ATTRIBUTES attributes;

    pr_info(PFX "%s Entering function\n",__func__ );
 
    //
    // Register a cleanup callback so that we can call WPP_CLEANUP when
    // the framework driver object is deleted during driver unload.
    //
    WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
    attributes.EvtCleanupCallback = pcisigdriverEvtDriverContextCleanup;

    WDF_DRIVER_CONFIG_INIT(&config,
                           pcisigdriverEvtDeviceAdd
                           );

    status = WdfDriverCreate(DriverObject,
                             RegistryPath,
                             &attributes,
                             &config,
                             WDF_NO_HANDLE
                             );

    if (!NT_SUCCESS(status)) {
        return status;
    }
    return status;
}

//
//  EvtDeviceAdd is called by the framework in response to AddDevice
//  call from the PnP manager. We create and initialize a device object to
//  represent a new instance of the device.
//
//  Driver - Handle to a framework driver object created in DriverEntry
//  DeviceInit - Pointer to a framework-allocated WDFDEVICE_INIT structure.
//
NTSTATUS pcisigdriverEvtDeviceAdd(_In_ WDFDRIVER Driver, _Inout_ PWDFDEVICE_INIT DeviceInit)
{
    NTSTATUS status;

    UNREFERENCED_PARAMETER(Driver);

    PAGED_CODE();

    pr_info(PFX "%s Entering function\n",__func__ );
    status = pcisigdriverCreateDevice(DeviceInit);
    return status;
}

//
//  Free all the resources allocated in DriverEntry.
//
//   DriverObject - handle to a WDF Driver object.
//
VOID pcisigdriverEvtDriverContextCleanup(_In_ WDFOBJECT DriverObject)
{
    UNREFERENCED_PARAMETER(DriverObject);

    PAGED_CODE();
}

