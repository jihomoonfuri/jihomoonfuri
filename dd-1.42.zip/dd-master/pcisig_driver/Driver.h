/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  driver.h

Environment:  Windows 10 32/64 bit
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/
#include <ntifs.h>
#include <ntstrsafe.h>

#include <wdm.h>
#include <wdf.h>

#include <initguid.h>
#include <devpkey.h>

#include <stdlib.h>

#include "device.h"
#include "queue.h"

EXTERN_C_START

//
// WDFDRIVER Events
//

DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD pcisigdriverEvtDeviceAdd;
EVT_WDF_OBJECT_CONTEXT_CLEANUP pcisigdriverEvtDriverContextCleanup;

EXTERN_C_END
