/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  queue.c

Environment:  Windows 10 32/64 bit
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/

#define _NO_CRT_STDIO_INLINE

#include "driver.h"
#include <aux_klib.h>

#ifdef ALLOC_PRAGMA
#pragma alloc_text (PAGE, pcisigdriverQueueInitialize)
#endif

#define DRV_VERSION_STR     "1.42" // ARM64 (Windows/Linux)
#define DRV_VERSION_NUM     0x0142
#define PFX "PCI-SIG: "

extern VOID pr_info(__in PCCHAR  DebugMessage, ...);
extern UINT32 pcisig_InitPCI(struct mCfgNode **gsMcfg, pcisigIoctl* inIoctl, pcisigIoctl* driverOut);
extern UINT32 pcisig_ClosePCI(struct mCfgNode **gsMcfg);
extern UINT32 pcisig_getMcfgACPI(struct mCfgNode **gsMcfg, pcisigIoctl* inIoctl, pcisigIoctl* outParam,
                                 UINT32 updateList);
#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space
extern UINT32 pcisig_ReadIO(UINT32 IOSize, UINT32 inputAddr);
extern void pcisig_WriteIO(UINT32 IOSize, UINT32 inputAddr, UINT32 inputData);
#endif

extern UINT32 pcisigReadPCIConfig(BOOLEAN readIO, struct mCfgNode **gsMcfg, pcisigIoctl* inoutParam, struct mCfgNode* inNode);
extern UINT32 pcisigWritePCIConfig(BOOLEAN writeIO, struct mCfgNode** gsMcfg, pcisigIoctl* inoutParam, struct mCfgNode* inNode);
extern UINT32 pcisig_TestFunctionMemory(PVOID *gtestMem, pcisigIoctl* inParam, pcisigIoctl* outParam);
extern UINT32 pcisig_RWMemory(pcisigIoctl* inoutParam);
//
//  The I/O dispatch callbacks for the frameworks device object are
//  configured in this function.
//
//  A single default I/O Queue is configured for parallel request
//  processing, and a driver context memory allocation is created
//  to hold our structure QUEUE_CONTEXT.
//
//  Device - Handle to a framework device object.
//
NTSTATUS pcisigdriverQueueInitialize(_In_ WDFDEVICE Device)
{
    WDFQUEUE queue;
    NTSTATUS status;
    WDF_IO_QUEUE_CONFIG queueConfig;

    PAGED_CODE();

    //
    // Configure a default queue so that requests that are not
    // configure-fowarded using WdfDeviceConfigureRequestDispatching to goto
    // other queues get dispatched here.
    //
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(
         &queueConfig,
          WdfIoQueueDispatchSequential
        );

    queueConfig.EvtIoDeviceControl = pcisigdriverEvtIoDeviceControl;
    queueConfig.EvtIoStop = pcisigdriverEvtIoStop;

    status = WdfIoQueueCreate(
                 Device,
                 &queueConfig,
                 WDF_NO_OBJECT_ATTRIBUTES,
                 &queue
                 );

    if(!NT_SUCCESS(status)) {
        return status;
    }

    return status;
}



//
//  This event is invoked when the framework receives IRP_MJ_DEVICE_CONTROL request.
//
//  Queue -  Handle to the framework queue object that is associated with the I/O request.
//  Request - Handle to a framework request object.
//  OutputBufferLength - Size of the output buffer in bytes
//  InputBufferLength - Size of the input buffer in bytes
//  IoControlCode - I/O control code.
//
VOID pcisigdriverEvtIoDeviceControl(_In_ WDFQUEUE Queue, _In_ WDFREQUEST Request, _In_ size_t OutputBufferLength,
                                    _In_ size_t InputBufferLength, _In_ ULONG IoControlCode)
{
    NTSTATUS                status = STATUS_SUCCESS;
    PDEVICE_CONTEXT         devExt = NULL;

    WDFDEVICE               hDevice;
    WDF_REQUEST_PARAMETERS  params;
    size_t                  inBufLength;    // Input buffer length
    size_t                  outBufLength;   // Output buffer length
    pcisigIoctl*            inIoctl;

    
    UNREFERENCED_PARAMETER(OutputBufferLength);
    UNREFERENCED_PARAMETER(InputBufferLength);

    hDevice = WdfIoQueueGetDevice(Queue);
    
    devExt = DeviceGetContext(hDevice);

    WDF_REQUEST_PARAMETERS_INIT(&params);

    WdfRequestGetParameters(
        Request,
        &params
    );

    inBufLength = params.Parameters.DeviceIoControl.InputBufferLength;
    outBufLength = params.Parameters.DeviceIoControl.OutputBufferLength;
    //pr_info( PFX "In pcisigdriverEvtIoDeviceControl\n");
    if (!inBufLength || !outBufLength)
    {
        status = STATUS_INVALID_PARAMETER;
        WdfRequestComplete(Request, status);
        return;
    }
    status = WdfRequestRetrieveInputBuffer(
        Request,
        inBufLength,
        &inIoctl,
        (size_t*)&inBufLength
    );

    if (status != STATUS_SUCCESS)
    {
        WdfRequestComplete(Request, status);
        return;
    }
    if ( inIoctl->ioctlSignature != PCISIG_UNIQUE_SIGNATURE )
    {
        pr_info( PFX "[%s] Failed signature check, received 0x%X\n", __func__ , inIoctl->ioctlSignature);
        WdfRequestComplete(Request, STATUS_INVALID_PARAMETER);
        return;
    }
    // Now reset the signature as we will pass this back up
    inIoctl->ioctlSignature = PCISIG_UNIQUE_SIGNATURE_OUT;

    switch (IoControlCode)
    {
        case PCISIG_IOCTL_INIT_PCI:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            // Called to initialize some basic PCI variables
            //pr_info( PFX "About to call pcisig_InitPCI \n");
            inIoctl->outioctlStatus = pcisig_InitPCI(&(devExt->gsMcfg), inIoctl, inIoctl);
            break;
        case PCISIG_IOCTL_CLOSE_PCI:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            // Called to initialize some basic PCI variables
            //pr_info( PFX "About to call pcisig_InitPCI \n");
            inIoctl->outioctlStatus = pcisig_ClosePCI(&(devExt->gsMcfg));
            break;
        case PCISIG_IOCTL_GET_DRV_VERSION:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            inIoctl->outReturnData = DRV_VERSION_NUM;
            inIoctl->outioctlStatus = IOCTL_STATUS_SUCCESS;
            pr_info( PFX "inIoctl->outReturnData = %x\n", inIoctl->outReturnData);
            break;
        case PCISIG_IOCTL_GET_MCFG:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            inIoctl->outioctlStatus = pcisig_getMcfgACPI(&(devExt->gsMcfg), inIoctl, inIoctl, FALSE);
            break;
        case PCISIG_IOCTL_GETSET_PCI_CONFIG_MCFG:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            if (inIoctl->command == PCISIG_CMD_READ)
            {
                inIoctl->outioctlStatus = pcisigReadPCIConfig(FALSE, &(devExt->gsMcfg), inIoctl, NULL);
            }
            else
            {
                inIoctl->outioctlStatus = pcisigWritePCIConfig(FALSE, &(devExt->gsMcfg), inIoctl, NULL);
            }
            break;
#if !defined(_M_ARM64) // Arm64 does not support IOPort access to config space
        case PCISIG_IOCTL_GETSET_PCI_CONFIG_IO:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            if (inIoctl->command == PCISIG_CMD_READ)
            {
                inIoctl->outioctlStatus = pcisigReadPCIConfig(TRUE, NULL, inIoctl, NULL);
            }
            else
            {
                inIoctl->outioctlStatus = pcisigWritePCIConfig(TRUE, NULL, inIoctl, NULL);
            }
            break;
        case PCISIG_IOCTL_READ_IO:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            inIoctl->outReturnData = pcisig_ReadIO(inIoctl->requestSize, inIoctl->requestAddrLow);
            //pr_info( PFX "inIoctl->outReturnData = %x\n", inIoctl->outReturnData);
            inIoctl->outioctlStatus = IOCTL_STATUS_SUCCESS;
            break;
        case PCISIG_IOCTL_WRITE_IO:
            ASSERT((IoControlCode & 0x3) == METHOD_BUFFERED);
            //pr_info( PFX "inIoctl->requestAddrLow = %x, inIoctl->inputData = %x\n", inIoctl->requestAddrLow, inIoctl->inputData);
            pcisig_WriteIO(inIoctl->requestSize, inIoctl->requestAddrLow, inIoctl->inputData);
            inIoctl->outioctlStatus = IOCTL_STATUS_SUCCESS;
            break;
#endif
        case PCISIG_IOCTL_RW_MEM_ADDR:
            inIoctl->outioctlStatus = pcisig_RWMemory(inIoctl);
            break;
        case PCISIG_IOCTL_TEST_MEM:
            inIoctl->outioctlStatus = pcisig_TestFunctionMemory(&(devExt->gtestMem), inIoctl, inIoctl);
            break;
        default:
            //ASSERTMSG(FALSE, "Invalid IOCTL request\n");
            WdfRequestComplete(Request, STATUS_INVALID_DEVICE_REQUEST);
            return;
    }
    params.Parameters.DeviceIoControl.OutputBufferLength = sizeof(pcisigIoctl);
    WdfRequestCompleteWithInformation(Request, status, sizeof(pcisigIoctl));
    return;
}

//
//  This event is invoked for a power-managed queue before the device leaves the working state (D0).
//
//  Queue -  Handle to the framework queue object that is associated with the I/O request.
//  Request - Handle to a framework request object.
//  ActionFlags - A bitwise OR of one or more WDF_REQUEST_STOP_ACTION_FLAGS-typed flags
//                that identify the reason that the callback function is being called
//                and whether the request is cancelable.
//
VOID pcisigdriverEvtIoStop(_In_ WDFQUEUE Queue, _In_ WDFREQUEST Request, _In_ ULONG ActionFlags)
{
    UNREFERENCED_PARAMETER(Queue);
    UNREFERENCED_PARAMETER(Request);
    UNREFERENCED_PARAMETER(ActionFlags);

    //
    // In most cases, the EvtIoStop callback function completes, cancels, or postpones
    // further processing of the I/O request.
    //
    // Typically, the driver uses the following rules:
    //
    // - If the driver owns the I/O request, it calls WdfRequestUnmarkCancelable
    //   (if the request is cancelable) and either calls WdfRequestStopAcknowledge
    //   with a Requeue value of TRUE, or it calls WdfRequestComplete with a
    //   completion status value of STATUS_SUCCESS or STATUS_CANCELLED.
    //
    //   Before it can call these methods safely, the driver must make sure that
    //   its implementation of EvtIoStop has exclusive access to the request.
    //
    //   In order to do that, the driver must synchronize access to the request
    //   to prevent other threads from manipulating the request concurrently.
    //   The synchronization method you choose will depend on your driver's design.
    //
    //   For example, if the request is held in a shared context, the EvtIoStop callback
    //   might acquire an internal driver lock, take the request from the shared context,
    //   and then release the lock. At this point, the EvtIoStop callback owns the request
    //   and can safely complete or requeue the request.
    //
    // - If the driver has forwarded the I/O request to an I/O target, it either calls
    //   WdfRequestCancelSentRequest to attempt to cancel the request, or it postpones
    //   further processing of the request and calls WdfRequestStopAcknowledge with
    //   a Requeue value of FALSE.
    //
    // A driver might choose to take no action in EvtIoStop for requests that are
    // guaranteed to complete in a small amount of time.
    //
    // In this case, the framework waits until the specified request is complete
    // before moving the device (or system) to a lower power state or removing the device.
    // Potentially, this inaction can prevent a system from entering its hibernation state
    // or another low system power state. In extreme cases, it can cause the system
    // to crash with bugcheck code 9F.
    //

    return;
}
