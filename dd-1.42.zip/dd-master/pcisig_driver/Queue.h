/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  queue.h

Environment:  Windows 10 32/64 bit
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group
 
*/

EXTERN_C_START

//
// This is the context that can be placed per queue
// and would contain per queue information.
//
typedef struct _QUEUE_CONTEXT {
    ULONG PrivateDeviceData;  // just a placeholder
} QUEUE_CONTEXT, *PQUEUE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(QUEUE_CONTEXT, QueueGetContext)

NTSTATUS
pcisigdriverQueueInitialize(_In_ WDFDEVICE Device);

//
// Events from the IoQueue object
//
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL pcisigdriverEvtIoDeviceControl;
EVT_WDF_IO_QUEUE_IO_STOP pcisigdriverEvtIoStop;

EXTERN_C_END
