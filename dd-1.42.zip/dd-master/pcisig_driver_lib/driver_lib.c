/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  libraryfiles.c
 
Environment:  Windows 32/64 bit
 
Windows 10 library. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <malloc.h>
#include <time.h>

#if MSVC_TOOLSET_VERSION < 142
#define __func__ __FUNCTION__
#endif

#include "pcisig_common.h"
#include "pcisiglib_interface.h"

typedef struct
{
    UINT32  driverOpenCnt;
    UINT32  memPhysAddrLow;
    UINT32  memPhysAddrHigh;
} winGlobal;

extern winGlobal* gWinVars;
extern HANDLE ghSemaphore;

//
// Define all the externals that are available from pcisig_lib_common.c
//
extern pcisigIoctl inIoctl;
extern struct timeval   gstartTime, glastTime;
extern void pcisigWinCloseDriver(HANDLE hDev);
extern UINT32 pcisigWinOpenDriver(HANDLE *hDev);
extern int gettimeofday(struct timeval * tp, struct timezone * tzp);
extern void pcisigLoggingInit(UINT8 logLevelAccept, PCHAR filename, UINT8 logTimestampFormat);
extern UINT32 gendrivePCIInit(deviceData* devHandle, struct mCfgNodeLibOverRide *overRide, BOOLEAN bInitial);
extern void pcisigLog(UINT8 logLevel, const PCHAR function, const PCHAR message, ...);
extern void pcisigLoggingFinish(void);
extern void pcisigFreeList(struct mCfgNodeLib* pcinode);
extern UINT32 pcisigGetVersionInfo(deviceData* devHandle, UINT32 *pLibVer, UINT32 *pDrvVer);
extern INT32 pcisigAllocTestMemory(deviceData* devHandle, UINT32 command, UINT32 *PhysAddressLow,  UINT32 *PhysAddressHigh);
#define DECLDIR __declspec(dllexport)


//
// Master function that sends the IOCTL down to the driver
// Consolidates the return value as the actual IOCTL can be a success, but the action could have an error
//
INT32 pcisigSendIOCTL (deviceData* devHandle, INT32 command, pcisigIoctl *ioctl)
{
    INT32                   retStatus = IOCTL_STATUS_SUCCESS;
    BOOL                    bRc;
    DWORD                   bytesReturned;

    // Check that we have a valid driver file handle
    if ( !(devHandle->hDev) )
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "Invalid open driver count!  Fatal error!\n");
        return IOCTL_STATUS_ERROR_INVALID_FILEHANDLE;
    }
        
    // Create our structure that we will pass down to the driver
    // Considered the "input" to the driver
    
    ioctl->ioctlSignature = PCISIG_UNIQUE_SIGNATURE;
    // Send an IOCTL to the device to get the resource list

    // Also prepare the buffer that the driver will use to return data
    // Considered the "output" of the driver

    // Call down to the driver using the ioctl command
    bRc = DeviceIoControl(devHandle->hDev, (DWORD)command,
        (LPVOID)ioctl, (DWORD)sizeof(pcisigIoctl),
        (LPVOID)ioctl, (DWORD)sizeof(pcisigIoctl),
        &bytesReturned, NULL);

    if (bRc == FALSE)
    {
        printf("Error in DeviceIoControl : %d", GetLastError());
        retStatus = IOCTL_STATUS_DRIVER_NOTFOUND;
        goto pcisigSendIOCTL_end;
    }
    // Valid Return, let's check the return signature
    if (ioctl->ioctlSignature != PCISIG_UNIQUE_SIGNATURE_OUT)
    {
        pcisigLog(PCISIGLOG_INFO, __func__, "bad ioctl return signature\n");
        retStatus = IOCTL_STATUS_SIGNATURE_ERROR;
    }
    else
    {
        retStatus = ioctl->outioctlStatus;
        pcisigLog(PCISIGLOG_INFO, __func__, "ioctl call returned inIoctl.outIoctlStatus %d\n", ioctl->outioctlStatus);
    }
    
pcisigSendIOCTL_end:
    return retStatus;
}

//
// Open a handle to the driver and return a handle
// Note: The first concurrent process to open the driver, sets the logging
//
DECLDIR UINT32 pcisigDriverOpen(deviceData** devHandle, UINT8 logLevelAccept, PCHAR logFileName,
                                UINT8 logTimestampFormat, struct mCfgNodeLibOverRide *overRide,
                                BOOLEAN bAllocPhys)
{
    DWORD   dwWaitResult;
    UINT32  retStatus = IOCTL_STATUS_SUCCESS;

    // First check the required input fields
    if ((logTimestampFormat != PCISIG_TIMESTAMP_ABSOLUTE) && (logTimestampFormat != PCISIG_TIMESTAMP_RELATIVE))
    {
        return IOCTL_STATUS_ERROR_TIMESTAMP_FORMAT;
    }
    if (overRide == NULL)
    {
        return IOCTL_PARAMETER_ERROR_OVERRIDE;
    }
    // Let's allocate the structure and initialize it
    *devHandle = (deviceData*) malloc(sizeof(deviceData));
    if (*devHandle == NULL)
    {
        return IOCTL_STATUS_BUF_ERROR;
    }
    // Try to enter the semaphore gate.
    dwWaitResult = WaitForSingleObject(ghSemaphore, WAIT_SEMAPHORE_1_SECOND);
    if (dwWaitResult != WAIT_OBJECT_0)
    {
        return IOCTL_STATUS_SEMAPHORE_TIMEOUT;
    }
    (*devHandle)->pcinode = NULL;
    (*devHandle)->memPhysAddrLow = 0;
    (*devHandle)->memPhysAddrHigh = 0;
    (*devHandle)->hDev = NULL;
    (gWinVars->driverOpenCnt)++;
    // Do our first time initializations
    // Zero out the IOCTL Structure
    memset (&inIoctl, 0, sizeof(pcisigIoctl));
    gettimeofday(&gstartTime, NULL);
    glastTime = gstartTime;
    // Lets open our log file
    pcisigLoggingInit(logLevelAccept, logFileName, logTimestampFormat);
    pcisigLog(PCISIGLOG_INFO, __func__, "Created the log file\n");
    retStatus = pcisigWinOpenDriver(&(*devHandle)->hDev);
    if (retStatus != IOCTL_STATUS_SUCCESS)
    {
        pcisigLog(PCISIGLOG_ERROR, __func__, "pcisigWinOpenDriver failure, fatal!\n");
        pcisigLoggingFinish();
        free(*devHandle);
        (gWinVars->driverOpenCnt)--;
        goto pcisigDriverOpen_end;
    }
    pcisigLog(PCISIGLOG_INFO, __func__, "We have a valid driver file handle\n");
    pcisigGetVersionInfo(*devHandle, &((*devHandle)->libVer), &((*devHandle)->drvVer));   // Get the Driver and Library versions
    if ((*devHandle)->libVer != (*devHandle)->drvVer)
    {
        pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG | PCISIGLOG_ERROR, __func__, "WARNING:  Driver (0x%X) and Library (0x%X) version mismatch - may cause incompatibilities.\n", (*devHandle)->drvVer, (*devHandle)->libVer);
//        pcisigWinCloseDriver((*devHandle)->hDev);
//        pcisigLoggingFinish();
//        pcisigFreeList((*devHandle)->pcinode);
//        free(*devHandle);
        retStatus = IOCTL_STATUS_LIB_DRV_MISMATCH_WARNING;
//        goto pcisigDriverOpen_end;
    }
    if (gWinVars->driverOpenCnt == FIRST_TIME_DRIVER_OPENED)
    {
        gWinVars->memPhysAddrLow = 0;
        gWinVars->memPhysAddrHigh = 0;
        // Initialize the PCI registers
        retStatus = gendrivePCIInit(*devHandle, overRide, TRUE);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure in gendrivePCIInit, fatal!\n");
            pcisigWinCloseDriver((*devHandle)->hDev);
            pcisigLoggingFinish();
            pcisigFreeList((*devHandle)->pcinode);
            free(*devHandle);
            goto pcisigDriverOpen_end;
        }
        // Allocate our Physical Buffer for Testing
        retStatus = pcisigAllocTestMemory(*devHandle, PCISIG_CMD_ALLOCBUF,  &(gWinVars->memPhysAddrLow), &(gWinVars->memPhysAddrHigh));
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure in pcisigAllocTestMemory, fatal!\n");
            pcisigWinCloseDriver((*devHandle)->hDev);
            pcisigLoggingFinish();
            pcisigFreeList((*devHandle)->pcinode);
            free(*devHandle);
            goto pcisigDriverOpen_end;
        }
    }
    else
    {
        // Initialize the PCI registers
        retStatus = gendrivePCIInit(*devHandle, overRide, FALSE);
        if (retStatus != IOCTL_STATUS_SUCCESS)
        {
            pcisigLog(PCISIGLOG_ERROR, __func__, "driver open failure in gendrivePCIInit, fatal!\n");
            pcisigWinCloseDriver((*devHandle)->hDev);
            pcisigLoggingFinish();
            pcisigFreeList((*devHandle)->pcinode);
            free(*devHandle);
            goto pcisigDriverOpen_end;
        }
    }
    if (bAllocPhys == TRUE)
    {
        (*devHandle)->memPhysAddrLow = gWinVars->memPhysAddrLow;
        (*devHandle)->memPhysAddrHigh = gWinVars->memPhysAddrHigh;
    }

pcisigDriverOpen_end:

    ReleaseSemaphore(ghSemaphore, 1, NULL);
    pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG , __func__, "Opened the pcisig Library, instance#0x%x\n",
              gWinVars->driverOpenCnt);
    return retStatus;
}


// Close the driver and pass in our open Handle
// If the count goes to 0, it will close up the logs, files, etc.
DECLDIR UINT32 pcisigCloseDriver(deviceData* devHandle)
{
    UINT32  dwWaitResult;

    dwWaitResult = WaitForSingleObject(ghSemaphore, WAIT_SEMAPHORE_1_SECOND);
    if (dwWaitResult != WAIT_OBJECT_0)
    {
        return IOCTL_STATUS_SEMAPHORE_TIMEOUT;
    }
    (gWinVars->driverOpenCnt)--;
    if ( gWinVars->driverOpenCnt == 0 )
    {
        pcisigAllocTestMemory(devHandle, PCISIG_CMD_FREEBUF, &(gWinVars->memPhysAddrLow), &(gWinVars->memPhysAddrHigh));
        pcisigSendIOCTL (devHandle, PCISIG_IOCTL_CLOSE_PCI, &inIoctl);

    }
    pcisigLog(PCISIGLOG_INFO | PCISIGLOG_DEBUG, __func__, "Closing the pcisig Library\n");
    pcisigLoggingFinish();
    pcisigWinCloseDriver(devHandle->hDev);
    pcisigFreeList(devHandle->pcinode);
    free(devHandle);
    ReleaseSemaphore(ghSemaphore, 1, NULL);
    return IOCTL_STATUS_SUCCESS;
}



