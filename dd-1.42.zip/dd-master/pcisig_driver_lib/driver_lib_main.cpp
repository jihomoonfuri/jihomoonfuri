/*
 
Copyright (c) 2021 PCI-SIG ALL RIGHTS RESERVED.
 
 
PCI-SIG PROPRIETARY INFORMATION
 
This software is supplied under the terms of a license agreement with PCI-SIG and may not be copied
 or disclosed except in accordance with the terms of that agreement.
 
Name:  main.cpp
 
Environment:  Windows 32/64 bit
 
Windows 10 library entry points. Dependent on the underlying infrastructure.
 
OS-dependent.
 
Author:
  
Nagib Gulam, CCI
 
Joe Leong, VTM Group

*/

#include <windows.h>
#include <iostream>
#include <basetyps.h>
#include <stdlib.h>
#include <wtypes.h>
#include <setupapi.h>
#include <initguid.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <winioctl.h>
#include <tchar.h>
#if MSVC_TOOLSET_VERSION < 142
#define __func__ __FUNCTION__
#else
#include <devioctl.h>
#include <infstr.h>
#include <chrono>
#endif
#include <cfgmgr32.h>
#include <strsafe.h>
#include <string.h>
#include <newdev.h>
#include <regstr.h>
#include <list>


// DECLDIR will perform an export for us
#define DLL_EXPORT

#undef _PCISIG_STDINT_
#include "pcisig_common.h"
#include "pcisiglib_interface.h"

#define SHMEMSIZE 4096
 
static HANDLE hMapObject = NULL;  // handle to file mapping
extern "C"
{

typedef struct
{
    UINT32  driverOpenCnt;
    UINT32  memPhysAddrLow;
    UINT32  memPhysAddrHigh;
} winGlobal;

winGlobal* gWinVars;
HANDLE ghSemaphore;
HANDLE gIoctlSem;

}

// The DLL entry-point function sets up shared memory using a
// named file-mapping object.
 
extern BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  // DLL module handle
    DWORD fdwReason,              // reason called
    LPVOID lpvReserved)           // reserved
{
    BOOL fInit, fIgnore;
 
    switch (fdwReason)
    {
        // DLL load due to process initialization or LoadLibrary
 
          case DLL_PROCESS_ATTACH:
            // Create a named file mapping object
 
            hMapObject = CreateFileMapping(
                INVALID_HANDLE_VALUE,   // use paging file
                NULL,                   // default security attributes
                PAGE_READWRITE,         // read/write access
                0,                      // size: high 32-bits
                SHMEMSIZE,              // size: low 32-bits
                TEXT("pcisigdll"));     // name of map object
            if (hMapObject == NULL)
                return FALSE;
 
            // The first process to attach initializes memory
 
            fInit = (GetLastError() != ERROR_ALREADY_EXISTS);
 
            // Get a pointer to the file-mapped shared memory
 
            gWinVars = (winGlobal*) MapViewOfFile(
                hMapObject,     // object to map view of
                FILE_MAP_WRITE, // read/write access
                0,              // high offset:  map from
                0,              // low offset:   beginning
                0);             // default: map entire file
            if (gWinVars == NULL)
                return FALSE;
 
    
            // Initialize memory if this is the first process
 
            if (fInit)
                memset(gWinVars, '\0', sizeof(winGlobal));
            
            // Create a semaphore with initial and max counts of MAX_SEM_COUNT

            ghSemaphore = CreateSemaphore(
                NULL,           // default security attributes
                1,  // initial count
                1,  // maximum count
                L"pcisigdll_semopenclose");          // unnamed semaphore

            if (ghSemaphore == NULL)
            {
                fIgnore = UnmapViewOfFile(gWinVars);
                // Close the process's handle to the file-mapping object
                fIgnore = CloseHandle(hMapObject);
                return FALSE;
            }
            
            gIoctlSem = CreateSemaphore(
                NULL,           // default security attributes
                1,  // initial count
                1,  // maximum count
                L"pcisigdll_semoioctl");          // unnamed semaphore

            if (gIoctlSem == NULL)
            {
                fIgnore = UnmapViewOfFile(gWinVars);
                // Close the process's handle to the file-mapping object
                fIgnore = CloseHandle(hMapObject);
                CloseHandle(ghSemaphore);
                return FALSE;
            }

            break;
 
        // The attached process creates a new thread
 
        case DLL_THREAD_ATTACH:
            break;
 
        // The thread of the attached process terminates
 
        case DLL_THREAD_DETACH:
            break;
 
        // DLL unload due to process termination or FreeLibrary
 
        case DLL_PROCESS_DETACH:
 
            // Unmap shared memory from the process's address space
 
            fIgnore = UnmapViewOfFile(gWinVars);
 
            // Close the process's handle to the file-mapping object
 
            fIgnore = CloseHandle(hMapObject);
            CloseHandle(ghSemaphore);
            CloseHandle(gIoctlSem);
            
            break;
 
        default:
          break;
     }
 
    return TRUE;
    UNREFERENCED_PARAMETER(hinstDLL);
    UNREFERENCED_PARAMETER(lpvReserved);
}

extern "C"
{

extern void pcisigLog(UINT8 logLevel, const PCHAR function, const PCHAR message, ...);

/* FILETIME of Jan 1 1970 00:00:00. */
static const unsigned __int64 epoch = (__int64)(116444736000000000);

//
// Windows implementation of linux's gettimeofday()
// Used to maintain code compatability
//
int gettimeofday(struct timeval * tp, struct timezone * tzp)
{
    FILETIME        fileTime;
    ULARGE_INTEGER  uLarge;
    ULONGLONG       uSec;

    // Use GetSystemTimeAsFileTime as it seems the most accurate in Windows
    GetSystemTimeAsFileTime(&fileTime);

    uLarge.LowPart = fileTime.dwLowDateTime;
    uLarge.HighPart = fileTime.dwHighDateTime;

    uSec = uLarge.QuadPart / 10  -  epoch;
    tp->tv_sec  = (long)(uSec / 1000000ULL);
    tp->tv_usec = (long)(uSec % 1000000ULL);
    
    return 0;
}

//
// Boilerplate driver code to get the deviceInterface
// This basically locates our driver and attempts to open a handle
//
PSP_DEVICE_INTERFACE_DETAIL_DATA
getDeviceInterfaceDetailData(HDEVINFO devInfo, int devIndex)
{
	SP_DEVICE_INTERFACE_DATA          deviceInterfaceData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA  deviceInterfaceDetailData = NULL;
	ULONG                             requiredLength = 0;
	ULONG                             predictedLength = 0;


	deviceInterfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
	if (TRUE == SetupDiEnumDeviceInterfaces(devInfo,
                                            0, // No care about specific PDOs
                                            (LPGUID)&GUID_DEVINTERFACE_PCISIG,
                                            devIndex,
                                            &deviceInterfaceData))
    {
		// Allocate a function class device data structure to
		// receive the information about this particular device.
		// First find out required length of the buffer
		if (FALSE == SetupDiGetDeviceInterfaceDetail(devInfo,
                                                     &deviceInterfaceData,
                                                     NULL, // probing so no output buffer yet
                                                     0, // probing so output buffer length of zero
                                                     &requiredLength,
                                                     NULL))
        { // not interested in the specific dev-node
			if (ERROR_INSUFFICIENT_BUFFER != GetLastError())
            {
				return(NULL);
			}
		}
		predictedLength = requiredLength;
		deviceInterfaceDetailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(predictedLength);
		if (NULL == deviceInterfaceDetailData)
        {
			return(NULL);
		}
		deviceInterfaceDetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
		if (FALSE == SetupDiGetDeviceInterfaceDetail(devInfo,
                                                     &deviceInterfaceData,
                                                     deviceInterfaceDetailData,
                                                     predictedLength,
                                                     &requiredLength,
                                                     NULL))
        {
			free(deviceInterfaceDetailData);
			return(NULL);
		}
	}
	else if (ERROR_NO_MORE_ITEMS != GetLastError())
    {
		free(deviceInterfaceDetailData);
		return(NULL);
	}
	return(deviceInterfaceDetailData);
}

//
// UpdateDriverForPlugAndPlayDevices
//
typedef BOOL (WINAPI *UpdateDriverForPlugAndPlayDevicesProto)(_In_opt_ HWND hwndParent,
                                                              _In_ LPCTSTR HardwareId,
                                                              _In_ LPCTSTR FullInfPath,
                                                              _In_ DWORD InstallFlags,
                                                              _Out_opt_ PBOOL bRebootRequired
                                                         );
#ifdef _UNICODE
#define UPDATEDRIVERFORPLUGANDPLAYDEVICES "UpdateDriverForPlugAndPlayDevicesW"
#else
#define UPDATEDRIVERFORPLUGANDPLAYDEVICES "UpdateDriverForPlugAndPlayDevicesA"
#endif

// The following functions are boilerplate code used for
// manipulating the SetupDi* functions
LPTSTR * GetMultiSzIndexArray(_In_ __drv_aliasesMem LPTSTR MultiSz)
/*++
Routine Description:
    Get an index array pointing to the MultiSz passed in
Arguments:
    MultiSz - well formed multi-sz string
Return Value:
    array of strings. last entry+1 of array contains NULL
    returns NULL on failure
--*/
{
    LPTSTR scan;
    LPTSTR * array;
    int elements;

    for(scan = MultiSz, elements = 0; scan[0] ;elements++)
    {
        scan += _tcslen(scan)+1;
    }
    array = new LPTSTR[elements+2];
    if (NULL == array)
    {
        return NULL;
    }
    array[0] = MultiSz;
    //std::wcout << MultiSz << std::endl;

    array++;
    if (elements > 0)
    {
        for(scan = MultiSz, elements = 0; scan[0]; elements++)
        {
            array[elements] = scan;
            scan += _tcslen(scan)+1;
        }
    }
    array[elements] = NULL;
    return array;
}

LPTSTR * GetDevMultiSz(_In_ HDEVINFO Devs, _In_ PSP_DEVINFO_DATA DevInfo, _In_ DWORD Prop)
/*++
Routine Description:
    Get a multi-sz device property
    and return as an array of strings
Arguments:
    Devs    - HDEVINFO containing DevInfo
    DevInfo - Specific device
    Prop    - SPDRP_HARDWAREID or SPDRP_COMPATIBLEIDS
Return Value:
    array of strings. last entry+1 of array contains NULL
    returns NULL on failure
--*/
{
    LPTSTR buffer;
    DWORD size;
    DWORD reqSize;
    DWORD dataType;
    LPTSTR * array;
    DWORD szChars;

    size = 8192; // initial guess, nothing magic about this
    buffer = new TCHAR[(size/sizeof(TCHAR))+2];
    if(buffer == NULL)
    {
        return NULL;
    }
    while (FALSE == SetupDiGetDeviceRegistryProperty(Devs,DevInfo,Prop,&dataType,(LPBYTE)buffer,size,&reqSize))
    {
        if(GetLastError() != ERROR_INSUFFICIENT_BUFFER)
        {
            goto failed;
        }
        if(dataType != REG_MULTI_SZ)
        {
            goto failed;
        }
        size = reqSize;
        delete [] buffer;
        buffer = new TCHAR[(size/sizeof(TCHAR))+2];
        if(buffer == NULL)
        {
            goto failed;
        }
    }
    szChars = reqSize/sizeof(TCHAR);
    buffer[szChars] = TEXT('\0');
    buffer[szChars+1] = TEXT('\0');
    array = GetMultiSzIndexArray(buffer);
    if(array != NULL)
    {
        return array;
    }

failed:
    if(buffer != NULL)
    {
        delete [] buffer;
    }
    return NULL;
}

void DelMultiSz(_In_opt_ __drv_freesMem(object) PZPWSTR Array)
/*++
Routine Description:
    Deletes the string array allocated by GetDevMultiSz/GetRegMultiSz/GetMultiSzIndexArray
Arguments:
    Array - pointer returned by GetMultiSzIndexArray
Return Value:
    None
--*/
{
    if(Array != NULL)
    {
        Array--;
        if(Array[0] != NULL)
        {
            delete [] Array[0];
        }
        delete [] Array;
    }
}


UINT32 pcisigDriverUninstall(void)
{
    HDEVINFO                    devs = INVALID_HANDLE_VALUE;
    DWORD                       devIndex;
    SP_DEVINFO_DATA             devInfo;
    SP_DEVINFO_LIST_DETAIL_DATA devInfoListDetail;
    BOOL                        match = FALSE;
    LPCTSTR                     hwid = (LPCTSTR) L"root\\pcisig_driver";
    LPTSTR                      *hwIds = NULL;
    SP_REMOVEDEVICE_PARAMS      rmdParams;
    TCHAR                       devID[MAX_DEVICE_ID_LEN];
    UINT32                      retStatus = IOCTL_STATUS_SUCCESS;

    // Only enumerate the "ROOT" devices
    devs = SetupDiGetClassDevsEx(NULL,
                                 (PCWSTR) L"ROOT",
                                 NULL,
                                 DIGCF_ALLCLASSES | DIGCF_PRESENT,
                                 NULL,
                                 NULL,
                                 NULL);
    if(devs == INVALID_HANDLE_VALUE)
    {
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverUninstall_end;
    }

    devInfoListDetail.cbSize = sizeof(devInfoListDetail);
    if(FALSE == SetupDiGetDeviceInfoListDetail(devs,&devInfoListDetail))
    {
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverUninstall_end;
    }
    
    devInfo.cbSize = sizeof(devInfo);
    for(devIndex=0;SetupDiEnumDeviceInfo(devs,devIndex,&devInfo);devIndex++)
    {
        // search for matches
        hwIds = GetDevMultiSz(devs,&devInfo,SPDRP_HARDWAREID);
        if(_tcsicmp(hwid,hwIds[0]) == 0)
        {
            match = TRUE;
            DelMultiSz((PZPWSTR)hwIds);
            break;
        }
        DelMultiSz((PZPWSTR)hwIds);
    }
    
    if (match == TRUE)
    {
        devInfoListDetail.cbSize = sizeof(devInfoListDetail);
        if((FALSE == SetupDiGetDeviceInfoListDetail(devs,&devInfoListDetail)) ||
                (CM_Get_Device_ID_Ex(devInfo.DevInst,devID,MAX_DEVICE_ID_LEN,0,devInfoListDetail.RemoteMachineHandle)!=CR_SUCCESS))
        {
            retStatus = IOCTL_STATUS_ERROR_SETUPDI;
            goto pcisigDriverUninstall_end;
        }

        // This code finally removes the device
        rmdParams.ClassInstallHeader.cbSize = sizeof(SP_CLASSINSTALL_HEADER);
        rmdParams.ClassInstallHeader.InstallFunction = DIF_REMOVE;
        rmdParams.Scope = DI_REMOVEDEVICE_GLOBAL;
        rmdParams.HwProfile = 0;
        if((FALSE == SetupDiSetClassInstallParams(devs,&devInfo,&rmdParams.ClassInstallHeader,sizeof(rmdParams))) ||
           (FALSE == SetupDiCallClassInstaller(DIF_REMOVE,devs,&devInfo)))
        {
            retStatus = IOCTL_STATUS_ERROR_SETUPDI;
            goto pcisigDriverUninstall_end;
        }
    }

pcisigDriverUninstall_end:
    if(devs != INVALID_HANDLE_VALUE)
    {
        SetupDiDestroyDeviceInfoList(devs);
    }
    return retStatus;

}


//
// Install the pcisig driver
// Based on boilerplate code to install a device
//
UINT32 pcisigDriverInstall(void)
{
    UpdateDriverForPlugAndPlayDevicesProto UpdateFn;
    HDEVINFO        DeviceInfoSet = INVALID_HANDLE_VALUE;
    SP_DEVINFO_DATA DeviceInfoData;
    GUID            ClassGUID;
    TCHAR           ClassName[MAX_CLASS_NAME_LEN];
    TCHAR           hwIdList[LINE_LEN+4];
    TCHAR           InfPath[MAX_PATH];
    UINT32          retStatus = IOCTL_STATUS_SUCCESS;
    LPCTSTR         hwid = (LPCTSTR) L"root\\pcisig_driver";
    LPCTSTR         inf = (LPCTSTR) L"pcisig_driver\\pcisig_driver.inf";
    DWORD           flags = 0;
    HMODULE         newdevMod = NULL;
    BOOL            reboot = FALSE;


    // Inf must be a full pathname
    if(GetFullPathName(inf,MAX_PATH,InfPath,NULL) >= MAX_PATH)
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"GetFullPathName() failed!\n");
        retStatus = IOCTL_STATUS_ERROR_INF;
        goto pcisigDriverInstall_end;
    }
    
    // List of hardware ID's must be double zero-terminated
    ZeroMemory(hwIdList,sizeof(hwIdList));
    if (FAILED(StringCchCopy(hwIdList,LINE_LEN, hwid)))
    {
        retStatus = IOCTL_STATUS_ERROR_INF;
        goto pcisigDriverInstall_end;
    }
    
    // Use the INF File to extract the Class GUID.
    // Fails if the INF is not found
    if (FALSE == SetupDiGetINFClass(InfPath,&ClassGUID,ClassName,sizeof(ClassName)/sizeof(ClassName[0]),0))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"SetupDiGetINFClass() failed.  InfPath = %ls\n",InfPath);
        retStatus = IOCTL_STATUS_ERROR_INFNOTFOUND;
        goto pcisigDriverInstall_end;
    }

    // Create the container for the to-be-created Device Information Element.
    DeviceInfoSet = SetupDiCreateDeviceInfoList(&ClassGUID,0);
    if(DeviceInfoSet == INVALID_HANDLE_VALUE)
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"SetupDiCreateDeviceInfoList() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverInstall_end;
    }
    
    // Now create the element using the Class GUID and Name from the INF file.
    DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
    if (FALSE == SetupDiCreateDeviceInfo(DeviceInfoSet,
                                         ClassName,
                                         &ClassGUID,
                                         NULL,
                                         0,
                                         DICD_GENERATE_ID,
                                         &DeviceInfoData))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"SetupDiCreateDeviceInfo() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverInstall_end;
    }

    // Add the HardwareID to the Device's HardwareID property.
    if(FALSE == SetupDiSetDeviceRegistryProperty(DeviceInfoSet,
                                                 &DeviceInfoData,
                                                 SPDRP_HARDWAREID,
                                                 (LPBYTE)hwIdList,
                                                 ((DWORD)_tcslen(hwIdList)+1+1)*sizeof(TCHAR)))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"SetupDiSetDeviceRegistryProperty() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverInstall_end;
     }

    // Transform the registry element into an actual devnode
    // in the PnP HW tree.
    if (FALSE == SetupDiCallClassInstaller(DIF_REGISTERDEVICE,
                                           DeviceInfoSet,
                                           &DeviceInfoData))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"SetupDiCallClassInstaller() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_SETUPDI;
        goto pcisigDriverInstall_end;
     }

    // update the driver for the device we just created
    if(GetFileAttributes(InfPath)==(DWORD)(-1))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"GetFileAttributes() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_INF;
        goto pcisigDriverInstall_end;
    }

    inf = InfPath;
    flags |= INSTALLFLAG_FORCE;

    // make use of UpdateDriverForPlugAndPlayDevices
    newdevMod = LoadLibrary(TEXT("newdev.dll"));
    if (FALSE == newdevMod)
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"LoadLibrary(newdev.dll) failed.\n");
        retStatus = IOCTL_STATUS_ERROR_UPDATEDRIVER;
        goto pcisigDriverInstall_end;
    }
    UpdateFn = (UpdateDriverForPlugAndPlayDevicesProto)GetProcAddress(newdevMod,UPDATEDRIVERFORPLUGANDPLAYDEVICES);
    if (FALSE == UpdateFn)
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"UpdateDriverForPlugAndPlayDevicesProto() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_UPDATEDRIVER;
        goto pcisigDriverInstall_end;
    }

    if(FALSE == UpdateFn(NULL,hwid,inf,flags,&reboot))
    {
        pcisigLog(PCISIGLOG_ERROR, (const PCHAR)__func__, (const PCHAR)"UpdateDriverForPlugAndPlayDevicesProto() failed.\n");
        retStatus = IOCTL_STATUS_ERROR_UPDATEDRIVER;
        goto pcisigDriverInstall_end;
    }

pcisigDriverInstall_end:
    if (DeviceInfoSet != INVALID_HANDLE_VALUE)
    {
        SetupDiDestroyDeviceInfoList(DeviceInfoSet);
    }
    if(newdevMod != NULL)
    {
        FreeLibrary(newdevMod);
    }
    return retStatus;
}

PSP_DEVICE_INTERFACE_DETAIL_DATA pcisigFindDriver(void)
{
    HDEVINFO                            devInfo;
    PSP_DEVICE_INTERFACE_DETAIL_DATA    deviceInterfaceDetailData = NULL;
    int                                 i;
    
    // Open a handle to the device interface information set of all
    // present class interfaces.
    devInfo = SetupDiGetClassDevs(NULL,
                                  NULL, // Define no enumerator (global)
                                  NULL, // Define no
                                  (DIGCF_PRESENT | // Only Devices present & function class devices
                                   DIGCF_DEVICEINTERFACE | DIGCF_ALLCLASSES));
    if (INVALID_HANDLE_VALUE == devInfo) {
        goto pcisigFindDriver_end;
    }


    // Look for the matching serial number
    i = 0;
    while (NULL != (deviceInterfaceDetailData = getDeviceInterfaceDetailData(devInfo, i++)))
    {
        // For now, we'll just match the first one we come to.
        if (NULL != deviceInterfaceDetailData)
            break;
        // We MUST free the detail data struct from getDeviceInterfaceDetailData.
        free(deviceInterfaceDetailData);
        deviceInterfaceDetailData = NULL;
    }
    SetupDiDestroyDeviceInfoList(devInfo);

pcisigFindDriver_end:
    return deviceInterfaceDetailData;

}

void pcisigWinCloseDriver(HANDLE hDev)
{
    CloseHandle(hDev);
    hDev = INVALID_HANDLE_VALUE;
    // Uninstall the driver
    // Removing this for now. Leave with the driver installed
    //pcisigDriverUninstall();
}

UINT32 pcisigWinOpenDriver(HANDLE *hDev)
{
    PSP_DEVICE_INTERFACE_DETAIL_DATA    deviceInterfaceDetailData = NULL;
    ULONG                               requiredLength = 0, bytes = 0;
    UINT32                              retStatus = IOCTL_STATUS_SUCCESS;
    
    // First lets see if we can find our device, assume the driver is installed
    deviceInterfaceDetailData = pcisigFindDriver();
    if (NULL == deviceInterfaceDetailData)
    {
        retStatus = pcisigDriverInstall();
        if (retStatus != IOCTL_STATUS_SUCCESS)
            goto pcisigWinOpenDriver_end;
        deviceInterfaceDetailData = pcisigFindDriver();
        if (NULL == deviceInterfaceDetailData)
        {
            pcisigDriverUninstall();
            retStatus = IOCTL_STATUS_DRIVER_NOTFOUND;
            goto pcisigWinOpenDriver_end;
        }
    }
    *hDev = CreateFile(deviceInterfaceDetailData->DevicePath,
                       GENERIC_READ | GENERIC_WRITE,
                       0,
                       NULL, // no SECURITY_ATTRIBUTES structure
                       OPEN_EXISTING, // No special create flags
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);
    free(deviceInterfaceDetailData);

    if (INVALID_HANDLE_VALUE == *hDev)
    {
        retStatus = IOCTL_STATUS_ERROR_INVALID_FILEHANDLE;
        goto pcisigWinOpenDriver_end;
    }

pcisigWinOpenDriver_end:
    return retStatus;
}

}

