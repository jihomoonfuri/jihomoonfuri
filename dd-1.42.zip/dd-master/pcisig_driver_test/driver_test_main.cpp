#include <windows.h>


extern "C"
{
 int test_main(int argC, char* argV[]);
}


int main(int argc, char* argv[])
{
	test_main(argc, argv);
	return(0); // return success
}
